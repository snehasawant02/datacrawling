'''
!/usr/bin/env python
title           : pcworld_uk.py
description     : To crawl Product information uisng python(Selenium,BS4)
author          : Sayar Mendis
date            : 6-8-2018
version         : 0.1
python_version  : 3.6.4
==============================================================================
'''

import datetime
import requests
import pandas as pd
from bs4 import BeautifulSoup
from openpyxl import load_workbook
from pandas import ExcelWriter
import pyodbc
import os
from selenium import webdriver
from selenium.webdriver.chrome.options import Options

chromedriver = "chromedriver.exe"
os.environ["webdriver.chrome.driver"] = chromedriver

options = Options()
# options.add_argument('--headless')
options.add_argument('--disable-gpu')  # Last I checked this was necessary.

driver = webdriver.Chrome(chromedriver, chrome_options=options)
driver.set_page_load_timeout(120)


#proxy = {'https': 'https://eclerxusa:WonderS1979@london.wonderproxy.com:80'}
headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36',
           'content-type': 'text/html;charset=utf-8',
           'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
           'Host': 'www.misco.fr'}
input = []
DataOut = []
sqldata=[]
tempout=[]
#----proxy fetch from excel
excel_file = 'E:\Python\AMD Script\ProxyInput.xlsx'
# excel_file = r'E:\SAYAR PROJECTS\PYTHON\AMD_CNCT\\ProxyInput.xlsx'

proxy_set = pd.read_excel(excel_file)


def excel_To_List():
    # filename=r'E:\SAYAR PROJECTS\PYTHON\AMD_CNCT\Input.xlsx'
    filename='E:\Python\AMD Script\Input.xlsx'
    wb= load_workbook(filename)
    ws = wb['Sheet1']
    row = ws.max_row
    col=ws.max_column
    for row in ws.iter_rows(min_row=1, min_col=0, max_row=row, max_col=1):
        for cell in row:
            if cell.value is not None and "cdw" in cell.value:
                input.append(cell.value)
    wb.close()


# def get_proxy(proxy_set):
#     plen = len(proxy_set)
#     gr = random.randrange(0, plen, step=5)
#     row_data = proxy_set.loc[gr]
#     ip = row_data[1]
#     port = row_data[2]
#     uname = row_data[3]
#     pswrd = row_data[4]
#     text = "https://" + str(uname) + ":" + str(pswrd) + "@" + str(ip) + ":" + str(port)
#     return text


def fetch_data(url):
    #proxy = {"https": "https://216.227.130.3:80"}
    try:

        print('Running URL  : ' + url)
        driver.get(url)
        page = driver.page_source
    except Exception as e:
        print('Page not hit: (Pagging Error)')
    return page


def get_PageNo(res):
    soup = BeautifulSoup(res, 'lxml')
    try:
        count = soup.find("div", {'class': 'search-pagination-range'}).text.split("of")[1].replace(',','').strip()
        if count:
            products = int(count)
            Pages = int(products/72)
            if products % 72 > 0:
                Pages += 1
        else:
            Pages = 0
    except Exception as e:
        Pages = 1
    return Pages


def Extract_data(res, url):
    soup = BeautifulSoup(res, 'lxml')
    today =str(datetime.datetime.now()).split(".")[0]

    try:
        block = soup.find_all('div', {'class': 'search-result coupon-check'})
        for li in block:
            Namea = li.find('a', {'class': 'search-result-product-url'})
            Name = Namea.text
            try:
                Desc = li.find('div', {'class': 'product-specs'}).text
                Namea=Namea+'^^'+Desc
            except:
                pass
            ProdURL = 'https://www.cdw.com'+Namea['href']
            namepart = Name.split(" ")
            Manufacturer = namepart[0]
            try:
                promo = list_price = li.find('div', {'class': 'price-type-price'}).text.replace('$', '').replace(',', '')
            except:
                promo = list_price = 'Check For Price'
            Itemnumber = li['data-product-code']
            mpn = Itemnumber
            temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                    'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': list_price,
                    'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                    'Category URL': CategoryURL, 'Crawling Date': today}
            DataOut.append(temp)
            tempout.append(temp)
    except Exception as e:
        temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': '', 'MPN': '',
                'Manufacturer': '', 'Name': 'Not Found'+str(e), 'Product URL': '', 'List Price': '',
                'Promo Price': '', 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                'Category URL': CategoryURL, 'Crawling Date': today}
        DataOut.append(temp)
        tempout.append(temp)


def Push_TO_Sql(df):
    connStr = pyodbc.connect('DRIVER={SQL Server};SERVER=ecxus249;DATABASE=SHOPAMD;UID=SHOPAMD;PWD=SHOP@md2010')
    if connStr:
        print('Connected To SQL Server')
        cursor = connStr.cursor()
        for index, row in df.iterrows():
            try:
                cursor.execute("INSERT INTO dbo.Master_Collation(LOB,Country,Site,Itemnumber,MPN,Manufacturer,ProductName,ProductURL,Listprice,Promoprice,CurrencyType,RetailerID,Date) values(?,?,?,?,?,?,?,?,?,?,?,?,?)", row['LOB'],row['Country'],row['Site'],row['ItemNumber'],row['MPN'],row['Manufacturer'],row['Name'],row['Product URL'],row['List Price'],row['Promo Price'],row['Currency'],row['Retailer ID'],row['Crawling Date'])
            except Exception as e:
                print(e)
        connStr.commit()
        print('Sucessfully Stored Records To DB')
        cursor.close()
        connStr.close()


def Result_Out_Excel(DataOut):
    col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price',
           'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']
    dt = str(datetime.date.today())
    filename = 'CDW_US' + "_" + dt
    path = r"E:\Python\AMD Script\Output\\" + filename + ".xlsx"
    df = pd.DataFrame(DataOut, columns=col)
    writer = pd.ExcelWriter(path, engine='xlsxwriter', options={'strings_to_urls': False})
    df.to_excel(writer, 'Sheet1', index=False)
    writer.save()
    writer.close()

    #
    # col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price',
    #        'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']
    #
    # dt = str(datetime.date.today())
    # filename = "CDW_US_" + dt
    # path = "E:\Python\AMD Script\Output\\" + filename + ".xlsx"
    # # path = "E:\SAYAR PROJECTS\PYTHON\AMD_CNCT\Output\\" + filename + ".xlsx"
    # df = pd.DataFrame(DataOut, columns=col)
    # writer = ExcelWriter(path)
    # df.to_excel(writer, 'Sheet1', index=False)
    # writer.save()
    # writer.close()
    # return df




print("start")
LOB = ''
site = ''
country = ''
CurrencyType = ''
RetailerId = ''
CategoryURL = ''
excel_To_List()
ic=0
col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price',
           'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']

for url in input:
    ic+=1
    if "cdw.com" in url:
        print('Running URL :'+str(ic)+') '+url+' out of '+str(len(input)))
        indx = url.index('^')
        if indx != 0:
            LOB = url[:indx]
            url = url[indx+1:]
            CategoryURL = url
            url = url.replace("http:", "https:")
            country = 'US'
            if country == "US":
                RetailerId = "95951"
                CurrencyType = "USD"
            site = 'cdw-us'
        response = fetch_data(url)
        Pages = int(get_PageNo(response))
        for i in range(1,Pages+1):
            '''Pages+1'''
            print('Page '+str(i)+' is Running Out of '+str(Pages))
            srl_sp=url.split("pCurrent")[0]
            caturl=srl_sp+'pCurrent='+str(i)
            CatRes = fetch_data(caturl)
            Extract_data(CatRes, url)
            print('Page ' + str(i) + ' Completed Out of ' + str(Pages))
            Result_SQL = pd.DataFrame(tempout, columns=col)
            Push_TO_Sql(Result_SQL)
            tempout.clear()
            Result_Out_Excel(DataOut)
