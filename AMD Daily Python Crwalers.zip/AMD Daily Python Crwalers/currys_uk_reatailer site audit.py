import pandas as pd
from pandas import ExcelWriter
import pyodbc
from tkinter.tix import ResizeHandle
import datetime
import requests
import re
from bs4 import BeautifulSoup
from openpyxl import load_workbook
import xlsxwriter
import random
sess = requests.session()
sess.headers =({
    'Connection': 'keep-alive',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36',
    'Upgrade-Insecure-Requests': '1',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-GB,en;q=0.9,en-US;q=0.8,hi;q=0.7'})
input = []
DataOut = []
sqldata=[]
#----proxy fetch from excel
#excel_file = 'E:\Prasad\ProxyInput.xlsx'
#proxy_set = pd.read_excel(excel_file)

def excel_To_List():
    wb= load_workbook(filename='E:\Python\AMD Script\Input.xlsx')
    ws = wb['Sheet4']
    row = ws.max_row
    col=ws.max_column
    for row in ws.iter_rows(min_row=2, min_col=0, max_row=row, max_col=1):
        for cell in row:
            input.append(cell.value)
    wb.close()

def Result_Out_Excel(DataOut):
    col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price',
           'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']

    dt = str(datetime.date.today())
    filename = "Currys_uk" + dt
    path = "E:\Python\AMD Script\Output\\" + filename + ".xlsx"
    # path = "E:\SAYAR PROJECTS\PYTHON\AMD_CNCT\Output\\" + filename + ".xlsx"
    df = pd.DataFrame(DataOut, columns=col)
    writer = ExcelWriter(path)
    df.to_excel(writer, 'Sheet1', index=False)
    writer.save()
    return df


def fetch_data(url):
    proxy = {'https': 'https://eclerxamd:Rid8B67I2Q@shp-prx109-us-v00002.tp-ns.com:80'}
    res = ''
    try:
        res = sess.get(url, proxies=proxy).text
    except Exception as e:
        print("type error: " + str(e))
    return res

def get_PageNo(res):
    soup = BeautifulSoup(res, 'lxml')
    try:
        PageDiv = soup.find("div", {'data-component': 'list-page-results-message'}).text.replace("\n", '').replace('\t', '')
        regx = re.compile('of\s\d+')
        notext = regx.search(PageDiv)
        no = notext.group().replace('of ', '')
        if no:
            products = int(no)
            Pages = int(products/20)
            if products % 20 > 0:
                Pages += 1
        else:
            Pages = 0
    except Exception as e:
        Pages = 0
    return Pages

def Extract_data(res, url):
    soup = BeautifulSoup(res, 'lxml')
    today = datetime.datetime.today()
    try:
        container = soup.find('div', {'data-component': 'product-list-view'})
        block = container.find_all('article')
        for li in block:
            Name = li.find('header', {'class': 'productTitle'}).text

            namepart = Name.split(" ")
            Manufacturer = namepart[0]
            try:
                Desc = li.find('ul', {'class': 'productDescription'}).text.replace("\n", " ").strip()
                Name=Name+'^^'+Desc
            except:
                pass
            if li.find('header', {'class': 'productTitle'}).find('a') is not None:
                ProdURL = li.find('header', {'class': 'productTitle'}).find('a')['href']
            else:
                ProdURL = li.find('a', {'class': 'in'})['href']
            mpn = Itemnumber = ProdURL.split('-')[-2]


            try:
                promo = price = li.find('strong', {'class': 'price'}).text.replace('\n','').replace('\t', '').replace('£', '').replace(",", "").strip()
            except Exception as es:
                price = promo = "Check for price"
            temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                    'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                    'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                    'Category URL': CategoryURL, 'Crawling Date': today}
            DataOut.append(temp)
            sqldata.append(temp)
    except Exception as e:
        temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': '', 'MPN': '',
                'Manufacturer': '', 'Name': '', 'Product URL': '', 'List Price': '',
                'Promo Price': '', 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                'Category URL': CategoryURL, 'Crawling Date': today}
        DataOut.append(temp)
        sqldata.append(temp)
    return DataOut

def Push_TO_Sql(df):
    ''''add here'''
    connStr = pyodbc.connect('DRIVER={SQL Server};SERVER=ecxus249;DATABASE=SHOPAMD;UID=SHOPAMD;PWD=SHOP@md2010')
    if connStr:
        # print('Connected To SQL Server')
        cursor = connStr.cursor()
        for index, row in df.iterrows():
            try:
                cursor.execute("INSERT INTO dbo.Master_Collation(LOB,Country,Site,Itemnumber,MPN,Manufacturer,ProductName,ProductURL,Listprice,Promoprice,CurrencyType,RetailerID,Date) values(?,?,?,?,?,?,?,?,?,?,?,?,?)", row['LOB'],row['Country'],row['Site'],row['ItemNumber'],row['MPN'],row['Manufacturer'],row['Name'],row['Product URL'],row['List Price'],row['Promo Price'],row['Currency'],row['Retailer ID'],row['Crawling Date'])
            except Exception as e:
                print(e)
        connStr.commit()
        print('Sucessfully Stored Records To DB')
        cursor.close()
        connStr.close()


print("start")
LOB = ''
site = ''
country = ''
CurrencyType = ''
RetailerId = ''
CategoryURL = ''
excel_To_List()
col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price',
           'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']

for url in input:
    if "currys.co.uk" in url:
        print(url)
        indx = url.index('^')
        if indx != 0:
            LOB = url[:indx]
            url = url[indx+1:]
            CategoryURL = url
            url = url.replace("http:", "https:")
            splitURL = url.split('/')
            hostpart = splitURL[2].split('.')
            country = hostpart[3].upper()
            if country == "UK":
                RetailerId = "28858"
                CurrencyType = "GBP"
            #site = hostpart[1] + "-" + country
            site = "currys-uk"
        response = fetch_data(url)
        Pages = int(get_PageNo(response))
        for i in range(1, Pages+1):
            if Pages > 1:
                urlText = "1_20"
                PageText = str(i)+"_20"
                caturl = url.replace(urlText, PageText)
            else:
                caturl = url
            CatRes = fetch_data(caturl)
            Extract_data(CatRes, url)
            Result_SQL = pd.DataFrame(sqldata, columns=col)
            # Push_TO_Sql(Result_SQL)
            # sqldata.clear()
Result_Out_Excel(DataOut)
print("Crawling Completed Successfully")
Result_SQL=Result_Out_Excel(DataOut)
print('Çompleted')