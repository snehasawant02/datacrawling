'''
Last Modified By : Hemant
Last Modified Date :
'''
import datetime
import requests
import re
from bs4 import BeautifulSoup
from openpyxl import load_workbook
import xlsxwriter
import pyodbc
import pandas as pd
from pandas import ExcelWriter

sess = requests.session()
sess.headers = ({
    'Connection': 'keep-alive',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36',
    'Upgrade-Insecure-Requests': '1',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-GB,en;q=0.9,en-US;q=0.8,hi;q=0.7'})
InputURL = []
DataOut = []
sqldata=[]


def excel_to_list():
    # wb = load_workbook(filename='E:\Python\AMD Script\Hemant Test\InputHK.xlsx')
    wb = load_workbook(filename='E:\Python\AMD Script\Input.xlsx')
    ws = wb['Sheet1']
    row = ws.max_row
    col = ws.max_column
    for row in ws.iter_rows(min_row=1, min_col=0, max_row=row, max_col=1):
        for cell in row:
            InputURL.append(cell.value)
    wb.close()


def fetch_data(url):
    res = ''
     #proxy = {"https": "http://eclerxamd:Rid8B67I2Q@shp-prx109-uk-v00001.tp-ns.com:80"}
    try:
        res = sess.get(url).text
    except Exception as e:
        print("type error: " + str(e))
    return res


def get_pageno(res):
    soup = BeautifulSoup(res, 'lxml')
    try:
        PageDiv = soup.find("div", {'class': 'search-header-form'}).text.replace("\n", '').replace('\t', '')
        regx = re.compile(r'\d+')
        no = regx.search(PageDiv)
        if no:
            products = int(no.group())
            Pages = int(products/50)
            if products % 50 > 0:
                Pages += 1
        else:
            Pages = 0
    except Exception as e:
        Pages = 0
    return Pages

def extract_data(res, url):
    Itemnumber = ''
    mpn = ''
    Manufacturer = ''
    Name = ''
    ProdURL = ''
    price = ''
    promo = ''
    today = str(datetime.datetime.now()).split(".")[0]
    soup = BeautifulSoup(res, 'lxml')
    try:
        container = soup.find('div', {'id': 'search_results_products'})
        block = container.find_all('div', {'class': 'search-results-list-item'})
        for li in block:
            try:
                Name = li.find('h2', {'class': 'product-name'}).find('a').text
                namepart = Name.split(" ")
                Manufacturer = namepart[0]
                try:
                    Desc = li.find('div', {'class': 'product-information'}).text.replace("\n", " ").strip()
                    Name=Name+'^^'+Desc
                except:
                    pass
                ProdURL = li.find('h2', {'class': 'product-name'}).find('a')['href']
                try:
                    promo = price = li.find('span', {'class': 'linelistvatprice'}).text.replace('\n', '').replace('\t', '').replace('£', '').replace(",", "")
                except Exception as es:
                    price = promo = "Check for price"
                try:
                    ItemDiv = li.find("ul", {"class": "product-codes"})
                    liItem = ItemDiv.find_all("li")
                    for l in liItem:
                        if 'Insight #:' in l.text:
                            Itemnumber = l.find('span').text
                            Itemnumber = Itemnumber[3:]
                        if 'Mfr. #:' in l.text:
                            mpn = l.find('span').text
                except:
                    if mpn == '':
                        mpn = Itemnumber
                temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                        'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                        'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                        'Category URL': url, 'Crawling Date': today}
                DataOut.append(temp)
                sqldata.append(temp)
            except:
                print("error in product")
    except Exception as e:
        temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                'Category URL': url, 'Crawling Date': today}
        DataOut.append(temp)
        sqldata.append(temp)
    return DataOut


def push_to_sql(df):
    ''''add here'''
    conn_str = pyodbc.connect('DRIVER={SQL Server};SERVER=ecxus249;DATABASE=SHOPAMD;UID=SHOPAMD;PWD=SHOP@md2010')
    if conn_str:
        # print('Connected To SQL Server')
        cursor = conn_str.cursor()
        for index, row in df.iterrows():
            try:
                cursor.execute("INSERT INTO dbo.Master_Collation(LOB,Country,Site,Itemnumber,MPN,Manufacturer,ProductName,ProductURL,Listprice,Promoprice,CurrencyType,RetailerID, CategoryURL, Date) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", row['LOB'],row['Country'],row['Site'],row['ItemNumber'],row['MPN'],row['Manufacturer'],row['Name'],row['Product URL'],row['List Price'],row['Promo Price'],row['Currency'],row['Retailer ID'], row['Category URL'],row['Crawling Date'])
            except Exception as e:
                print("String SQL", e)
        conn_str.commit()
        print('Sucessfully Stored Records To DB')
        cursor.close()
        conn_str.close()


def result_out_excel(DataOut):
    col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price', 'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']
    dt = str(datetime.date.today())
    filename = site + "_" + dt
    path = "E:\Python\AMD Script\Output\\" +filename+".xlsx"
    df = pd.DataFrame(DataOut, columns=col)
    writer = pd.ExcelWriter(path, engine='xlsxwriter', options={'strings_to_urls': False})
    df.to_excel(writer, 'Sheet1', index=False)
    writer.save()



print("start")
LOB = ''
site = ''
country = ''
CurrencyType = ''
RetailerId = ''
CategoryURL = ''
col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price',
           'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']
excel_to_list()
for url in InputURL:
    if "uk.insight" in url:
        print(url)
        indx = url.index('^')
        if indx != 0:
            LOB = url[:indx]
            url = url[indx+1:]
            CategoryURL = url
            splitURL = url.split('/')
            country = splitURL[3].replace("en-", "")
            if country == "gb":
                country = 'UK'
                RetailerId = "95991"
                CurrencyType = "GBP"
            site = splitURL[2].replace('www.uk.', '').replace('com', '').replace('.', '-') + country.lower()
        response = fetch_data(url)
        Pages = int(get_pageno(response))
        for i in range(1, Pages+1):
            if Pages > 1:
                urlText = "&P=1"
                PageText = "&P="+str(i)
                caturl = url.replace(urlText, PageText)
                # print(caturl)
            else:
                caturl = url
            CatRes = fetch_data(caturl)
            extract_data(CatRes, url)
            Result_SQL = pd.DataFrame(sqldata, columns=col)
            push_to_sql(Result_SQL)
            sqldata.clear()
result_out_excel(DataOut)
