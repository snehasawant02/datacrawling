import datetime
import requests
from bs4 import BeautifulSoup
from openpyxl import load_workbook
import pandas as pd
from pandas import ExcelWriter
import re
import pyodbc


sess = requests.session()
sess.headers = ({
    'Connection': 'keep-alive',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36',
    'Upgrade-Insecure-Requests': '1',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-GB,en;q=0.9,en-US;q=0.8,hi;q=0.7'})
input = []
DataOut = []
sqldata=[]


def excel_to_list():
    wb =load_workbook(filename='E:\Python\AMD Script\Input.xlsx')
    #wb = load_workbook(filename='E:\Prasad\Input.xlsx')
    ws = wb['Sheet1']
    row = ws.max_row
    col=ws.max_column
    for row in ws.iter_rows(min_row=1, min_col=0, max_row=row, max_col=1):
        for cell in row:
            input.append(cell.value)
    wb.close()


def fetch_data(url):
    if "/gb/" in url:
        sess.proxies = {"https", "https://eclerxamd:Rid8B67I2Q@shp-prx109-us-v00002.tp-ns.com:80"}
    res = ''
    try:
        res = sess.get(url).text
        # res = sess.get(url, proxies=proxies).text
    except Exception as e:
        print("type error: " + str(e))
    return res


def get_pageno(res):
    soup = BeautifulSoup(res, 'lxml')
    products = ''
    # try:
    #     if soup.find("div", {'class': 'totalResults'}) is not None:
    #         PageDiv = soup.find("div", {'class': 'totalResults'}).text.replace("\n", '').replace('\t', '')
    #         regx = re.compile(r'\d+')
    #         no = regx.search(PageDiv)
    #         if no:
    #             products = int(no.group())
    #     elif soup.find('span', {'class': 'facet-area-products-count'}):
    #         products = int(soup.find('span', {'class': 'facet-area-products-count'}).text)
    #     if products is not "":
    #         Pages = int(products / 8)
    #         if products % 8 > 0:
    #             Pages += 1
    #     else:
    #         Pages = 0
    try:
        if soup.find('div', {'class': 'accessories-pagination'}) is not None:
            Pages = soup.find('div', {'class': 'accessories-pagination'}).find_all('li')[-3].text
            # print(Pages)
        else:
            Pages=0
    except Exception as e:
        Pages = 0
    return Pages


def extract_data(res, url, CategoryURL):
    Itemnumber = ''
    mpn = ''
    Manufacturer = ''
    Name = ''
    ProdURL = ''
    price = ''
    promo = ''
    today = str(datetime.datetime.now()).split(".")[0]
    soup = BeautifulSoup(res, 'lxml')
    try:
        if soup.find('div', {'id': 'resultsList'}) is not None:
            container = soup.find('div', {'id': 'resultsList'})
            block = container.find_all('div', {'class': 'facetedResults-item only-allow-small-pricingSummary'})
            for li in block:
                try:
                    Name = li.find('h3', {'class': 'facetedResults-title'}).find('a').text.strip()
                    namepart = Name.split(" ")
                    Manufacturer = namepart[0]
                    ProdURL = "https://www3.lenovo.com" + li.find('h3', {'class': 'facetedResults-title'}).find('a')['href']
                    if li.find('dd', {'itemprop': 'price'}) is not None:
                        promo = price = li.find('dd', {'itemprop': 'price'}).text.replace(',','').replace('\n','').replace('\t','').replace('€', '').replace('£', '').replace('$', '').strip()
                    else:
                        promo = price = li.find('dd', {'class': 'saleprice'}).text.replace(',','').replace('\n','').replace('\t','').replace('€', '').replace('£', '').replace('$', '').strip()
                    if li.find('input', {'name': 'productCodePost'}) is not None:
                        Itemnumber = li.find('input', {'name': 'productCodePost'})['value']
                    else:
                        IMSplit = ProdURL.split('/')
                        ind = IMSplit.__len__() - 1
                        Itemnumber = IMSplit[ind]
                    mpn = Itemnumber
                    temp = {}
                    temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn, 'Manufacturer': Manufacturer,
                            'Name': Name, 'Product URL': ProdURL, 'List Price': price, 'Promo Price': promo,
                            'Currency': CurrencyType, 'Retailer ID': RetailerId, 'Category URL': CategoryURL,
                            'Crawling Date': today}
                    DataOut.append(temp)
                except:
                    print('Error in Product')
        elif soup.find('ol', {'class': 'seriesListings'}) is not None:
            container = soup.find('ol', {'class': 'seriesListings'})
            block = container.find_all('li', {'class': 'seriesListings-itemContainer'})
            for li in block:
                try:
                    Name = li.find('h3', {'class': 'seriesListings-title'}).text
                    Manufacturer = ''
                    ProdURL = li.find('h3', {'class': 'seriesListings-title'}).find('a')['href']
                    if ProdURL.index('/') == 0:
                        ProdURL = "https://www.lenovo.com" + ProdURL
                    price = promo = li.find('dd', {'class': 'saleprice pricingSummary-details-final-price'}).text.replace('$', '').replace(',', '')
                    mpn = Itemnumber = ProdURL.split('/')[-1]
                    temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                            'Manufacturer': Manufacturer,
                            'Name': Name, 'Product URL': ProdURL, 'List Price': price, 'Promo Price': promo,
                            'Currency': CurrencyType, 'Retailer ID': RetailerId, 'Category URL': CategoryURL,
                            'Crawling Date': today}
                    DataOut.append(temp)
                    sqldata.append(temp)
                except:
                    print("error in product")
        elif soup.find('ol', {'class': 'accessoriesListing facetsSearchListing'}) is not None:
            container = soup.find('ol', {'class': 'accessoriesListing facetsSearchListing'})
            block = container.find_all('li', {'class': 'accessoriesLists-itemContainer'})
            for li in block:
                try:
                    Name = li.find('h3', {'class': 'qa_product_title'}).find('a').text.strip()
                    namepart = Name.split(" ")
                    Manufacturer = namepart[0]
                    ProdURL = "https://www3.lenovo.com" + li.find('h3', {'class': 'qa_product_title'}).find('a')['href']
                    if li.find('dd', {'itemprop': 'price'}) is not None:
                        promo = price = li.find('dd', {'itemprop': 'price'}).text.replace(',', '').replace('\n', '').replace('\t','').replace('€','').replace('£', '').replace('$', '').strip()
                    else:
                        promo = price = li.find('dd', {'class': 'saleprice'}).text.replace(',', ''). replace('\n', '').replace('\t','').replace('€', '').replace('£', '').replace('$', '').strip()
                    if li.find('input', {'name': 'productCodePost'}) is not None:
                        Itemnumber = li.find('input', {'name': 'productCodePost'})['value']
                    else:
                        IMSplit = ProdURL.split('/')
                        ind = IMSplit.__len__() - 1
                        Itemnumber = IMSplit[ind]
                    mpn = Itemnumber
                    temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn, 'Manufacturer': Manufacturer,
                            'Name': Name, 'Product URL': ProdURL, 'List Price': price, 'Promo Price': promo,
                            'Currency': CurrencyType, 'Retailer ID': RetailerId, 'Category URL': CategoryURL,
                            'Crawling Date': today}
                    DataOut.append(temp)
                    sqldata.append(temp)
                except:
                    print('Error in Product')
                # DataOut.append([LOB, country, site, Itemnumber, mpn, Manufacturer, Name, ProdURL, price, promo, CurrencyType,RetailerId, CategoryURL, today])
    except Exception as e:
        temp = {}
        temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                'Manufacturer': Manufacturer,
                'Name': Name, 'Product URL': ProdURL, 'List Price': price, 'Promo Price': promo,
                'Currency': CurrencyType, 'Retailer ID': RetailerId, 'Category URL': CategoryURL,
                'Crawling Date': today}
        DataOut.append(temp)
        sqldata.append(temp)


def Push_TO_Sql(df):
    ''''add here'''
    connStr = pyodbc.connect('DRIVER={SQL Server};SERVER=ecxus249;DATABASE=SHOPAMD;UID=SHOPAMD;PWD=SHOP@md2010')
    if connStr:
        # print('Connected To SQL Server')
        cursor = connStr.cursor()
        for index, row in df.iterrows():
            try:
                cursor.execute("INSERT INTO dbo.Master_Collation(LOB,Country,Site,Itemnumber,MPN,Manufacturer,ProductName,ProductURL,Listprice,Promoprice,CurrencyType,RetailerID,CategoryURL,Date) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", row['LOB'],row['Country'],row['Site'],row['ItemNumber'],row['MPN'],row['Manufacturer'],row['Name'],row['Product URL'],row['List Price'],row['Promo Price'],row['Currency'],row['Retailer ID'], row['Category URL'],row['Crawling Date'])
            except Exception as e:
                print(e)
        connStr.commit()
        print('Sucessfully Stored Records To DB')
        cursor.close()
        connStr.close()


def result_out_excel(DataOut):
    col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price', 'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']
    dt = str(datetime.date.today())
    filename = site + "_" + dt
    path = "E:\Python\AMD Script\Output\\" +filename+".xlsx"
    df = pd.DataFrame(DataOut, columns=col)
    writer = ExcelWriter(path)
    df.to_excel(writer, 'Sheet1', index=False)
    writer.save()


print("start")
LOB = ''
site = ''
country = ''
CurrencyType = ''
RetailerId = ''
CategoryURL = ''
today = datetime.datetime.today()
excel_to_list()
col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price',
           'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']
for url in input:
    if "lenovo.com/gb" in url:
        if 'page=' in url:
            # url = 'a^https://www3.lenovo.com/us/en/accessories-and-monitors/graphic-cards/graphic-cards/c/Graphic%20Cards_Graphic%20Cards?q=%3Aprice-asc&page=0&'
            print(url)
            indx = url.index('^')
            if indx != 0:
                LOB = url[:indx]
                url = url[indx+1:]
                CategoryURL = url
                splitURL = url.split('/')
                #country = splitURL[3]
                country = "UK"
                #site = splitURL[2].replace('www3.', '').replace('.com', '-') + country
                site ="lenovo-uk"
                RetailerId = "95992"
                CurrencyType = "GBP"
            response = fetch_data(url)
            Pages = int(get_pageno(response))
            for i in range(0, Pages+1):
                len = url.index('page=')
                if len != 0:
                    caturl = url[:len+5] + str(i)
                else:
                    caturl = url
                CatRes = fetch_data(caturl)
                extract_data(CatRes, url, CategoryURL)
        Result_SQL = pd.DataFrame(sqldata, columns=col)
        Push_TO_Sql(Result_SQL)
        sqldata.clear()
result_out_excel(DataOut)
print("Crawling completed Successfully.")
