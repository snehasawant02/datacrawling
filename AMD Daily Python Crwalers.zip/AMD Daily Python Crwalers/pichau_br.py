import pyodbc
import pandas as pd
from tkinter.tix import ResizeHandle
import datetime
import requests
from bs4 import BeautifulSoup
from openpyxl import load_workbook
import xlsxwriter

#sess = requests.session()
headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36',
           'content-type': 'text/html;charset=utf-8',
           'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
           'Host': 'www.pichau.com.br'}
input = []
DataOut = []

def excel_To_List():
    wb= load_workbook(filename='E:\Python\AMD Script\Input.xlsx')
    ws = wb['Sheet4']
    row = ws.max_row
    col=ws.max_column
    for row in ws.iter_rows(min_row=1, min_col=0, max_row=row, max_col=1):
        for cell in row:
            input.append(cell.value)
    wb.close()

def Result_Out_Excel(DataOut):
    dt = str(datetime.date.today());
    filename = "Pichau"+country+"_"+dt
    path = "E:\Python\AMD Script\Output\\" +filename+".xlsx"
    workbook = xlsxwriter.Workbook(path)
    worksheet = workbook.add_worksheet()
    row = 0
    col = 0

    worksheet.write(row, col, "LOB")
    worksheet.write(row, col + 1, "Country")
    worksheet.write(row, col + 2, "Site")
    worksheet.write(row, col + 3, "Item number")
    worksheet.write(row, col + 4, "MPN")
    worksheet.write(row, col + 5, "Manufacturer")
    worksheet.write(row, col + 6, "ProductName")
    worksheet.write(row, col + 7, "ProductURL")
    worksheet.write(row, col + 8, "Listprice")
    worksheet.write(row, col + 9, "Promoprice")
    worksheet.write(row, col + 10, "CurrencyType")
    worksheet.write(row, col + 11, "RetailerId")
    worksheet.write(row, col + 12, "CategoryURL")
    worksheet.write(row, col + 13, "Date")
    row += 1

    for d in DataOut:
        worksheet.write(row, col, d[0])
        worksheet.write(row, col + 1, d[1])
        worksheet.write(row, col + 2, d[2])
        worksheet.write(row, col + 3, d[3])
        worksheet.write(row, col + 4, d[4])
        worksheet.write(row, col + 5, d[5])
        worksheet.write(row, col + 6, d[6])
        worksheet.write(row, col + 7, d[7])
        worksheet.write(row, col + 8, d[8])
        worksheet.write(row, col + 9, d[9])
        worksheet.write(row, col + 10, d[10])
        worksheet.write(row, col + 11, d[11])
        worksheet.write(row, col + 12, d[12])
        worksheet.write(row, col + 13, d[13])
        row += 1
    workbook.close()

def fetch_data(url):
    #proxy = {'https': 'https://11115:7My2Ng@world.nohodo.com:6811'}
    # proxy = {'https': 'https://162.248.6.107:80'}
    res = ''
    proxy = {'https': 'https://eclerxamd:Rid8B67I2Q@shp-prx109-us-v00007.tp-ns.com:80'}
    try:
        res = requests.get(url, proxies=proxy).text
    except Exception as e:
        print("type error: " + str(e))
    return res

def get_PageNo(res):
    soup = BeautifulSoup(res, 'lxml')
    try:
        Pages=soup.find('span', {'class':'text-page last'}).text
        # Pages=Pages.replace("Página 1 de", "").strip()
        print(Pages)
    except Exception as e:
        Pages = 1
    return Pages

def Extract_data(res, url):
    # soup = BeautifulSoup(res, 'lxml')
    # #today = datetime.datamlabel-product-price-etime.today()
    # today = datetime.datetime.today()
    # try:
    #     container = soup.find('div', {'class': 'products wrapper grid products-grid'})
    #     liBlock=container.find_all('li', {'class': 'item product product-item'})
    #     #liBlock=container.find('h4', {'class': 'clearfix linha-produtos'})
    #     for li in liBlock:
    #
    #             Name = li.find('a', {'class': 'product-item-link'}).text.replace('\n','').strip()
    #
    #             if li.find('div', {'class': 'price-final_price'})['data-product-id'] is not None:
    #                 mpn = Itemnumber = li.find('div', {'class': 'price-final_price'})['data-product-id']
    #                 # print(mpn)
    #             else:
    #                 mpn = Itemnumber = str("MPN not available")
    #             ProdURL = li.find('strong', {'class': 'product-item-name'}).find('a')['href']
    #             temp_manufacturer = ProdURL.split('-')
    #             Manufacturer = temp_manufacturer[1]
    #             if Manufacturer == 'de':
    #                 Manufacturer = temp_manufacturer[3]
    #             elif Manufacturer == 'm':
    #                 Manufacturer = 'mae'
    #             elif Manufacturer == 'os':
    #                 Manufacturer = temp_manufacturer[0]
    #
    #             # print(Manufacturer)
    #             PP = li.find('span', {'class': 'price-boleto'}).text
    #             if PP is not None:
    #                 promo = price = PP.replace("à vista R$",'').replace(' no boleto com 12% de desconto','').replace('.','').replace(",", ".").replace('\n','')
    #             else:
    #                 promo = price = "check for price"
    #             DataOut.append([LOB, country, site, Itemnumber, mpn, Manufacturer, Name, ProdURL, price, promo, CurrencyType, RetailerId, CategoryURL, today])
    #
    # except Exception as e:
    #     print(Name)
    #     DataOut.append([LOB, country, site, '', '', '', '', '', '', '', CurrencyType, RetailerId, CategoryURL, today])

    Itemnumber = ''
    mpn = ''
    Manufacturer = ''
    Name = ''
    ProdURL = ''
    price = ''
    promo = ''
    today = str(datetime.datetime.now()).split(".")[0]
    soup = BeautifulSoup(res, 'lxml')


    try:
        container = soup.find('main', {'id': 'maincontent'})
        liBlock = container.find_all('li', {'class': 'item product product-item'})
        for li in liBlock:
            try:
                Name = li.find('a', {'class': 'product-item-link'}).text.replace('\n', '').strip()

                # try:
                if li.find('div', {'class': 'price-box price-final_price'}) is not None:
                    mpn = Itemnumber = 'ecx_'+ li.find('div', {'class': 'price-box price-final_price'})['data-product-id']
                                # print(mpn)
                # except:
                else:
                    pass
                    # mpn = Itemnumber = ''
                ProdURL = li.find('strong', {'class': 'product name product-item-name'}).find('a')['href']
                temp_manufacturer = ProdURL.split('-')
                Manufacturer = temp_manufacturer[1]
                if Manufacturer == 'de':
                    Manufacturer = temp_manufacturer[3]
                elif Manufacturer == 'm':
                    Manufacturer = 'mae'
                elif Manufacturer == 'os':
                    Manufacturer = temp_manufacturer[0]
                PP = li.find('span', {'class': 'price-boleto'})
                if PP is not None:
                    PP = PP.text
                    promo = price = PP.replace("à vista R$",'').replace(' no boleto com 12% de desconto','').replace('.','').replace(",", ".").replace('\n','')
                else:
                    pass
                    # promo = price = "check for price"

                temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                        'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                        'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                        'Category URL': url, 'Crawling Date': today}
                if Itemnumber != '':
                    DataOut.append(temp)
                    # Sqldataout.append(temp)

            except Exception as e:
                print(Name)
                print('error in Product')

    except Exception as e:
        temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
            'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
            'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
            'Category URL': url, 'Crawling Date': today}



        DataOut.append(temp)
        # Sqldataout.append(temp)
    return DataOut


def Push_TO_Sql(df):
    ''''add here'''
    connStr = pyodbc.connect('DRIVER={SQL Server};SERVER=ecxus249;DATABASE=SHOPAMD;UID=SHOPAMD;PWD=SHOP@md2010')
    if connStr:
        # print('Connected To SQL Server')
        cursor = connStr.cursor()
        for index, row in df.iterrows():
            try:
                cursor.execute("INSERT INTO dbo.Master_Collation(LOB,Country,Site,Itemnumber,MPN,Manufacturer,ProductName,ProductURL,Listprice,Promoprice,CurrencyType,RetailerID, CategoryURL, Date) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", row['LOB'],row['Country'],row['Site'],row['ItemNumber'],row['MPN'],row['Manufacturer'],row['Name'],row['Product URL'],row['List Price'],row['Promo Price'],row['Currency'],row['Retailer ID'], row['Category URL'],row['Crawling Date'])
            except Exception as e:
                print("String SQL", e)
        connStr.commit()
        print('Sucessfully Stored Records To DB')
        cursor.close()
        connStr.close()


def result_out_excel(DataOut):
    col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price', 'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']
    dt = str(datetime.date.today())
    filename = site + "_" + dt
    path = "E:\Python\AMD Script\Output\\" +filename+".xlsx"
    df = pd.DataFrame(DataOut, columns=col)
    writer = pd.ExcelWriter(path, engine='xlsxwriter', options={'strings_to_urls': False})
    df.to_excel(writer, 'Sheet1', index=False)
    writer.save()


print("start")
LOB = ''
site = ''
country = ''
CurrencyType = ''
RetailerId = ''
CategoryURL = ''
excel_To_List()
col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price',
           'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']
for url in input:
    if "pichau.com" in url:
        url = url.replace("http:", "https:")
        url = url.split('&p=')
        url = url[0]
        url = url + "&p="
        print(url)
        indx = url.index('^')
        if indx != 0:
            LOB = url[:indx]
            url = url[indx+1:]
            CategoryURL = url
            splitURL = url.split('/')
            Con = splitURL[2].split('.')
            country = Con[3].upper()
            site = splitURL[2].replace('www.', '').replace(".com", "").replace('.', '-')
            if country == 'BR':
                RetailerId = '96023'
                country = "Brazil"
                CurrencyType = 'BRL'
        response = fetch_data(url)
        Pages = int(get_PageNo(response))
        for i in range(1, Pages+1):
            len = url.index('p=')
            caturl = url[:len+5] + str(i)
            print(caturl)
            CatRes = fetch_data(caturl)
            Extract_data(CatRes, url)
            Result_SQL = pd.DataFrame(DataOut, columns=col)
            Push_TO_Sql(Result_SQL)
        result_out_excel(DataOut)
