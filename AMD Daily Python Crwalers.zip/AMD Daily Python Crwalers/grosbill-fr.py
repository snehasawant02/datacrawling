import time
from pandas import ExcelWriter
import pandas as pd
from openpyxl import load_workbook
import pyodbc
import datetime
import requests
from pandas.io.json import json_normalize
import os
from bs4 import BeautifulSoup as bss

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import json



input=[]
DataOut=[]
sqldata=[]

sess = requests.session()
sess.headers = ({
    'Connection': 'keep-alive',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36',
    'Upgrade-Insecure-Requests': '1',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-GB,en;q=0.9,en-US;q=0.8,hi;q=0.7'})


def excel_To_List():
    wb = load_workbook(filename='E:\Python\AMD Script\Input.xlsx')
    # wb = load_workbook(filename='E:\Python\AMD Script\Input.xlsx')
    ws = wb['Sheet1']
    row = ws.max_row
    col = ws.max_column
    for row in ws.iter_rows(min_row=1, min_col=0, max_row=row, max_col=1):
        for cell in row:
            if cell.value is not None and "grosbill" in cell.value:
                input.append(cell.value)
    wb.close()


def fetch_data(url):
    res = ''
    proxy = {'https': 'https://eclerxamd:Rid8B67I2Q@shp-prx109-fr-v00001.tp-ns.com:80'}
    try:
        res = requests.get(url, proxies=proxy).text
        # driver.get(url)
    except Exception as e:
        print("type error: " + str(e))
    return res

# def selenium_pagging(url):
#     chromedriver = "chromedriver.exe"
#     os.environ["webdriver.chrome.driver"] = chromedriver
#
#     options=Options()
#     options.add_argument('--headless')
#     driver = webdriver.Chrome(chromedriver,chrome_options=options)
#     driver.get(url)
#     time.sleep(3)
#
#     Stop=True
#     while Stop:
#
#         try:
#             time.sleep(2)
#             driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
#             Next=driver.find_element_by_class_name("ias-button")
#             Next.click()
#         except Exception as E:
#             Stop=False
#     res = driver.page_source
#     Extract_data(res, driver.current_url)
#     driver.quit()


def get_PageNo(res):
    soup = bss(res, 'lxml')


    try:
        if soup.find('td',{'style': 'width:auto'}).text.replace('\n','').replace('\t','').split(' ')[-2] is not None:
            Pages = int(soup.find('td',{'style': 'width:auto'}).text.replace('\n','').replace('\t','').split(' ')[-2])
            # print(Pages)
            # soup.find('div', {'class': 'col-sm-6 text-right results'}).text.split('(')[1].replace(' Pages)', ''))
            if Pages is not None:
                Pages = Pages
        else:
            Pages = 1
    except Exception as e:
        Pages = 1
    return Pages




def Extract_data(res, url):
    Itemnumber = ''
    mpn = ''
    Manufacturer = ''
    Name = ''
    ProdURL = ''
    price = ''
    promo = ''
    today = str(datetime.datetime.now()).split(".")[0]
    soup = bss(res, 'lxml')
    try:
        container= soup.find('table', {'id': 'listing_mode_display'})
        items = container.find_all('tr')
        for li in items:
            try:
                Name = li.find('h2').text
                #print(Name)
                ProdURL = 'https://www.grosbill.com' + li.find('h2', {'style': 'font-size: 12px;'}).find('a')['href']
                # print(ProdURL)
                # price = li.find('p', {'class': 'price'}).text.replace('Rs.','')
                # print(price)
                try:
                    Desc = li.find('div', {'class': 'product_description'}).text.replace("\n", " ").strip()
                    Name=Name+'^^'+Desc
                except:
                    pass
                Manufacturer = li.find('h2', {'style': 'font-size: 12px;'}).text.split(' ')[0]
                # print(Manufacturer)

                if li.find('input', {'class': 'input_checkbox'})['value'] is not None:
                    mpn = Itemnumber = li.find('input', {'class': 'input_checkbox'})['value']
                    # print(Itemnumber)
                try:
                    if li.find('td', {'class': 'btn_price_wrapper'}) is not None:
                        promo = price = li.find('td', {'class': 'btn_price_wrapper'}).text.replace('\n','').replace('\t','').split('€')[-2]
                        # print(promo)
                except:
                    pass
                temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                        'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                        'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                        'Category URL': url, 'Crawling Date': today}
                DataOut.append(temp)
                sqldata.append(temp)
            except Exception as e:
                #print(Name)
                print('error in Product')
    except Exception as e:
        temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                'Category URL': url, 'Crawling Date': today}
        DataOut.append(temp)
        sqldata.append(temp)



def Push_TO_Sql(df):
    ''''add here'''
    connStr = pyodbc.connect('DRIVER={SQL Server};SERVER=ecxus249;DATABASE=SHOPAMD;UID=SHOPAMD;PWD=SHOP@md2010')
    if connStr:
        # print('Connected To SQL Server')
        cursor = connStr.cursor()
        for index,row in df.iterrows():
            try:
                cursor.execute("INSERT INTO dbo.Master_Collation(LOB,Country,Site,Itemnumber,MPN,Manufacturer,ProductName,ProductURL,Listprice,Promoprice,CurrencyType,RetailerID,Date) values(?,?,?,?,?,?,?,?,?,?,?,?,?)", row['LOB'],row['Country'],row['Site'],row['ItemNumber'],row['MPN'],row['Manufacturer'],row['Name'],row['Product URL'],row['List Price'],row['Promo Price'],row['Currency'],row['Retailer ID'],row['Crawling Date'])
            except Exception as e:
                print(e)
        connStr.commit()
        print('Sucessfully Stored Records To DB')
        cursor.close()
        connStr.close()


def Result_Out_Excel(DataOut):
    col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price',
           'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']

    dt = str(datetime.date.today())
    filename = "grosbill-fr_" + dt
    path = "E:\Python\AMD Script\Output\\" + filename + ".xlsx"
    # path = "E:\SAYAR PROJECTS\PYTHON\AMD_CNCT\Output\\" + filename + ".xlsx"
    df = pd.DataFrame(DataOut, columns=col)
    writer = pd.ExcelWriter(path, engine='xlsxwriter', options={'strings_to_urls': False})
    df.to_excel(writer, 'Sheet1', index=False)
    writer.save()
    return df


print("start")
LOB = ''
site = ''
country = ''
CurrencyType = ''
RetailerId = ''
CategoryURL = ''
excel_To_List()
col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price',
           'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']

for url in input:
    print(url)
    indx = url.index('^')
    if indx != 0:
        LOB = url[:indx]
        url = url[indx+1:]
        CategoryURL = url
        splitURL = url.split('/')
        country = 'fr'
        site = 'grosbill-fr'
        if country == 'fr':
            RetailerId = '95976'
            country = "France"
            CurrencyType = 'EURO'
        endpart = splitURL[-1].split('?')
    response = fetch_data(url)
    Pages = int(get_PageNo(response))
    for i in range(1, Pages+1):
        URL=url.split('page=')
        caturl =URL[0]+'page=' + str(i)+'&tri=w&filtre_page=50'
        CatRes = fetch_data(caturl)
        print(caturl)
        Extract_data(CatRes, url)
        Result_SQL = pd.DataFrame(sqldata, columns=col)
        Push_TO_Sql(Result_SQL)
        sqldata.clear()
    # # selenium_pagging(url)
    Result_Out_Excel(DataOut)
print('Completed')