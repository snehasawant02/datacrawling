from pandas import ExcelWriter
import pandas as pd
from openpyxl import load_workbook
import pyodbc
import datetime
import requests
from pandas.io.json import json_normalize
import os
import re
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import json
import time

chromedriver = "E:\Python\AMD Daily Python Crwalers\chromedriver.exe"
os.environ["webdriver.chrome.driver"] = chromedriver

options = Options()
options.add_argument('--headless')
options.add_argument('--disable-gpu')  # Last I checked this was necessary.

driver = webdriver.Chrome(chromedriver,chrome_options=options)

input=[]
DataOut=[]
sqldata=[]


sess = requests.session()
sess.headers = ({
    'Connection': 'keep-alive',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36',
    'Upgrade-Insecure-Requests': '1',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-GB,en;q=0.9,en-US;q=0.8,hi;q=0.7'})


def excel_To_List():
    # wb = load_workbook(filename='E:\Python\AMD Script\Hemant Test\InputHK.xlsx')
    wb = load_workbook(filename='E:\Python\AMD Script\Input.xlsx')
    ws = wb['Sheet1']
    row = ws.max_row
    col = ws.max_column
    for row in ws.iter_rows(min_row=1, min_col=0, max_row=row, max_col=1):
        for cell in row:
            if cell.value is not None and "inet.se" in cell.value:
                input.append(cell.value)
    wb.close()


def fetch_data(url):
    res = ''
    # proxy = {'https': 'https://eclerxamd:Rid8B67I2Q@shp-prx109-us-v00007.tp-ns.com:80'}
    SCROLL_PAUSE_TIME = 0.5
    try:
        driver.get(url)
        # Get scroll height
        last_height = driver.execute_script("return document.body.scrollHeight")
        while True:
            # Scroll down to bottom
            driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            # Wait to load page
            time.sleep(SCROLL_PAUSE_TIME)
            # Calculate new scroll height and compare with last scroll height
            new_height = driver.execute_script("return document.body.scrollHeight")
            if new_height == last_height:
                break
            last_height = new_height
    except Exception as e:
        print("type error: " + str(e))
    return driver.page_source


def get_PageNo(res):
    soup = BeautifulSoup(res, 'lxml')
    # cont = soup.find('section', {'class': 'category-page'})
    try:
        if soup.find("div", {'class': 'filter-footer'}) is not None:
            Products = soup.find("div", {'class': 'filter-footer'}).text
            m = re.search(r'\d+', Products)
            Products = m.group()
            Pages1 = int(Products) / 10
            if int(Pages1) >=1 :
                Pages = Pages1
            else:
                Pages = 1

    except Exception as e:
        Pages = 1
    return Pages

def Extract_data(res, url):
    Itemnumber = ''
    mpn = ''
    Manufacturer = ''
    Name = ''
    ProdURL = ''
    price = ''
    promo = ''
    today = str(datetime.datetime.now()).split(".")[0]
    soup = BeautifulSoup(res, 'lxml')
    try:
        container = soup.find('div', {'class': 'product-list'})
        items = container.find_all('div', {'class': 'description'})
        for li in items:
            try:
                Name = li.find('h4').text
                try:
                    Desc = li.find('p', {'class': 'key-text'}).text.replace("\n", " ").strip()
                    Name=Name+'^^'+Desc
                except:
                    pass
                Manufacturer = Name.split(' ')[0]
                ProdURL = 'https://www.inet.se' + li.find('a')['href']
                mpn = Itemnumber = ProdURL.split('/')[4]
                if li.find('div', {'class': 'price-buy-compare'}) is not None:
                    promo = price = li.find('div', {'class': 'price-buy-compare'}).text.split('kr')[0].replace(' ', '').replace('kr', '').replace('Nu', '').strip()
                # elif li.find('span', {'class': 'campaign-price'}) is not None:
                #     promo = price = li.find('span', {'class': 'campaign-price'}).text.replace(' ', '').replace('kr', '').replace('Nu', '').strip()
                # else:
                #     promo = price = "Check For Price"
                temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                        'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                        'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                        'Category URL': url, 'Crawling Date': today}
                DataOut.append(temp)
                sqldata.append(temp)
            except Exception as e:
                print('error in Product')
    except Exception as e:
        temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                'Category URL': url, 'Crawling Date': today}
        DataOut.append(temp)
        sqldata.append(temp)
    return DataOut


def Push_TO_Sql(df):
    ''''add here'''
    connStr = pyodbc.connect('DRIVER={SQL Server};SERVER=ecxus249;DATABASE=SHOPAMD;UID=SHOPAMD;PWD=SHOP@md2010')
    if connStr:
        # print('Connected To SQL Server')
        cursor = connStr.cursor()
        for index, row in df.iterrows():
            try:
                cursor.execute("INSERT INTO dbo.Master_Collation(LOB,Country,Site,Itemnumber,MPN,Manufacturer,ProductName,ProductURL,Listprice,Promoprice,CurrencyType,RetailerID,Date) values(?,?,?,?,?,?,?,?,?,?,?,?,?)", row['LOB'],row['Country'],row['Site'],row['ItemNumber'],row['MPN'],row['Manufacturer'],row['Name'],row['Product URL'],row['List Price'],row['Promo Price'],row['Currency'],row['Retailer ID'],row['Crawling Date'])
            except Exception as e:
                print(e)
        connStr.commit()
        print('Sucessfully Stored Records To DB')
        cursor.close()
        connStr.close()


def Result_Out_Excel(DataOut):
    col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price',
           'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']

    dt = str(datetime.date.today())
    filename = "inet_se_" + dt
    path = "E:\Python\AMD Script\Output\\" + filename + ".xlsx"
    df = pd.DataFrame(DataOut, columns=col)
    writer = ExcelWriter(path)
    df.to_excel(writer, 'Sheet1', index=False)
    writer.save()
    return df


print("start")
LOB = ''
site = ''
country = ''
CurrencyType = ''
RetailerId = ''
CategoryURL = ''
excel_To_List()
col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price',
           'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']

for url in input:
    print(url)
    indx = url.index('^')
    if indx != 0:
        LOB = url[:indx]
        url = url[indx+1:]
        CategoryURL = url
        splitURL = url.split('/')
        country = 'se'
        site = splitURL[2].replace('www.', '').replace('.', '-')
        if country == 'se':
            RetailerId = '96007'
            country = "Sweden"
            CurrencyType = 'SEK'
    response = fetch_data(url)
    Pages = int(get_PageNo(response))
    for i in range(1, Pages+1):
        caturl = url.replace('page=1', 'page=%s'%i)
        print(caturl)
        CatRes = fetch_data(caturl)
        Extract_data(CatRes, url)
        # if Pages > 1:
        #     caturl = url
        # else:
        #     caturl = url
        # CatRes = fetch_data(caturl)
        # Extract_data(response, caturl)
        # try:
        #     CatRes = driver.find_element_by_class_name('btn-blue btn-show-more btn btn-default')
        #     CatRes.click()
        #     time.sleep(3)
        # except Exception as NoSuchElementException:
        #     break
        #     print("No element found")
        Result_SQL = pd.DataFrame(sqldata, columns=col)
        Push_TO_Sql(Result_SQL)
        sqldata.clear()
        Result_Out_Excel(DataOut)
print('Completed')