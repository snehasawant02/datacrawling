from pandas import ExcelWriter
import pandas as pd
from openpyxl import load_workbook
import pyodbc
import datetime
import requests
from pandas.io.json import json_normalize
import os
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import json
import time


chromedriver = "chromedriver.exe"
os.environ["webdriver.chrome.driver"] = chromedriver

options = Options()
# options.add_argument('--headless')

options.add_argument('--disable-gpu')  # Last I checked this was necessary.

driver = webdriver.Chrome(chromedriver,chrome_options=options)

input=[]
DataOut=[]
sqldata=[]



def excel_To_List():
    # wb = load_workbook(filename='E:\Prasad\dell.xlsx')
    wb = load_workbook(filename='E:\Python\AMD Script\Input.xlsx')
    ws = wb['Sheet1']
    row = ws.max_row
    col =ws.max_column
    for row in ws.iter_rows(min_row=1, min_col=0, max_row=row, max_col=1):
        for cell in row:
            if cell.value is not None and "dell.com" in cell.value:
                input.append(cell.value)
    wb.close()


def fetch_data(url):
    res = ''
    # proxy = {'https': 'https://eclerxamd:Rid8B67I2Q@shp-prx109-us-v00002.tp-ns.com:80'}
    #proxy = {'https':'https://csimonra:h19VA2xZ@104.144.109.87:29842'}
    try:
        driver.get(url)

        time.sleep(2)
        if 'pilot.search' not in url:
            while driver.find_element_by_class_name('load-more-button') is not None:
                check = driver.find_element_by_class_name('load-more-button').text

            # while 'display: block;' in driver.find_element_by_class_name('load-more-button').get_attribute('style'):
            #     if driver.find_element_by_class_name('load-more-button') is not None:
                if check == '':
                    break
                else:
                    el = driver.find_element_by_class_name('load-more-button')
                    webdriver.ActionChains(driver).move_to_element(el).click(el).perform()
                    time.sleep(4)
        else:
            try:
                driver.get(url)
                time.sleep(2)
                i = 0
                while driver.find_element_by_xpath("//div[@class='text-center']//button[@class='btn btn-default']") is not None:
                    check = driver.find_element_by_xpath("//div[@class='text-center']//button[@class='btn btn-default']").text
                    if check == '':
                        break
                    else:
                        if i <= 6:
                            el = driver.find_element_by_xpath("//div[@class='text-center']//button[@class='btn btn-default']")
                            webdriver.ActionChains(driver).move_to_element(el).click(el).perform()
                            time.sleep(2)
            except:
                print('Error in Product')

    except Exception as e:
        print('No Pagination Available')

    return driver.page_source


def get_pageno(res):
    soup = BeautifulSoup(res, 'lxml')
    products = ''
    Pages = 1
    # try:
    #     if soup.find("span", {'class': 'resultsCount'}) is not None:
    #         products = int(soup.find("span", {'class': 'resultsCount'}).text)
    #         if products is not "":
    #             Pages = products // 12
    #             if products % 12 > 0:
    #                 Pages += 1
    #         else:
    #             Pages = 1
    # except Exception as e:
    #     Pages = 1
    return Pages


def Extract_data(res, url):
    Itemnumber = ''
    mpn = ''
    Manufacturer = ''
    Name = ''
    ProdURL = ''
    price = ''
    promo = ''
    today = str(datetime.datetime.now()).split(".")[0]
    res = res.replace('\&quot;', '').replace('\n', '').replace('\r', '').replace('\t', '')
    # soup = BeautifulSoup(res, 'lxml')
    if 'pilot.search' not in url:
        try:
            # container = driver.find_element_by_id('//*[@id="ProductStackContainer"]')
            name_container = driver.find_elements_by_xpath("//span[@data-testid='configItemProductTitle']")
            purl_container = driver.find_elements_by_xpath("//a[@class='btn chat-btn text-white col-xs-12 bottom-offset-10 whitespace-normal btn-success dellmetrics-dclickthru']")
            price_container = driver.find_elements_by_xpath("//strong[@data-testid='psDellPrice']")
            i = 0
            for li in name_container and purl_container and price_container:
                try:
                    while i <= len(name_container):
                        i = i + 1
                        if name_container[i].text is not None:
                            Name = name_container[i].text
                        else:
                            Name = "Name not available"
                        # print(Name)
                        if purl_container[i].get_attribute('href') is not None:
                            ProdURL = purl_container[i].get_attribute('href')
                        else:
                            ProdURL = 'No Product URL'
                        # print('test')
                        # print(ProdURL)
                        if price_container[i].text is not None:
                            promo = price = price_container[i].text.replace('$','').replace(',','')
                        else:
                            promo = price = "Price not Available"
                        # print(price)
                        Manufacturer = 'Dell'
                        # print(Manufacturer)
                        try:
                            mpn = Itemnumber = ProdURL.split('/')[-1]
                        except:
                            mpn = Itemnumber = "MPN not Available"
                        # print(mpn)

                        temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                                'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                                'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                                'Category URL': url, 'Crawling Date': today}
                        DataOut.append(temp)
                        sqldata.append(temp)


                except Exception as e:
                    print(Name)
                    print('error in Product')
        except Exception as e:
            temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                    'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                    'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                    'Category URL': url, 'Crawling Date': today}
            DataOut.append(temp)
            sqldata.append(temp)
    else:
        try:
            # container = driver.find_element_by_id('results')
            name_container = driver.find_elements_by_xpath("//a[@class='dellmetrics-tclickthru cft-title']")
            purl_container = driver.find_elements_by_xpath("//a[@class='dellmetrics-tclickthru cft-title']")
            price_container = driver.find_elements_by_xpath("//Span[@class='mobile-price']")
            i = 0
            for m in name_container and purl_container and price_container:
                try:
                    while i <= len(name_container):
                        Name = name_container[i].text
                        # print(Name)
                        ProdURL = purl_container[i].get_attribute('href')
                        # print('test')
                        # print(ProdURL)
                        promo = price = price_container[i].text.replace('$', '').replace(',', '')
                        # print(price)
                        Manufacturer = 'Dell'
                        # print(Manufacturer)
                        mpn = Itemnumber = ProdURL.split('/')[-1]
                        # print(mpn)

                        temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                                'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                                'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                                'Category URL': url, 'Crawling Date': today}
                        DataOut.append(temp)
                        sqldata.append(temp)
                        i = i+1

                except Exception as e:
                    # print(Name)
                    print('Ignoring Out of Stock Product')
        except Exception as e:
            temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                    'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                    'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                    'Category URL': url, 'Crawling Date': today}
            DataOut.append(temp)
            sqldata.append(temp)
    return DataOut


def Push_TO_Sql(df):
    ''''add here'''
    connStr = pyodbc.connect('DRIVER={SQL Server};SERVER=ecxus249;DATABASE=SHOPAMD;UID=SHOPAMD;PWD=SHOP@md2010')
    if connStr:
        # print('Connected To SQL Server')
        cursor = connStr.cursor()
        for index, row in df.iterrows():
            try:
                cursor.execute(
                    "INSERT INTO dbo.Master_Collation(LOB,Country,Site,Itemnumber,MPN,Manufacturer,ProductName,ProductURL,Listprice,Promoprice,CurrencyType,RetailerID,CategoryURL,Date) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",row['LOB'], row['Country'], row['Site'], row['ItemNumber'], row['MPN'], row['Manufacturer'],row['Name'], row['Product URL'], row['List Price'], row['Promo Price'], row['Currency'],row['Retailer ID'], row['Category URL'], row['Crawling Date'])
            except Exception as e:
                print(e)
        connStr.commit()
        print('Sucessfully Stored Records To DB')
        cursor.close()
        connStr.close()


def Result_Out_Excel(DataOut):
    col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price',
           'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']

    dt = str(datetime.date.today())
    filename = "Dell_US_" + dt
    path = "E:\Python\AMD Script\Output\\" + filename + ".xlsx"
    df = pd.DataFrame(DataOut, columns=col)
    writer = ExcelWriter(path)
    df.to_excel(writer, 'Sheet1', index=False)
    writer.save()
    return df


print("start")
LOB = ''
site = ''
country = ''
CurrencyType = ''
RetailerId = ''
CategoryURL = ''
excel_To_List()
col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price',
           'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']

for url in input:
    print(url)
    indx = url.index('^')
    if indx != 0:
        LOB = url[:indx]
        url = url[indx+1:]
        CategoryURL = url
        splitURL = url.split('/')
        country = 'us'
        site = splitURL[2].replace('www.', '').replace('.com', '-') + country
        if "pilot.search." in site:
            site = site.split('.search.')
            site = site[1]
        if country == 'us':
            RetailerId = '96003'
            country = "US"
            CurrencyType = 'USD'
        endpart = splitURL[-1].split('?')
    if LOB == 'Server':
        response = fetch_data(url)
        Extract_data(response, url)
        Result_SQL = pd.DataFrame(DataOut, columns=col)
        Push_TO_Sql(Result_SQL)
        Result_Out_Excel(DataOut)
    else:
        # response = fetch_data(url)
        Pages = 1
        for i in range(1, Pages+1):
            if "appliedRefinements" in url:
                # caturl = "https://www.dell.com/csbapi/en-us/anavfilter/GetSystemsResults?categorypath=all-products/" + endpart[0] + "&sortby=price-ascending&" + endpart[1] + "&page=" + str(i) + "&categoryid=" + endpart[0]
                caturl = url
            else:
                # caturl = "https://www.dell.com/csbapi/en-us/category/deals/" + endpart[-1] + "?sortby=sort-relevance&page=" + str(i)
                # caturl = 'https://www.dell.com/csbapi/en-us/anavfilter/GetSystemsResults?categorypath=all-products/desktops-n-workstations&sortby=price-ascending&appliedRefinements=2985,10696&page=1&categoryid=desktops-n-workstations'
                caturl = url
            CatRes = fetch_data(caturl)
            Extract_data(CatRes, url)
            Result_SQL = pd.DataFrame(sqldata, columns=col)
            Push_TO_Sql(Result_SQL)
            sqldata.clear()
            Result_Out_Excel(DataOut)
driver.close()
print('Completed')


