import datetime
from openpyxl import load_workbook
import pyodbc
import pandas as pd
import os
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from pandas import ExcelWriter
import re

#chromedriver = "E:\Prasad\chromedriver.exe"
chromedriver = "E:\Python\AMD Daily Python Crwalers\chromedriver.exe"
os.environ["webdriver.chrome.driver"] = chromedriver

options = Options()
# options.add_argument('--headless')
options.add_argument('--disable-gpu')  # Last I checked this was necessary.

driver = webdriver.Chrome(chromedriver, chrome_options=options)
driver.set_page_load_timeout(120)


#proxy = {'https': 'https://eclerxusa:WonderS1979@london.wonderproxy.com:80'}
headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36',
           'content-type': 'text/html;charset=utf-8',
           'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8'}

input = []
DataOut = []
sqldata=[]


def excel_To_List():
    wb= load_workbook(filename='E:\Python\AMD Script\Input.xlsx')
    ws = wb['Sheet1']
    row = ws.max_row
    col=ws.max_column
    for row in ws.iter_rows(min_row=1, min_col=0, max_row=row, max_col=1):
        for cell in row:
            if cell.value is not None and "fnac.com" in cell.value:
                input.append(cell.value)
    wb.close()

def result_out_excel(DataOut):
    col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price','Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']
    dt = str(datetime.date.today())
    filename = site + "_" + dt
    path = "E:\Python\AMD Script\Output\\" +filename+".xlsx"
    df = pd.DataFrame(DataOut, columns=col)
    writer = pd.ExcelWriter(path, engine='xlsxwriter', options={'strings_to_urls': False})
    df.to_excel(writer, 'Sheet1', index=False)
    writer.save()
    writer.close()

def fetch_data(url):
    res = ''
    proxy = {'https': 'https://eclerxamd:Rid8B67I2Q@shp-prx109-fr-v00001.tp-ns.com:80'}
    #proxy= {'https': 'https://162.248.6.107:80'}
    try:
        driver.get(url)
        # try:
        #     driver.find_element_by_xpath('/html/body/div[2]/div/div/div/div[1]/div[2]/a[2]').click()
        # except:
        #     pass
        # res = requests.get(url, proxies=proxy).text
    except Exception as e:
        print("type error: " + str(e))
    return driver.page_source


def get_PageNo(res):
    soup = BeautifulSoup(res, 'lxml')
    products = ''
    try:
        # if soup.find("div", {'class': 'actions-toolbar'}) is not None:
        Product = int(soup.find("span", {'class': 'Search-titleCount js-Search-titleCount'}).text.replace("\n", "").replace('(','').replace(')',''))
        pages1 = int(Product) / 20
        pages2 = int(pages1)
        if int(pages2) >= 1:
            Pages = pages2
        else:
            Pages = 1

    except Exception as e:
        Pages = 1
    return Pages


def Extract_data(res, url):
    Itemnumber = ''
    mpn = ''
    Manufacturer = ''
    Name = ''
    ProdURL = ''
    price = ''
    promo = ''
    today = str(datetime.datetime.now()).split(".")[0]
    soup = BeautifulSoup(res, 'lxml')
    try:
        if soup.find("div", {"class": 'Article f-search__main'}) is not None:
            container = soup.find("div", {"class": 'articleList Article-list'})
            block = container.find_all("div", {"class": "clearfix Article-item js-Search-hashLinkId"})
            for li in block:
                try:
                    Name = li.find('p', {'class': 'Article-desc'}).text.strip()
                    namesplit = Name.split(' ')
                    Manufacturer = namesplit[1]
                    ProdURL = li.find('p', {'class': 'Article-desc'}).find('a')['href']
                    if li.find('span', {'class': 'price red'}) is not None:
                        sup = int(li.find('em', {'class': 'tax'}).text.replace('€',''))
                        if sup == "":
                            promo = price = li.find('span', {'class': 'price red'}).text.replace('€', '.').replace('\n','').strip() + '00'
                        elif sup > 1:
                            promo = price = li.find('span', {'class': 'price red'}).text.replace('€','.').replace('\n','').strip()
                        else:
                            promo = price = li.find('span', {'class': 'price red'}).text.replace('€', '.').replace('\n','').strip() + '00'
                        # print(price)
                    elif li.find('a', {'class': 'userPrice'}) is not None:
                        sup = int(li.find('a', {'class': 'userPrice'}).find('sup').text.replace('€', ''))
                        if sup == "":
                            promo = price = li.find('a', {'class': 'userPrice'}).text.replace('€', '.').replace('\n','').strip() + '00'
                        elif sup > 1:
                            promo = price = li.find('a', {'class': 'userPrice'}).text.replace('€', '.').replace('\n','').strip()
                        else:
                            promo = price = li.find('a', {'class': 'userPrice'}).text.replace('€', '.').replace('\n', '').strip() + '00'
                        # print(price)
                    elif li.find('strong', {'class': 'userPrice'}) is not None:
                        sup = int(li.find('strong', {'class': 'userPrice'}).find('sup').text.replace('€',''))
                        if sup == "":
                            promo = price = li.find('strong', {'class': 'userPrice'}).text.replace('€', '.').replace('\n', '').strip() + '00'
                        elif sup > 1:
                            promo = price = li.find('strong', {'class': 'userPrice'}).text.replace('€', '.').replace('\n','').strip()
                        else:
                            promo = price = li.find('strong', {'class': 'userPrice'}).text.replace('€', '.').replace('\n','').strip() + '00'
                    else:
                        promo = price = 'Check for Price'
                    Itemnumber = li.find("div", {"class": "js-ProductBuy"})['data-product-id']
                    mpn = Itemnumber
                    temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                            'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                            'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                            'Category URL': url, 'Crawling Date': today}
                    DataOut.append(temp)
                    sqldata.append(temp)

                except Exception as E:
                    print("Out of stock product excluded")
    except Exception as e:
        temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                'Category URL': url, 'Crawling Date': today}
        print("Error in page")
        DataOut.append(temp)
        sqldata.append(temp)


def Push_TO_Sql(df):
    ''''add here'''
    connStr = pyodbc.connect('DRIVER={SQL Server};SERVER=ecxus249;DATABASE=SHOPAMD;UID=SHOPAMD;PWD=SHOP@md2010')
    if connStr:
        # print('Connected To SQL Server')
        cursor = connStr.cursor()
        for index, row in df.iterrows():
            try:
                cursor.execute("INSERT INTO dbo.Master_Collation(LOB,Country,Site, CategoryURL,Itemnumber,MPN,Manufacturer,ProductName,ProductURL,Listprice,Promoprice,CurrencyType,RetailerID,Date) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", row['LOB'],row['Country'],row['Site'], row['Category URL'],row['ItemNumber'],row['MPN'],row['Manufacturer'],row['Name'],row['Product URL'],row['List Price'],row['Promo Price'],row['Currency'],row['Retailer ID'],row['Crawling Date'])
            except Exception as e:
                print(e)
        connStr.commit()
        print('Sucessfully Stored Records To DB')
        cursor.close()
        connStr.close()


print("start")
LOB = ''
site = ''
country = ''
CurrencyType = ''
RetailerId = ''
CategoryURL = ''
excel_To_List()
col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price', 'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']
for url in input:
    if 'fnac.com' in url:
        url = url.replace("http:", "https:")
        print(url)
        indx = url.index('^')
        if indx != 0:
            LOB = url[:indx]
            url = url[indx+1:]
            site = "fnac-fr"
            RetailerId = '95974'
            country = "France"
            CurrencyType = 'EURO'

            CategoryURL = url
        response = fetch_data(url)
        Pages = int(get_PageNo(response))
        print(Pages)
        for i in range(1, Pages+1):
            caturl = url + str(i)+ "&sl"
            print(caturl)
            CatRes = fetch_data(caturl)
            Extract_data(CatRes, url)
            result_out_excel(DataOut)
            Result_SQL = pd.DataFrame(sqldata, columns=col)
            Push_TO_Sql(Result_SQL)
            sqldata.clear()
        result_out_excel(DataOut)
