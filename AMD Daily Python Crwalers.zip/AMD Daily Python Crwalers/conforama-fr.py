from pandas import ExcelWriter
import pandas as pd
from openpyxl import load_workbook
import pyodbc
import datetime
import requests
from pandas.io.json import json_normalize
import os
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import json



input=[]
DataOut=[]
sqldata=[]

# sess = requests.session()
# sess.headers = ({
#     'Connection': 'keep-alive',
#     'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36',
#     'Upgrade-Insecure-Requests': '1',
#     'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
#     'Accept-Encoding': 'gzip, deflate, br',
#     'Accept-Language': 'en-GB,en;q=0.9,en-US;q=0.8,hi;q=0.7'})

chromedriver = "E:\Python\AMD Daily Python Crwalers\chromedriver.exe"
os.environ["webdriver.chrome.driver"] = chromedriver

options = Options()
# options.add_argument('--headless')
options.add_argument('--disable-gpu')  # Last I checked this was necessary.

driver = webdriver.Chrome(chromedriver, chrome_options=options)
driver.set_page_load_timeout(240)


def excel_To_List():
    wb = load_workbook(filename='E:\Python\AMD Script\Input.xlsx')
    # wb = load_workbook(filename='E:\Python\AMD Script\Input.xlsx')
    ws = wb['Sheet8']
    row = ws.max_row
    col = ws.max_column
    for row in ws.iter_rows(min_row=2, min_col=0, max_row=row, max_col=1):
        for cell in row:
            if cell.value is not None and "conforama.fr" in cell.value:
                input.append(cell.value)
    wb.close()


def fetch_data(url):
    res = ''
    proxy = {'https': 'https://eclerxamd:Rid8B67I2Q@shp-prx109-fr-v00001.tp-ns.com:80'}
    try:
        driver.get(url)
        res=driver.page_source
        # driver.get(url)
    except Exception as e:
        print("type error: " + str(e))
    return res


def get_PageNo(res):
    soup = BeautifulSoup(res, 'lxml')
    try:
        if soup.find('div', {'class': 'awk-filter'}) is not None:
            prodcount = int(soup.find('div', {'class': 'awk-filter'}).find('h2').text.split(' ')[0])
            Pages = int(prodcount/120)
            if (prodcount%120>0):
                Pages = Pages + 1
            print(Pages)
        else:
            Pages = 1
    except Exception as e:
        Pages = 1
    return Pages

def Extract_data(res, url):
    Itemnumber = ''
    mpn = ''
    Manufacturer = ''
    Name = ''
    ProdURL = ''
    price = ''
    promo = ''
    today = str(datetime.datetime.now()).split(".")[0]
    soup = BeautifulSoup(res, 'lxml')
    try:
        items = soup.find_all('div', {'class': 'box-product'})

        for li in items:
                try:
                    Name = li.find('div', {'class': 'awk-detail-product'}).find('h3').text
                    # print(Name)
                    ProdURL = str('https://www.conforama.fr') + li.find('div', {'class': 'awk-detail-product'}).find('a')['href']
                    temp_no = ProdURL.split('/')
                    if li.find('div', {'class': 'op-product'}).find('a') is not None:
                        Manufacturer = li.find('div', {'class': 'op-product'}).find('a').find('img')['alt']
                    else:
                        Manufacturer = ''

                    if li.find('div', {'class': 'awk-addtocart addBtn'}).find('input') is not None:
                        mpn = Itemnumber = temp_no[-1]
                    else:
                        mpn = Itemnumber = li.find('div', {'class': 'image-product'}).find('a')['tcproductclick']
                        # print(Itemnumber)
                    if li.find('div', {'class': 'price-product'}) is not None:
                        pprice = li.find('div', {'class': 'price-product'}).text.split('€')
                        if '*' in pprice[1]:
                            promo = price = pprice[0].replace('&nbsp;','').replace(u'\xa0','').strip() + '.00'
                        elif pprice[1]=='':
                            promo = price = pprice[0].replace('&nbsp;','').replace(u'\xa0','').strip()+ '.00'
                        else:
                            promo = price = pprice[0].replace('&nbsp;', '').replace(u'\xa0', '').strip() + '.' + pprice[1]
                        # print(price)
                    temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                            'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                            'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                            'Category URL': url, 'Crawling Date': today}
                    DataOut.append(temp)
                    sqldata.append(temp)
                except Exception as e:
                    print(Name)

    except Exception as e:
            temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                    'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                    'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                    'Category URL': url, 'Crawling Date': today}
            DataOut.append(temp)
            sqldata.append(temp)
    return DataOut


def Push_TO_Sql(df):
    ''''add here'''
    connStr = pyodbc.connect('DRIVER={SQL Server};SERVER=ecxus249;DATABASE=SHOPAMD;UID=SHOPAMD;PWD=SHOP@md2010')
    if connStr:
        # print('Connected To SQL Server')
        cursor = connStr.cursor()
        for index,row in df.iterrows():
            cursor.execute("INSERT INTO dbo.Master_Collation(LOB,Country,Site,Itemnumber,MPN,Manufacturer,ProductName,ProductURL,Listprice,Promoprice,CurrencyType,RetailerID,CategoryURL,Date) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",row['LOB'], row['Country'], row['Site'], row['ItemNumber'], row['MPN'], row['Manufacturer'],row['Name'], row['Product URL'], row['List Price'], row['Promo Price'], row['Currency'],row['Retailer ID'], row['Category URL'], row['Crawling Date'])
            try:
                pass
            except Exception as e:
                print(e)
        connStr.commit()
        print('Sucessfully Stored Records To DB')
        cursor.close()
        connStr.close()


def Result_Out_Excel(DataOut):
    col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price',
           'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']

    dt = str(datetime.date.today())
    filename = "conforama" + dt
    path = "E:\Python\AMD Script\Output\\" + filename + ".xlsx"
    # path = "E:\SAYAR PROJECTS\PYTHON\AMD_CNCT\Output\\" + filename + ".xlsx"
    df = pd.DataFrame(DataOut, columns=col)

    writer = pd.ExcelWriter(path, engine='xlsxwriter', options={'strings_to_urls': False})
    df.to_excel(writer)
    writer.close()


print("start")
LOB = ''
site = ''
country = ''
CurrencyType = ''
RetailerId = ''
CategoryURL = ''
excel_To_List()
col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price',
           'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']

for url in input:
    # print(url)
    indx = url.index('^')
    if indx != 0:
        LOB = url[:indx]
        url = url[indx+1:]
        CategoryURL = url
        splitURL = url.split('/')
        country = 'France'
        site = 'conforma-fr'
        if country == 'France':
            RetailerId = '95971'
            country = "France"
            CurrencyType = 'EURO'
        endpart = splitURL[-1].split('?')
    response = fetch_data(url)
    Pages = int(get_PageNo(response))
    for i in range(1, Pages+1):
        if 'p=1' in url:
            tempurl = url.split('p=')[0]
            caturl = tempurl + str('p=') + str(i) + str('&')
        else:
            caturl = url
        # print(tempurl)
        # caturl = tempurl + str('=') +str(i) + str('&pagesize=96')
        print(caturl)
        CatRes = fetch_data(caturl)
        Extract_data(CatRes, url)
        Result_SQL = pd.DataFrame(sqldata, columns=col)
        Push_TO_Sql(Result_SQL)
        sqldata.clear()
        Result_Out_Excel(DataOut)
print('Completed')
