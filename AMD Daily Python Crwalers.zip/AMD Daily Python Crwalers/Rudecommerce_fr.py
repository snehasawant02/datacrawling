import random
from pandas import ExcelWriter
import pandas as pd
from openpyxl import load_workbook
import pyodbc
import datetime
import os
import requests
from bs4 import BeautifulSoup as bss
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from selenium import webdriver
from selenium.webdriver.chrome.options import Options




input=[]
DataOut=[]
sqldata=[]

sess = requests.session()
header={'Accept':'*/*','Content-Type':'application/json','Referer':'https://www.rueducommerce.fr/rayon/ordinateurs-64/ordinateur-de-bureau-658?page=2&sort=ventes&view=grid',
        'Host': 'www.rueducommerce.fr','User-Agent':'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36'}
plain_cookie = '__cfduid=d0ff1d4a0608fe143cc657f7e2bb13e301541403025; SESSIONID=57884fb1-db0d-4eaa-ab22-28401bd19954; ABTastySession=referrer%3Dhttps%3A//c.datadome.co/captcha/%3FinitialCid%3DAHrlqAAAAAMAbxmNbkhyvf0AZ_vkCA%253D%253D%26hash%3D4D096F16F58CAD48C209A56E8041CD%26cid%3DT9pCLEVCgw-NI8%7EvZYGbxPyfmEcYkklEgnNFxNpBxW__landingPage%3Dhttps%3A//www.rueducommerce.fr/; TCPID=118111131123994891312; TCSESSION=2018111131128338817333; _ga=GA1.2.207258365.1541403073; _gid=GA1.2.64821585.1541403073; lux_uid=154140307356005684; _cs_c=0; _cs_cvars=%7B%7D; TC_OPTOUT=0@@@@@@ALL; _gcl_au=1.1.480341737.1541403178; cto_lwid=89798d96-82f5-4d27-a707-172034ebc496; toky_state=minimized; __as_rng=449; sto__session=1541403185269; sto__vuid=e21949ef3dccb0ae720b441f078c33e1; ABTasty=uid%3D18110513011075120%26fst%3D1541403070937%26pst%3Dnull%26cst%3D1541403070937%26ns%3D1%26pvt%3D3%26pvis%3D3%26th%3D; tc_cj_v2=_rn_lh%5BfyfcheZZZ%7DH%7E%7B/%7B%7E*%28%20H%7D*ZZZKONKNJMJQLPLPZZZ%5D777%5Ecl_%5Dny%5B%5D%5D_mmZZZZZZKONKNJMKRRJQJZZZ%5D; tc_page_counter=3; _cs_id=ccd24ba4-4bac-a08b-c076-ddeb31ca5d33.1541403074.1.1541403189.1541403074.1.1575567074223; _cs_s=3.0; sto__count=1; datadome=A3Pgp6Tysl~juMkFZuE1FWg6sWvM9JitB7Iio_0JqK'
cj = requests.utils.cookiejar_from_dict(dict(p.split('=') for p in plain_cookie.split('; ')))
sess.cookies=cj
proxies_list =['https://eclerxamd:Rid8B67I2Q@shp-prx109-br-v00001.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-us-v00005.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-us-v00002.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-ca-v00001.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-ca-v00003.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-cn-v00002.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-cn-v00001.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-de-v00001.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-de-v00002.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-de-v00003.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-de-v00004.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-es-v00001.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-es-v00002.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-fr-v00005.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-fr-v00006.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-fr-v00007.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-fr-v00002.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-fr-v00003.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-us-v00007.tp-ns.com:80']

def excel_To_List():
    wb = load_workbook(filename='E:\Python\AMD Script\Input.xlsx')
    # wb = load_workbook(filename='Input.xlsx')
    ws = wb['Sheet1']
    row = ws.max_row
    col = ws.max_column
    for row in ws.iter_rows(min_row=2, min_col=0, max_row=row, max_col=1):
        for cell in row:
            if cell.value is not None and "rueducommerce.fr" in cell.value:
                input.append(cell.value)
    wb.close()


def fetch_data(url):
    res=''
    Page_hit_retry=3
    print('Running URL : '+url)
    while Page_hit_retry>0:
        try:
            r = random.randint(0, len(proxies_list) - 1)
            prx = {'https:': proxies_list[r]}
            res = driver.get(url)
            if 'We want to make sure it is actually you we are dealing with and not a robot' in res:
                Page_hit_retry-=1
            else:
                break
        except Exception as e:
            print("type error: " + str(e))
            Page_hit_retry-=1
    return driver.page_source


def get_PageNo(res):
    soup = bss(res, 'lxml')
    try:
        if soup.find('div',{'class':'pagination'}).text.replace('\n','') is not None:
            Pages = int(soup.find('div',{'class':'pagination'}).text.replace('\n','').split('/')[1].strip())
            if Pages is not None:
                Pages = Pages
        else:
            Pages = 1
    except Exception as e:
        Pages = 1
    return Pages




def Extract_data(res, url):
    Itemnumber = ''
    mpn = ''
    Manufacturer = ''
    Name = ''
    ProdURL = ''
    price = ''
    promo = ''
    today = str(datetime.datetime.now()).split(".")[0]
    soup = bss(res, 'lxml')
    try:
        # container= soup.find('section', {'class': 'list'})
        items = soup.find_all('article')
        for li in items:
            try:
                Manufacturer = li.find('span', {'itemprop': 'name'}).text.replace('\n','')
                Name =li.find('div', {'class': 'summary'}).find('h2').text.replace('\n','')
                ProdURL ='https://www.rueducommerce.fr'+ li.find('a')['href']
                mpn = Itemnumber = li['data-mts-target_id']

                if li.find('meta', {'itemprop': 'price'}) is not None:
                    get_pr= li.find('meta', {'itemprop': 'price'})['content']
                    promo = price=get_pr
                temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                        'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                        'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                        'Category URL': url, 'Crawling Date': today}
                DataOut.append(temp)
                sqldata.append(temp)
            except Exception as e:
                print(Name)
                print('error in Product')

    except Exception as e:
        temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                'Category URL': url, 'Crawling Date': today}
        DataOut.append(temp)
        sqldata.append(temp)
    return DataOut


def Push_TO_Sql(df):
    ''''add here'''
    connStr = pyodbc.connect('DRIVER={SQL Server};SERVER=ecxus249;DATABASE=SHOPAMD;UID=SHOPAMD;PWD=SHOP@md2010')
    if connStr:
        # print('Connected To SQL Server')
        cursor = connStr.cursor()
        for index, row in df.iterrows():
            try:
                cursor.execute("INSERT INTO dbo.Master_Collation(LOB,Country,Site,Itemnumber,MPN,Manufacturer,ProductName,ProductURL,Listprice,Promoprice,CurrencyType,RetailerID,Date) values(?,?,?,?,?,?,?,?,?,?,?,?,?)", row['LOB'],row['Country'],row['Site'],row['ItemNumber'],row['MPN'],row['Manufacturer'],row['Name'],row['Product URL'],row['List Price'],row['Promo Price'],row['Currency'],row['Retailer ID'],row['Crawling Date'])
            except Exception as e:
                print(e)
        connStr.commit()
        print('Sucessfully Stored Records To DB')
        cursor.close()
        connStr.close()



def Result_Out_Excel(DataOut):
    col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price',
           'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']

    dt = str(datetime.date.today())
    filename = "rueducommerce-fr" + dt
    path = "E:\Python\AMD Script\Output\\" +filename+".xlsx"
    # path = "E:\SAYAR PROJECTS\PYTHON\AMD_CNCT\Output\\" + filename + ".xlsx"
    df = pd.DataFrame(DataOut, columns=col)
    writer = ExcelWriter(path)
    df.to_excel(writer, 'Sheet1', index=False)
    writer.save()
    return df

chromedriver = "E:\Python\AMD Script\chromedriver.exe"
os.environ["webdriver.chrome.driver"] = chromedriver

options = Options()
# options.add_argument('--headless')
options.add_argument('--disable-gpu')
options.add_argument("--allow-running-insecure-content");

driver = webdriver.Chrome(chromedriver,chrome_options=options)
driver.set_page_load_timeout(50)


print("start")
LOB = ''
site = ''
country = ''
CurrencyType = ''
RetailerId = ''
CategoryURL = ''
excel_To_List()
col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price',
       'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']
#urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
for url in input:
    indx = url.index('^')
    if indx != 0:
        LOB = url[:indx]
        url = url[indx+1:]
        CategoryURL = url
        splitURL = url.split('/')
        country = 'de'
        site = 'rueducommerce-fr'
        if country == 'de':
            RetailerId = '29530'
            country = "France"
            CurrencyType = 'EURO'
        endpart = splitURL[-1].split('?')
    url=url+'&is-ajax=1'
    response = fetch_data(url)
    Pages = int(get_PageNo(response))
    for i in range(1, Pages+1):
        caturl = url.split('page=')[0]+'page='+str(i)+'&sort=ventes&view=grid&is-ajax=1'
        CatRes = fetch_data(caturl)
        print(caturl)
        Extract_data(CatRes, url)
        Result_SQL = pd.DataFrame(sqldata, columns=col)
        # Push_TO_Sql(Result_SQL)
        sqldata.clear()
    Result_Out_Excel(DataOut)
driver.quit()
print('Completed')