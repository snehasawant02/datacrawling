import requests
import datetime
from openpyxl import load_workbook
import pyodbc
import pandas as pd
import os
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import time
from pandas import ExcelWriter
import json

# chromedriver = "chromedriver.exe"
# os.environ["webdriver.chrome.driver"] = chromedriver
#
# options = Options()
# # options.add_argument('--headless')
# options.add_argument('--disable-gpu')  # Last I checked this was necessary.
#
# driver = webdriver.Chrome(chromedriver, chrome_options=options)
# driver.set_page_load_timeout(120)


#proxy = {'https': 'https://eclerxusa:WonderS1979@london.wonderproxy.com:80'}

headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36',
           'content-type': 'application/json; charset=UTF-8',
           'accept': 'application/json, text/javascript, */*; q=0.01',
            'Host': 'www.game.es'}

input = []
DataOut = []
sqldataout=[]


def excel_To_List():
    wb= load_workbook(filename='E:\Python\AMD Script\Input.xlsx')
    ws = wb['Sheet1']
    row = ws.max_row
    col=ws.max_column
    for row in ws.iter_rows(min_row=1, min_col=0, max_row=row, max_col=1):
        for cell in row:
            if 'game.es' in cell.value:
                input.append(cell.value)
    wb.close()

def result_out_excel(DataOut):
    col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price', 'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']
    dt = str(datetime.date.today())
    filename = "game" + dt
    path = "E:\Python\AMD Script\Output\\" +filename+".xlsx"
    df = pd.DataFrame(DataOut, columns=col)
    writer = pd.ExcelWriter(path, engine='xlsxwriter', options={'strings_to_urls': False})
    df.to_excel(writer,index=False)
    writer.close()




def fetch_data(url,pagecount):
    res = ''
    # proxy = {'https': 'https://eclerxamd:Rid8B67I2Q@shp-prx109-br-v00001.tp-ns.com:80'}
    proxy= {'https': 'https://eclerxamd:Rid8B67I2Q@shp-prx109-es-v00001.tp-ns.com:80'}
    try:
        postdata='{"MinPrice":null,"MaxPrice":null,"Head":"'+url+'","SKU":"","Order":0,"CategoryFilter":[],"Category":null,"TotalPages":null,"FirstSearch":true,"Page":'+pagecount+'}'
        # driver.get(url)
        res = requests.post('https://www.game.es/api/search', proxies=proxy,data=postdata,headers=headers).text
    except Exception as e:
        print("type error: " + str(e))
    return res
    # return driver.page_source


def get_PageNo(res):
    try:
        # soup = BeautifulSoup(res, "lxml")
        Pages = 1
    except Exception as e:
        Pages = 1
    return Pages

def Extract_data(res, url):
    Itemnumber = ''
    mpn = ''
    Manufacturer = ''
    Name = ''
    ProdURL = ''
    price = ''
    promo = ''
    today = str(datetime.datetime.now()).split(".")[0]
    # soup = BeautifulSoup(res,'lxml')
    if res!='' and 'Unknown error 400' not in res:
        try:
            data=json.loads(res)
        except:
            print('a')
        try:
            products=data['Products']

            for p in products:
                Name=p['Name']
                ProdURL = 'https://www.game.es/'+p['Navigation']
                Manufacturer = p['Publisher']
                Itemnumber = mpn = p['SKU']
                price = promo = p['Offers'][0]['SellPrice']

                temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                            'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                            'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                            'Category URL': url, 'Crawling Date': today}
                DataOut.append(temp)
                sqldataout.append(temp)

        except Exception as e:
            temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                    'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                    'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                    'Category URL': url, 'Crawling Date': today}
            DataOut.append(temp)
            sqldataout.append(temp)

    return DataOut


def Push_TO_Sql(df):
    ''''add here'''
    connStr = pyodbc.connect('DRIVER={SQL Server};SERVER=ecxus249;DATABASE=SHOPAMD;UID=SHOPAMD;PWD=SHOP@md2010')
    if connStr:
        # print('Connected To SQL Server')
        cursor = connStr.cursor()
        for index, row in df.iterrows():
            try:
                cursor.execute("INSERT INTO dbo.Master_Collation(LOB,Country,Site, CategoryURL,Itemnumber,MPN,Manufacturer,ProductName,ProductURL,Listprice,Promoprice,CurrencyType,RetailerID,Date) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", row['LOB'],row['Country'],row['Site'], row['Category URL'],row['ItemNumber'],row['MPN'],row['Manufacturer'],row['Name'],row['Product URL'],row['List Price'],row['Promo Price'],row['Currency'],row['Retailer ID'],row['Crawling Date'])
            except Exception as e:
                print(e)
        connStr.commit()
        print('Sucessfully Stored Records To DB')
        cursor.close()
        connStr.close()


print("start")
LOB = ''
site = ''
country = ''
CurrencyType = ''
RetailerId = ''
CategoryURL = ''
excel_To_List()
col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price', 'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']
for url in input:
    if 'game.es' in url:
        print(url)
        indx = url.index('^')
        if indx != 0:
            CategoryURL = url
            LOB = url[:indx]
            url = url[indx+1:]
            splitURL = url.split('/')
            hostpart = splitURL[2].split('.')
            country = 'Spain'
            site = 'game-es'
            RetailerId = '96034'
            country = "Spain"
            CurrencyType = 'EURO'
        sp_url=url.split('/')[-1]

        response = fetch_data(sp_url,'0')
        Extract_data(response, url)
        response = fetch_data(sp_url, '1')
        Extract_data(response, url)

        Pages = 2

        # print(Pages)
        # for i in range(1, Pages+1):
        #     # temp_url = url.replace('page=1', 'page=')
        #     caturl = url
        #     print(caturl)
        #     response = fetch_data(caturl)
        #     Extract_data(response, url)
            # if driver.find_element_by_id('pagnNextLink') is not None:
            #     # CatRes = driver.find_element_by_id('pagnNextLink')
            #     # CatRes.click()
            #     driver.find_element_by_link_text("Página siguiente").click()
            # else:
            #    print('No Button to Click')
            #    break
        Result_SQL = pd.DataFrame(sqldataout, columns=col)
        Push_TO_Sql(Result_SQL)
        sqldataout.clear()
    result_out_excel(DataOut)

