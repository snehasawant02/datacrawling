from time import sleep
import datetime
import requests
import pandas as pd
import re
from bs4 import BeautifulSoup
from openpyxl import load_workbook
import xlsxwriter
import random
from lxml import html
from pandas import ExcelWriter
import pyodbc


sess = requests.session()
sess.headers ={
    'Connection': 'keep-alive',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36',
    'Upgrade-Insecure-Requests': '1',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip,s deflate, br',
    'authority': 'list.tmall.com',
    'Accept-Language': 'en-GB,en;q=0.9,en-US;q=0.8,hi;q=0.7'}
input = []
DataOut = []
sqldata=[]
headerslist= ['Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.65 Safari/537.36',
              'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.104 Safari/537.36',
              'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36',
              'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.93 Safari/537.36'
              ]
proxy_set = ['https://eclerxamd:Rid8B67I2Q@shp-prx109-fr-v00002.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-br-v00002.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-br-v00001.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-ca-v00002.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-ca-v00001.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-ca-v00003.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-cn-v00002.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-cn-v00001.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-de-v00001.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-de-v00002.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-de-v00003.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-de-v00004.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-es-v00001.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-es-v00002.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-fr-v00005.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-fr-v00006.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-fr-v00007.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-fr-v00003.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-fr-v00001.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-fr-v00004.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-in-v00001.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-in-v00002.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-se-v00003.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-se-v00002.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-se-v00001.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-uk-v00003.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-uk-v00004.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-uk-v00002.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-uk-v00001.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-us-v00002.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-us-v00003.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-us-v00001.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-us-v00005.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-us-v00006.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-us-v00004.tp-ns.com:80',
'https://eclerxamd:Rid8B67I2Q@shp-prx109-us-v00007.tp-ns.com:80']

def excel_To_List():
    wb = load_workbook(filename='E:\Python\AMD Script\Input.xlsx')
    # wb = load_workbook(filename='E:\Python\AMD Script\Hemant Test\InputHK.xlsx')
    ws = wb['Sheet5']
    row = ws.max_row
    col=ws.max_column
    for row in ws.iter_rows(min_row=2, min_col=0, max_row=row, max_col=1):
        for cell in row:
            if cell.value is not None and "list.tmall.com" in cell.value:
                input.append(cell.value)
    wb.close()


def get_proxy(proxy_set):
    plen = len(proxy_set)
    gr = random.randrange(0, plen)
    row_data = proxy_set[gr]
    # ip = '217.182.223.70' #row_data[0]
    # port = row_data[1]
    # uname = row_data[2]
    # pswrd = row_data[3]
    # text = "https://" + str(uname) + ":" + str(pswrd) + "@" + str(ip) + ":" + str(port)
    return row_data


def fetch_data(url):
    res ='na'
    # try:
    no = 0
    while res == 'na' and no < 3:
        # proxy = {"https": "https://eclerxamd:Rid8B67I2Q@shp-prx109-de-v00003.tp-ns.com:80"}
        prxText = get_proxy(proxy_set)
        proxy = {"https": prxText}
        if no == 4:
            no = 0
        sess.headers.__setitem__('User-Agent', headerslist[no])
        try:
            resp = sess.get(url, proxies=proxy)
            if "J_ItemList" not in resp.text:
                no += 1
            else:
                res = resp.content
                break
        except Exception as e:
            no += 1
            print("type error: " + str(e))
    # except Exception as e:
    #     print("type error: " + str(e))
    return res

def get_PageNo(res):
    soup = BeautifulSoup(res, 'lxml')
    PageDiv = soup.find("b", {'class': 'ui-page-s-len'}).text.split('/')
    Pages = PageDiv[1].strip()
    return Pages

def Extract_data(res, url):
    Itemnumber = ''
    mpn = ''
    Manufacturer = ''
    Name = ''
    ProdURL = ''
    price = ''
    promo = ''
    today = str(datetime.datetime.now()).split(".")[0]
    soup = BeautifulSoup(res, 'lxml')
    try:
        container = soup.find('div', {'id': 'J_ItemList'})
        block = container.find_all('div', {'class': 'product'})
        for li in block:
            try:
                Name =''
                ProdURL = ''
                titlediv = ''
                if li.find('div', {'class': 'productTitle productTitle-spu'}) is not None:
                    titlediv = li.find('div', {'class': 'productTitle productTitle-spu'}).find_all('a')
                elif li.find('div', {'class': 'productTitle'}) is not None:
                    titlediv = li.find('div', {'class': 'productTitle'}).find_all('a')
                elif li.find('p', {'class': 'productTitle'}) is not None:
                    titlediv = li.find('p', {'class': 'productTitle'}).find_all('a')
                cnt = 0
                for a in titlediv:
                    if cnt == 0:
                        Name = a.text + "^^"
                        ProdURL = "https:" + a['href']
                        cnt = 1
                    else:
                        Name = Name + a.text
                namepart = Name.split(" ")
                Manufacturer = namepart[0]
                try:
                    promo = price = li.find('p', {'class': 'productPrice'}).text.replace('\n','').replace('\t', '').replace('¥', '').replace(",", "").strip()
                except Exception as es:
                    price = promo = "Check for price"
                Itemnumber = "ecx_" + li['data-id']
                mpn = Itemnumber
                temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                        'Manufacturer': Manufacturer,
                        'Name': Name, 'Product URL': ProdURL, 'List Price': price, 'Promo Price': promo,
                        'Currency': CurrencyType, 'Retailer ID': RetailerId, 'Category URL': CategoryURL,
                        'Crawling Date': today}
                DataOut.append(temp)
                sqldata.append(temp)
            except:
                print("Error in product")
    except Exception as e:
        temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                'Manufacturer': Manufacturer,
                'Name': Name, 'Product URL': ProdURL, 'List Price': price, 'Promo Price': promo,
                'Currency': CurrencyType, 'Retailer ID': RetailerId, 'Category URL': CategoryURL,
                'Crawling Date': today}
        DataOut.append(temp)
        sqldata.append(temp)

def Push_TO_Sql(df):
    ''''add here'''
    connStr = pyodbc.connect('DRIVER={SQL Server};SERVER=ecxus249;DATABASE=SHOPAMD;UID=SHOPAMD;PWD=SHOP@md2010')
    if connStr:
        # print('Connected To SQL Server')
        cursor = connStr.cursor()
        for index, row in df.iterrows():
            try:
                cursor.execute(
                    "INSERT INTO dbo.Master_Collation(LOB,Country,Site,Itemnumber,MPN,Manufacturer,ProductName,ProductURL,Listprice,Promoprice,CurrencyType,RetailerID,CategoryURL,Date) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    row['LOB'], row['Country'], row['Site'], row['ItemNumber'], row['MPN'], row['Manufacturer'],
                    row['Name'], row['Product URL'], row['List Price'], row['Promo Price'], row['Currency'],
                    row['Retailer ID'], row['Category URL'], row['Crawling Date'])
            except Exception as e:
                print(e)
        connStr.commit()
        print('Sucessfully Stored Records To DB')
        cursor.close()
        connStr.close()

def result_out_excel(DataOut):
    col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price',
           'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']
    dt = str(datetime.date.today())
    filename = site + "_" + dt
    path = "E:\Python\AMD Script\Output\\" + filename + ".xlsx"
    df = pd.DataFrame(DataOut, columns=col)
    writer = ExcelWriter(path)
    df.to_excel(writer, 'Sheet1', index=False)
    writer.save()

print("start")
LOB = ''
site = ''
country = ''
CurrencyType = ''
RetailerId = ''
CategoryURL = ''
excel_To_List()
col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price',
           'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']
sess.get('https://tmall.com/')
for url in input:
    if "tmall" in url:
        print(url)
        # url='Graphic Card^https://mall.jd.com/view_search-657455-0-99-1-24-1.html'
        indx = url.index('^')
        if indx != 0:
            LOB = url[:indx]
            url = url[indx+1:]
            CategoryURL = url
            url = url.replace("http:", "https:")
            RetailerId = "95954"
            country = "China"
            CurrencyType = "CNY"
            site = 'tmall-cn'

        CatHomeRes = fetch_data(url)
        Pages = int(get_PageNo(CatHomeRes))
        catId = url[url.index("&cat=")+5:]
        catId = catId[:catId.index("&")]
        for i in range(1, Pages+1):
            sec = random.randrange(0, 3)
            sleep(sec)
            caturl = "https://list.tmall.com/search_product.htm?totalPage=" + str(Pages) + "&cat=" + str(catId) + "&jumpto=" + str(i) + "#J_Filter"
            CatRes = fetch_data(caturl)
            Extract_data(CatRes, url)
            Result_SQL = pd.DataFrame(sqldata, columns=col)
            Push_TO_Sql(Result_SQL)
            sqldata.clear()
        result_out_excel(DataOut)
print("Crawling Completed Successfully")