import time
import requests
import datetime
from openpyxl import load_workbook
import pyodbc
import pandas as pd
import os
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from pandas import ExcelWriter
import json


chromedriver = "E:\Python\AMD Daily Python Crwalers\chromedriver.exe"
os.environ["webdriver.chrome.driver"] = chromedriver

options = Options()
# options.add_argument('--headless')
options.add_argument('--disable-gpu')  # Last I checked this was necessary.

driver = webdriver.Chrome(chromedriver, chrome_options=options)
driver.set_page_load_timeout(120)


#proxy = {'https': 'https://eclerxusa:WonderS1979@london.wonderproxy.com:80'}
headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36',
           'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
           'Host': 'shop.bt.com',
           'Accept-Encoding': 'gzip, deflate, br',
           'Connection' : 'keep-alive' ,
           'Accept-Language' : 'en-US,en;q=0.9'}

input = []
DataOut = []
sqldata=[]


def excel_To_List():
    wb= load_workbook(filename='E:\Python\AMD Script\Input.xlsx')
    ws = wb['Sheet1']
    row = ws.max_row
    col=ws.max_column
    for row in ws.iter_rows(min_row=1, min_col=0, max_row=row, max_col=1):
        for cell in row:
            input.append(cell.value)
    wb.close()

def result_out_excel(DataOut):
    col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price', 'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']
    dt = str(datetime.date.today())
    filename = "btshop_uk" + dt
    path = "E:\Python\AMD Script\Output\\" + filename + ".xlsx"
    df = pd.DataFrame(DataOut, columns=col)
    writer = pd.ExcelWriter(path, engine='xlsxwriter', options={'strings_to_urls': False})
    df.to_excel(writer,index=False)
    writer.close()




def fetch_data(url):
    res = ''
    # proxy = {'https': 'https://eclerxamd:Rid8B67I2Q@shp-prx109-br-v00001.tp-ns.com:80'}
    # proxy= {'https': '107.155.108.158:80'}
    try:
        driver.get(url)
        # res = requests.get(url).text
    except Exception as e:
        print("type error: " + str(e))
    # return res
    return driver.page_source


def get_PageNo(res):
    soup = BeautifulSoup(res, 'lxml')
    try:
        Product = soup.find('div', {'class': 'pager float-left d-none d-md-none d-lg-block mt-2'}).text.replace('\n','').strip().replace('products','').split('of')
        pages1 = int(Product[1]) / 10
        pages2 = int(pages1) + 1
        if int(pages2) >= 1:
            Pages = pages2
        else:
            Pages = 1

    except Exception as e:
        Pages = 2
    return Pages

def Extract_data(res, url):
    Itemnumber = ''
    mpn = ''
    Manufacturer = ''
    Name = ''
    ProdURL = ''
    price = ''
    promo = ''
    today = str(datetime.datetime.now()).split(".")[0]
    soup = BeautifulSoup(res, 'lxml')
    try:
        # container = soup.find('div', {'class': 'widget widget-ArticleList widget-ArticleList---bf700d21-07d0-4fa7-954e-efd088cabbfe widget-ArticleList---view-article-list widget-ArticleList---preset-default margin-xs-bottom-10  '})
        items = soup.find_all('div', {'class': 'product-container product-container-halfwidthitem'})
        for li in items:
            try:
                Name = li.find('div', {'class': 'product-heading'}).text
                # print(Name)
                ProdURL = 'https://www.shop.bt.com' + li.find('div', {'class': 'product-heading'}).find('a')['href']
                Manufacturer = Name
                if li.find('span', {'class': 'lprice h2 btfont-bold'}) is not None:
                    price = promo = li.find('span', {'class': 'lprice h2 btfont-bold'}).text.replace('£','').replace(',' , '').strip()
                elif li.find('span',{'class': 'lprice h2 btfont-bold'}) == ' ':
                    price = promo = 'Check for Price'
                else:
                    price = promo = 'Price Not Available'
                print(price)

                mpn = Itemnumber = li.find('div', {'class': 'image-and-review d-flex flex-column'}).find('img')['id'].split('-')[-1] + 'WS00'

                # print(Manufacturer)


                temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                        'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                        'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                        'Category URL': url, 'Crawling Date': today}
                DataOut.append(temp)
                sqldata.append(temp)

            except Exception as e:
                print(Name)
                print('error in Product')

    except Exception as e:
        temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                'Category URL': url, 'Crawling Date': today}
        DataOut.append(temp)
        sqldata.append(temp)
    return DataOut


def Push_TO_Sql(df):
    ''''add here'''
    connStr = pyodbc.connect('DRIVER={SQL Server};SERVER=ecxus249;DATABASE=SHOPAMD;UID=SHOPAMD;PWD=SHOP@md2010')
    if connStr:
        # print('Connected To SQL Server')
        cursor = connStr.cursor()
        for index, row in df.iterrows():
            try:
                cursor.execute("INSERT INTO dbo.Master_Collation(LOB,Country,Site, CategoryURL,Itemnumber,MPN,Manufacturer,ProductName,ProductURL,Listprice,Promoprice,CurrencyType,RetailerID,Date) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", row['LOB'],row['Country'],row['Site'], row['Category URL'],row['ItemNumber'],row['MPN'],row['Manufacturer'],row['Name'],row['Product URL'],row['List Price'],row['Promo Price'],row['Currency'],row['Retailer ID'],row['Crawling Date'])
            except Exception as e:
                print(e)
        connStr.commit()
        print('Sucessfully Stored Records To DB')
        cursor.close()
        connStr.close()


print("start")
LOB = ''
site = ''
country = ''
CurrencyType = ''
RetailerId = ''
CategoryURL = ''
excel_To_List()
col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price', 'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']
for url in input:
    if 'shop.bt.com' in url:
        # print(url)
        print(url)
        indx = url.index('^')
        if indx != 0:
            LOB = url[:indx]
            url = url[indx + 1:]
            CategoryURL = url
            splitURL = url.split('/')
            site = 'btshop-uk'
            RetailerId = '96027'
            country = "UK"
            CurrencyType = 'EURO'
            response = fetch_data(url)
        Pages = int(get_PageNo(response))
        print(Pages)

        for i in range(1, Pages+1):
            soup = BeautifulSoup(response, 'lxml')
            temp_url = url + '/%s#Paging'%i
            caturl = temp_url
            print(caturl)
            response = fetch_data(caturl)
            Extract_data(response, url)
            Result_SQL = pd.DataFrame(sqldata, columns=col)
            Push_TO_Sql(Result_SQL)
            sqldata.clear()
            result_out_excel(DataOut)

driver.close()
