import datetime
import requests
from bs4 import BeautifulSoup
from openpyxl import load_workbook
import pandas as pd
from pandas import ExcelWriter
import re
import random
import pyodbc
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import os


sess = requests.session()
sess.headers = ({
    'Connection': 'keep-alive',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36',
    'Upgrade-Insecure-Requests': '1',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-GB,en;q=0.9,en-US;q=0.8,hi;q=0.7', 'Host': 'www.hpshopping.in'})

# headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36',
#            'content-type': 'text/html;charset=utf-8',
#            'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
#            'Host': 'www.hpshopping.in'}
input = []
DataOut = []
sqldata=[]

chromedriver = "chromedriver.exe"
os.environ["webdriver.chrome.driver"] = chromedriver
options = Options()
# options.add_argument('--headless')
options.add_argument('--disable-gpu')  # Last I checked this was necessary.
driver = webdriver.Chrome(chromedriver,chrome_options=options)

def excel_to_list():
    wb= load_workbook(filename='E:\Python\AMD Script\Input.xlsx')
    ws = wb['Sheet1']
    row = ws.max_row
    col=ws.max_column
    for row in ws.iter_rows(min_row=1, min_col=0, max_row=row, max_col=1):
        for cell in row:
            if cell.value is not None and "store.hp.com" in cell.value:
                input.append(cell.value)
    wb.close()


def result_out_excel(DataOut):
    col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price', 'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']
    dt = str(datetime.date.today())
    filename = "hp-in" + "_" + dt
    path = "E:\Python\AMD Script\Output\\" +filename+".xlsx"
    df = pd.DataFrame(DataOut, columns=col)
    writer = ExcelWriter(path)
    df.to_excel(writer, 'Sheet1', index=False)
    writer.save()


def fetch_data(url):
    #proxy_set = ["https://216.227.130.13:80"]
    proxy_set = ["http://eclerxamd:Rid8B67I2Q@shp-prx109-us-v00002.tp-ns.com:80",
                  "http//eclerxamd:Rid8B67I2Q@shp-prx109-in-v00001.tp-ns.com:80"]
    no = random.randint(0, len(proxy_set) - 1)
    # print(self.proxy_set[no])
    sess.proxies = {"https ": proxy_set[no]}
    res = ''
    try:
        driver.get(url)
        #print(res)
        # res = sess.get(url, proxies=proxies).text
    except Exception as e:
        print("type error: " + str(e))
    return driver.page_source


def get_pageno(res):
    soup = BeautifulSoup(res, 'lxml')
    try:
        Pages = 20
    except Exception as e:
        Pages = 1
    return Pages


def extract_data(res, url):
    Itemnumber = ''
    mpn = ''
    Manufacturer = ''
    Name = ''
    ProdURL = ''
    price = ''
    promo = ''
    today = str(datetime.datetime.now()).split(".")[0]
    soup = BeautifulSoup(res, 'lxml')
    try:
        if soup.find('ol', {'class': 'products list items product-items'}) is not None:
            # container = soup.find('div', {'id': 'resultsList'})
            block = soup.find_all('li', {'class': 'item product product-item'})
            for li in block:
                try:
                    Name = li.find('strong', {'class': 'product name product-item-name'}).find('a').text.strip()
                    namepart = Name.split(" ")
                    Manufacturer = namepart[0]

                    try:
                        Desc = li.find('div', {'class': 'product-desc-features'}).text.replace("\n", " ").strip()
                        Name=Name+'^^'+Desc
                    except:
                        pass

                    ProdURL = li.find('strong', {'class': 'product name product-item-name'}).find('a')['href']
                    try:
                        promo = price = li.find('span', {'class': 'price-wrapper '}).text.replace('₹', '').replace(',', '').strip()
                    except Exception as es:
                        promo = price = "check for price"
                    mpn = Itemnumber = li.find('div', {'class': 'product-item-inner'})['data-sku']

                    temp = {}
                    temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                            'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                            'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                            'Category URL': url, 'Crawling Date': today}
                    DataOut.append(temp)
                    sqldata.append(temp)
                except:
                    print("Error in product")
    except Exception as e:
        temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                'Category URL': url, 'Crawling Date': today}
        print("Error in page")
        DataOut.append(temp)
        sqldata.append(temp)


def Push_TO_Sql(df):
    ''''add here'''
    connStr = pyodbc.connect('DRIVER={SQL Server};SERVER=ecxus249;DATABASE=SHOPAMD;UID=SHOPAMD;PWD=SHOP@md2010')
    if connStr:
        # print('Connected To SQL Server')
        cursor = connStr.cursor()
        for index, row in df.iterrows():
            try:
                cursor.execute("INSERT INTO dbo.Master_Collation(LOB,Country,Site, CategoryURL,Itemnumber,MPN,Manufacturer,ProductName,ProductURL,Listprice,Promoprice,CurrencyType,RetailerID,Date) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", row['LOB'],row['Country'],row['Site'], row['Category URL'],row['ItemNumber'],row['MPN'],row['Manufacturer'],row['Name'],row['Product URL'],row['List Price'],row['Promo Price'],row['Currency'],row['Retailer ID'],row['Crawling Date'])
            except Exception as e:
                print(e)
        connStr.commit()
        print('Sucessfully Stored Records To DB')
        cursor.close()
        connStr.close()

print("start")
LOB = ''
site = ''
country = ''
CurrencyType = ''
RetailerId = ''
CategoryURL = ''
col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price',
           'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']
today = str(datetime.datetime.now()).split(".")[0]
excel_to_list()
for url in input:
    if "store.hp.com" in url:
        # url = url.replace("http:", "https:")
        #url = url + "?p="
        indx = url.index('^')
        if indx != 0:
            LOB = url[:indx]
            url = url[indx+1:]
            splitURL = url.split('/')[2].split(".")
            RetailerId = "96018"
            CurrencyType = "INR"
            country = "India"
            site = splitURL[1].replace('shopping', '') + "-in"
        print(url)
        response = fetch_data(url)
        Pages = 20
        for i in range(1, Pages + 1):
            #len = url.index('?p=')
            caturl = url + '?p=' + str(i) + '&product_list_limit=30'
            #caturl = url[:len + 9] + str(i)
            CatRes = fetch_data(caturl)
            extract_data(CatRes, url)
            Result_SQL = pd.DataFrame(sqldata, columns=col)
            Push_TO_Sql(Result_SQL)
            sqldata.clear()
result_out_excel(DataOut)
print("Crawling completed Successfully.")