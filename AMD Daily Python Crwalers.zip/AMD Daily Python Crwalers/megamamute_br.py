'''
Last Modified By: Hemant
Last Modified Date : 28/08/2018
'''
import datetime
import requests
from bs4 import BeautifulSoup
from openpyxl import load_workbook
from pandas import ExcelWriter
import pandas as pd
import pyodbc
import re
#import urllib3

#urllib3.disable_warnings()

sess = requests.session()
sess.headers = ({
    'Connection': 'keep-alive',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36',
    'Upgrade-Insecure-Requests': '1',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-GB,en;q=0.9,en-US;q=0.8,hi;q=0.7'})
input = []
DataOut = []
sqldata=[]


def excel_to_list():
    wb= load_workbook(filename='E:\Python\AMD Script\Input.xlsx')
    ws = wb['Sheet1']
    row = ws.max_row
    col=ws.max_column
    for row in ws.iter_rows(min_row=1, min_col=0, max_row=row, max_col=1):
        for cell in row:
            if cell.value is not None and "megamamute" in cell.value:
                input.append(cell.value)
    wb.close()


def result_out_excel(DataOut):
    col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price', 'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']
    dt = str(datetime.date.today())
    filename = "megamaute_br" + dt
    path = "E:\Python\AMD Script\Output\\" + filename + ".xlsx"
    df = pd.DataFrame(DataOut, columns=col)
    writer = ExcelWriter(path)
    df.to_excel(writer, 'Sheet1', index=False)
    writer.save()


def fetch_data(url):
    sess.proxies = {"https", "https://eclerxamd:Rid8B67I2Q@shp-prx109-us-v00001.tp-ns.com:80",
                    "https", "https://eclerxamd:Rid8B67I2Q@shp-prx109-us-v00002.tp-ns.com:80"}
    res = ''
    try:
        res = sess.get(url, verify=False).text
        # res = sess.get(url, proxies=proxies).text
    except Exception as e:
        pass
    return res


def get_pageno(res):
    soup = BeautifulSoup(res, 'lxml')
    products = ''
    try:
        if soup.find("span", {'class': 'value'}) is not None:
            PageDiv = soup.find("span", {'class': 'value'}).text
            regx = re.compile(r'\d+')
            no = regx.search(PageDiv)
            if no:
                products = int(no.group())
        if products is not "":
            Pages = int(products / 18)
            if products % 18 > 0:
                Pages += 1
        else:
            Pages = 0
    except Exception as e:
        Pages = 0
    return Pages


def extract_data(res, url, CategoryURL):
    Itemnumber = ''
    mpn = ''
    Manufacturer = ''
    Name = ''
    ProdURL = ''
    price = ''
    promo = ''
    today = str(datetime.datetime.now()).split(".")[0]
    soup = BeautifulSoup(res, 'lxml')
    try:
            block = soup.find_all('li', {'class': re.compile(r'product-')})
            for li in block:
                try:
                    Name = li.find('h3', {'class': 'name'}).find('a').text
                    Manufacturer = Name
                    ProdURL = "https://megamamute.com.br" + li.find('h3', {'class': 'name'}).find('a')['href']
                    # if li.find('span', {'class': 'x-bestPrice'}) is not None:
                    if li.find('p', {'class': 'x-outOfStock'}) is None:
                        promo = price = li.find('strong', {'class': 'instant-price'}).text.replace('R$', '').replace(',','$')
                        if '.' in price:
                            price=promo=price.replace('.',',').replace('$','.')
                        else:
                            price = promo = price.replace('$', '.')
                    else:
                        promo = price = 'Check for Price'
                    itemclass=li.find('div',{'class':'wd-product-price-description wd-widget wd-widget-js'})
                    Itemnumber = mpn =itemclass['data-widget-pid']
                    temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                            'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                            'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                            'Category URL': url, 'Crawling Date': today}
                    DataOut.append(temp)
                    sqldata.append(temp)
                except:
                    print('Error in Product')
    except Exception as e:
        temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                'Category URL': url, 'Crawling Date': today}
        DataOut.append(temp)
        sqldata.append(temp)
    return DataOut


def Push_TO_Sql(df):
    ''''add here'''
    connStr = pyodbc.connect('DRIVER={SQL Server};SERVER=ecxus249;DATABASE=SHOPAMD;UID=SHOPAMD;PWD=SHOP@md2010')
    if connStr:
        # print('Connected To SQL Server')
        cursor = connStr.cursor()
        for index, row in df.iterrows():
            try:
                cursor.execute("INSERT INTO dbo.Master_Collation(LOB,Country,Site,Itemnumber,MPN,Manufacturer,ProductName,ProductURL,Listprice,Promoprice,CurrencyType,RetailerID,CategoryURL,Date) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", row['LOB'],row['Country'],row['Site'],row['ItemNumber'],row['MPN'],row['Manufacturer'],row['Name'],row['Product URL'],row['List Price'],row['Promo Price'],row['Currency'],row['Retailer ID'], row['Category URL'],row['Crawling Date'])
            except Exception as e:
                print(e)
        connStr.commit()
        print('Sucessfully Stored Records To DB')
        cursor.close()
        connStr.close()

print("start")
LOB = ''
site = ''
country = ''
CurrencyType = ''
RetailerId = ''
CategoryURL = ''
today = datetime.datetime.today()
excel_to_list()
col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price',
           'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']
for url in input:
    print(url)
    indx = url.index('^')
    if indx != 0:
        LOB = url[:indx]
        url = url[indx+1:]
        CategoryURL = url
        splitURL = url.split('/')[2].split(".")
        country = splitURL[3]
        site = splitURL[1] + "-" + country
        RetailerId = "96022"
        CurrencyType = "BRL"
        country = "Brazil"
    response = fetch_data(url)
    extract_data(response, url, CategoryURL)
    Result_SQL = pd.DataFrame(sqldata, columns=col)
    Push_TO_Sql(Result_SQL)
    sqldata.clear()
result_out_excel(DataOut)
print("Crawling completed Successfully.")
