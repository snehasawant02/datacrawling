import pyodbc
import pandas as pd
import os
from openpyxl import load_workbook
import datetime
import requests
from bs4 import BeautifulSoup
import random
import json


class cddiscount_FR:
    def __init__(self, Input):

        self.sess = requests.session()
        self.sess.headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}

        self.post_data = {'TechnicalForm.SiteMapNodeId': '',
                          'TechnicalForm.DepartmentId': '',
                          'TechnicalForm.ProductId': '',
                          'hdnPageType': 'ProductList',
                          'TechnicalForm.ContentTypeId': '3',
                          'TechnicalForm.SellerId': '',
                          'TechnicalForm.PageType': 'PRODUCTLISTER',
                          'TechnicalForm.LazyLoading.ProductSheets': 'False',
                          'TechnicalForm.BrandLicenseId': '0',
                          'SortForm.BrandLicenseSelectedCategoryPath': '',
                          'SortForm.SelectedSort': 'BESTPRODUCTS',
                          'ProductListTechnicalForm.Keyword': '',
                          'ProductListTechnicalForm.TemplateName': 'InLine'}

        self.proxy_set = ['https://eclerxamd:Rid8B67I2Q@shp-prx109-fr-v00001.tp-ns.com:80',
                          'https://eclerxamd:Rid8B67I2Q@shp-prx109-in-v00001.tp-ns.com:80',
                          'https://eclerxamd:Rid8B67I2Q@shp-prx109-fr-v00003.tp-ns.com:80',
                          'https://eclerxamd:Rid8B67I2Q@shp-prx109-fr-v00005.tp-ns.com:80',
                          'https://eclerxamd:Rid8B67I2Q@shp-prx109-fr-v00006.tp-ns.com:80',
                          'https://eclerxamd:Rid8B67I2Q@shp-prx109-fr-v00004.tp-ns.com:80',
                          'https://eclerxamd:Rid8B67I2Q@shp-prx109-fr-v00002.tp-ns.com:80']

        self.DataOut = []
        self.input = Input
        self.LOB = ''
        self.site = 'cdiscount-fr'
        self.country = 'France'
        self.CurrencyType = 'EURO'
        self.RetailerId = '95956'
        self.CategoryURL = ''

    def fetch_data(self, url):
        no = random.randint(0, len(self.proxy_set) - 1)
        self.sess.proxies = {"https": self.proxy_set[no]}
        res = ''
        try:
            res = self.sess.post(url, data=json.dumps(self.post_data)).text
        except Exception as e:
            print("Error: " + str(e))
        return res

    def get_PageNo(self, res):
        json_d = json.loads(res)
        page_html = str(json_d['pagination'])
        count = ''
        soup = BeautifulSoup(page_html, 'lxml')
        try:
            count = soup.find("span", {'class': 'pgActual'}).text.split("/")[1].strip()
        except Exception as e:
            count = 1
        return count

    def Extract_data(self, res, url):
        today = str(datetime.datetime.now()).split(".")[0]
        Itemnumber = ''
        mpn = ''
        Manufacturer = ''
        Name = ''
        ProdURL = ''
        list_price = ''
        promo = ''
        json_data = json.loads(res)
        for product in json_data['products']:
            try:
                Itemnumber = product['sku']
                mpn = Itemnumber
                ProdURL = product['urlToRedirect']
                Name = product['name']
                try:
                    Desc=BeautifulSoup(product['desc']).get_text()
                    Name=Name+'^^'+Desc
                except:
                    pass
                Manufacturer = Name.split(' ')[0]
                tempprice = product['prx']['val']
                list_price = product['prx']['val'].replace('<sup>&euro;', '.').replace('</sup>', '').strip()
                promo = list_price
                temp = {'LOB': self.LOB, 'Country': self.country, 'Site': self.site, 'ItemNumber': Itemnumber,
                        'MPN': mpn,
                        'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': list_price,
                        'Promo Price': promo, 'Currency': self.CurrencyType, 'Retailer ID': self.RetailerId,
                        'Category URL': self.CategoryURL, 'Crawling Date': today}
                self.DataOut.append(temp)
            except Exception as e:
                temp = {'LOB': self.LOB, 'Country': self.country, 'Site': self.site, 'ItemNumber': '', 'MPN': '',
                        'Manufacturer': '', 'Name': Name, 'Product URL': '', 'List Price': '',
                        'Promo Price': '', 'Currency': self.CurrencyType, 'Retailer ID': self.RetailerId,
                        'Category URL': self.CategoryURL, 'Crawling Date': today}
                self.DataOut.append(temp)


    def main_call(self,Input, LOB):
        ob = cddiscount_FR(Input)
        getsp = LOB.split('_')
        Departmentid = str(getsp[1])
        Mapnodeid = str(getsp[2])
        ob.LOB = str(getsp[0])
        ob.post_data['TechnicalForm.SiteMapNodeId'] = Mapnodeid
        ob.post_data['TechnicalForm.DepartmentId'] = Departmentid
        print(str(ob.post_data['TechnicalForm.SiteMapNodeId'] + '_' + str(ob.post_data['TechnicalForm.DepartmentId'])))
        print(ob.LOB)
        response = ob.fetch_data(Input)
        ob.CategoryURL = Input
        Pages = int(ob.get_PageNo(response))
        print('Page Found : ' + str(Pages))
        for i in range(1, Pages+1):
            srl_sp = Input.split("page=")[0]
            caturl = srl_sp + 'page=' + str(i)
            ob.CategoryURL = caturl
            print(caturl)
            CatRes = ob.fetch_data(caturl)
            ob.Extract_data(CatRes, Input)
            print('Page ' + str(i) + ' Completed Out of ' + str(Pages))
        return ob.DataOut

class Comman():
    def read_excel(self, path=None, sheetname='Sheet1'):
        inputs=[]
        try:
            wb = load_workbook(filename=path)
            ws = wb[sheetname]
            row = ws.max_row
            for row in ws.iter_rows(min_row=0, min_col=0, max_row=row, max_col=1):
                for cell in row:
                    url = cell.value
                    if 'cdiscount.com' in url:
                        inputs.append(url.lower())
            wb.close()
            return inputs
        except Exception as Err:
            print(str(Err))

    def out_excel(self, filepath=None, dataframe=None, website='Output'):
        '''

        :param path: Path Where excel should stored
        :param Dataframe: The data which excel should have
        :return: return success msg
        '''

        now = datetime.datetime.now()
        datstr = str(now.day) + '_' + str(now.month) + '_' + str(now.year) + '_' + str(now.hour) + '_' + str(
            now.minute) + '_' + str(now.second)
        filepath = filepath + '/' + website + '_' + str(datstr) + '.xlsx'
        df = pd.DataFrame(dataframe)
        df.to_excel(filepath)
        return filepath

    def Push_SQL(self, Datalist):
        '''

        :param DataFrame: The data which excel should have
        :return: return success msg
        '''
        connStr = pyodbc.connect('DRIVER={SQL Server};SERVER=ecxus249;DATABASE=SHOPAMD;UID=SHOPAMD;PWD=SHOP@md2010')
        if connStr:
            # print('Connected To SQL Server')
            cursor = connStr.cursor()
            for row in Datalist:
                try:
                    cursor.execute(
                        "INSERT INTO dbo.Master_Collation(LOB,Country,Site,Itemnumber,MPN,Manufacturer,ProductName,ProductURL,Listprice,Promoprice,CurrencyType,RetailerID,Date) values(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        row['LOB'], row['Country'], row['Site'], row['ItemNumber'], row['MPN'], row['Manufacturer'],
                        row['Name'], row['Product URL'], row['List Price'], row['Promo Price'], row['Currency'],
                        row['Retailer ID'], row['Crawling Date'])
                except Exception as e:
                    print(e)
            connStr.commit()
            print('Sucessfully Stored Records To DB')
            cursor.close()
            connStr.close()

if __name__ == '__main__':
    ob=Comman()
    Input=ob.read_excel('cdisctest.xlsx', 'Sheet1')
    Report = []
    count = 0
    for url in Input:
        Report_Data = {}
        if '^' in url:
            count += 1
            print('Running ' + str(count) + ' Url out of ' + str(len(Input) - 1) + ' URLS ')
            indx = url.index('^')
            LOB = url[:indx]
            url = url[indx + 1:]
            CategoryURL = url
            url = url.replace("http:", "https:")
            Domain = url.split("/")[2].replace('www.', '')
            Excelout = ''
            try:
                print('Script Running For: ' + Domain)
                print('URL :' + url)
                Crawl_ob=cddiscount_FR(url)
                Result = Crawl_ob.main_call(url,LOB)
                dirname = os.path.dirname(__file__)
                Excelout = ob.out_excel('E:\Python\AMD Script\Output', Result, Domain)
                if (len(Result) > 0):
                    # pass
                    ob.Push_SQL(Result)
                else:
                    print('No Data found in Dataframe')
                Report_Data['Domain'] = Domain
                Report_Data['URL'] = Input
                Report_Data['Output Excel'] = Excelout
                Report_Data['Status'] = 'Completed'
            except Exception as Err:
                Report_Data['Domain'] = Domain
                Report_Data['URL'] = Input
                Report_Data['Output Excel'] = Excelout
                Report_Data['Status'] = 'Error :' + str(Err)
        Report.append(Report_Data)
    df = pd.DataFrame(Report)
    df.to_excel('Crawl_Report.xlsx')
