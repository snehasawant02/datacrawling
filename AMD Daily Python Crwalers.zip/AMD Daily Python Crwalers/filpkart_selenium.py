import requests
import datetime
from openpyxl import load_workbook
import pyodbc
import pandas as pd
import os
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import time
from pandas import ExcelWriter
import json

chromedriver = "chromedriver.exe"
os.environ["webdriver.chrome.driver"] = chromedriver

options = Options()
# options.add_argument('--headless')
options.add_argument('--disable-gpu')  # Last I checked this was necessary.

driver = webdriver.Chrome(chromedriver, chrome_options=options)
driver.set_page_load_timeout(120)


#proxy = {'https': 'https://eclerxusa:WonderS1979@london.wonderproxy.com:80'}
headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36',
           'content-type': 'text/html;charset=utf-8',
           'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
           'Host': 'www.misco.fr'}

input = []
DataOut = []
sqldata=[]


def excel_To_List():
    wb= load_workbook(filename='E:\Python\AMD Script\Input.xlsx')
    ws = wb['Sheet1']
    row = ws.max_row
    col=ws.max_column
    for row in ws.iter_rows(min_row=1, min_col=0, max_row=row, max_col=1):
        for cell in row:
            if cell.value is not None and "flipkart.com" in cell.value:
                input.append(cell.value)
    wb.close()

def result_out_excel(DataOut):
    col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price', 'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']
    dt = str(datetime.date.today())
    filename = "flipkart" + dt
    path = "E:\Python\AMD Script\Output\\" +filename+".xlsx"
    df = pd.DataFrame(DataOut, columns=col)
    writer = pd.ExcelWriter(path, engine='xlsxwriter', options={'strings_to_urls': False})
    df.to_excel(writer,index=False)
    writer.close()




def fetch_data(url):
    res = ''
    proxy = {'https': 'https://eclerxamd:Rid8B67I2Q@shp-prx109-de-v00001.tp-ns.com:80'}
    #proxy= {'https': '107.155.108.158:80'}
    try:
        driver.get(url)
        # res = requests.get(url, proxies=proxy).text
    except Exception as e:
        print("type error: " + str(e))
    # return res
    return driver.page_source


def get_PageNo():
    global content
    global check
    try:
        if content:
            check=True
        else:
            check=False

    except Exception as e:
        check=False
    return check

def Extract_data(res, url):
    global content
    Itemnumber = ''
    mpn = ''
    Manufacturer = ''
    Name = ''
    ProdURL = ''
    price = ''
    promo = ''
    today = str(datetime.datetime.now()).split(".")[0]
    soup = BeautifulSoup(res, 'lxml')
    try:
        if soup.find_all('div', {'class': '_3liAhj'}) is not None:
            items=soup.find_all('div', {'class': '_3liAhj'})
            if len(items)>1:
                for li in items:
                    try:
                        Name = li.find('a', {'class': '_2cLu-l'})['title']
                    # print(Name)
                        ProdURL = 'https://www.flipkart.com' + li.find('a', {'class': 'Zhf2z-'})['href']
                    # if '/gp/slredirect' in ProdURL:
                    #     ProdURL = 'https://www.amazon.de' + ProdURL
                    # print(ProdURL)
                        price=promo=li.find('div', {'class': '_1vC4OE'}).text.replace("₹",'').replace(',','')
                        Manufacturer = Name.split(' ')[0]
                    # print(Manufacturer)
                        mpn_tag=ProdURL.split('?')[1]
                        mpn_tag=mpn_tag.split('&')[0]
                        Itemnumber=mpn=mpn_tag.split("=")[1]
                    # print(mpn)

                        temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                                'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                                'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                                'Category URL': url, 'Crawling Date': today}
                        DataOut.append(temp)
                        sqldata.append(temp)

                    except Exception as e:
                        print(Name)
                        print('error in Product')

            else:
                items=soup.find_all('div', {'class': '_1UoZlX'})
                if len(items)<=1:
                    content=False
                for li in items:
                    try:
                        Name = li.find('div', {'class': '_3wU53n'}).text
                    # print(Name)
                        ProdURL = 'https://www.flipkart.com' + li.find('a', {'class': '_31qSD5'})['href']
                    # if '/gp/slredirect' in ProdURL:
                    #     ProdURL = 'https://www.amazon.de' + ProdURL
                    # print(ProdURL)
                        price=promo=li.find('div', {'class': '_1vC4OE _2rQ-NK'}).text.replace("₹",'').replace(',','')
                        Manufacturer = Name.split(' ')[0]
                    # print(Manufacturer)
                        mpn_tag=ProdURL.split('?')[1]
                        mpn_tag=mpn_tag.split('&')[0]
                        Itemnumber=mpn=mpn_tag.split("=")[1]
                    # print(mpn)

                        temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                                'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                                'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                                'Category URL': url, 'Crawling Date': today}
                        DataOut.append(temp)
                        sqldata.append(temp)

                    except Exception as e:
                        print(Name)
                        print('error in Product')


    except Exception as e:
        temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                'Category URL': url, 'Crawling Date': today}
        DataOut.append(temp)
        sqldata.append(temp)
    return DataOut


def Push_TO_Sql(df):
    ''''add here'''
    connStr = pyodbc.connect('DRIVER={SQL Server};SERVER=ecxus249;DATABASE=SHOPAMD;UID=SHOPAMD;PWD=SHOP@md2010')
    if connStr:
        # print('Connected To SQL Server')
        cursor = connStr.cursor()
        for index, row in df.iterrows():
            try:
                cursor.execute("INSERT INTO dbo.Master_Collation(LOB,Country,Site, CategoryURL,Itemnumber,MPN,Manufacturer,ProductName,ProductURL,Listprice,Promoprice,CurrencyType,RetailerID,Date) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", row['LOB'],row['Country'],row['Site'], row['Category URL'],row['ItemNumber'],row['MPN'],row['Manufacturer'],row['Name'],row['Product URL'],row['List Price'],row['Promo Price'],row['Currency'],row['Retailer ID'],row['Crawling Date'])
            except Exception as e:
                print(e)
        connStr.commit()
        print('Sucessfully Stored Records To DB')
        cursor.close()
        connStr.close()


print("start")
LOB = ''
site = ''
country = ''
CurrencyType = ''
RetailerId = ''
CategoryURL = ''
excel_To_List()
col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price', 'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']
for url in input:
    if 'flipkart' in url:
        # print(url)
        indx = url.index('^')
        if indx != 0:
            CategoryURL = url
            LOB = url[:indx]
            url = url[indx+1:]
            splitURL = url.split('/')
            hostpart = splitURL[2].split('.')
            country = 'India'
            site = 'flipkart-in'
            RetailerId = '96004'
            country = "India"
            CurrencyType = 'INR'
        print(url)
        res1=fetch_data(url)
        check=True
        content=True
        i=1
        while check:
            tempurlp=url.replace("&page=1",'&page=')
            caturl=tempurlp+str(i)
            response = fetch_data(caturl)
            Extract_data(response, url)
            # if driver.find_element_by_id('pagnNextLink') is not None:
            #     # CatRes = driver.find_element_by_id('pagnNextLink')
            #     # CatRes.click()
            #     driver.find_element_by_link_text("Página siguiente").click()
            # else:
            #    print('No Button to Click')
            #    break
            Result_SQL = pd.DataFrame(sqldata, columns=col)
            Push_TO_Sql(Result_SQL)
            sqldata.clear()
            result_out_excel(DataOut)
            i=i+1
            get_PageNo()
driver.close()
