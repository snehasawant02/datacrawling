import datetime
import requests
import os
import re
import random
from bs4 import BeautifulSoup
from openpyxl import load_workbook
import xlsxwriter
import pandas as pd
from pandas import ExcelWriter
import pyodbc
import string

sess = requests.session()
sess.headers = ({
    'Connection': 'keep-alive',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36',
    'Upgrade-Insecure-Requests': '1',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-GB,en;q=0.9,en-US;q=0.8,hi;q=0.7'})
input = []
DataOut = []
sqldata=[]
proxy_set = ["https://eclerxamd:Rid8B67I2Q@shp-prx109-br-v00001.tp-ns.com:80",
             "https://eclerxamd:Rid8B67I2Q@shp-prx109-br-v00002.tp-ns.com:80",
             "https://eclerxamd:Rid8B67I2Q@shp-prx109-ca-v00002.tp-ns.com:80",
             "https://eclerxamd:Rid8B67I2Q@shp-prx109-ca-v00001.tp-ns.com:80",
             "https://eclerxamd:Rid8B67I2Q@shp-prx109-ca-v00003.tp-ns.com:80",
             "https://eclerxamd:Rid8B67I2Q@shp-prx109-cn-v00002.tp-ns.com:80",
             "https://eclerxamd:Rid8B67I2Q@shp-prx109-cn-v00001.tp-ns.com:80",
             "https://eclerxamd:Rid8B67I2Q@shp-prx109-de-v00001.tp-ns.com:80",
             "https://eclerxamd:Rid8B67I2Q@shp-prx109-de-v00002.tp-ns.com:80",
             "https://eclerxamd:Rid8B67I2Q@shp-prx109-de-v00003.tp-ns.com:80",
             "https://eclerxamd:Rid8B67I2Q@shp-prx109-de-v00004.tp-ns.com:80",
             "https://eclerxamd:Rid8B67I2Q@shp-prx109-es-v00001.tp-ns.com:80",
             "https://eclerxamd:Rid8B67I2Q@shp-prx109-es-v00002.tp-ns.com:80",
             "https://eclerxamd:Rid8B67I2Q@shp-prx109-fr-v00005.tp-ns.com:80",
             "https://eclerxamd:Rid8B67I2Q@shp-prx109-fr-v00006.tp-ns.com:80",
             "https://eclerxamd:Rid8B67I2Q@shp-prx109-fr-v00007.tp-ns.com:80",
             "https://eclerxamd:Rid8B67I2Q@shp-prx109-fr-v00002.tp-ns.com:80",
             "https://eclerxamd:Rid8B67I2Q@shp-prx109-fr-v00003.tp-ns.com:80",
             "https://eclerxamd:Rid8B67I2Q@shp-prx109-fr-v00001.tp-ns.com:80",
             "https://eclerxamd:Rid8B67I2Q@shp-prx109-fr-v00004.tp-ns.com:80",
             "https://eclerxamd:Rid8B67I2Q@shp-prx109-in-v00001.tp-ns.com:80",
             "https://eclerxamd:Rid8B67I2Q@shp-prx109-in-v00002.tp-ns.com:80",
             "https://eclerxamd:Rid8B67I2Q@shp-prx109-se-v00003.tp-ns.com:80",
             "https://eclerxamd:Rid8B67I2Q@shp-prx109-se-v00002.tp-ns.com:80",
             "https://eclerxamd:Rid8B67I2Q@shp-prx109-se-v00001.tp-ns.com:80"]


def excel_To_List():
    wb =load_workbook(filename='E:\Python\AMD Script\Input.xlsx')
    #wb = load_workbook(filename='E:\Prasad\Input.xlsx')
    ws = wb['Sheet1']
    row = ws.max_row
    col = ws.max_column
    for row in ws.iter_rows(min_row=1, min_col=0, max_row=row, max_col=1):
        for cell in row:
            input.append(cell.value)
    wb.close()


def fetch_data(url):
    # no = random.randint(0, len(proxy_set)-1)
    # temp = proxy_set[no]
    sess.proxies = {"https": "https://eclerxamd:Rid8B67I2Q@shp-prx109-de-v00001.tp-ns.com:80"}
    res = ''
    try:
        res = sess.get(url).text
    except Exception as e:
        print("type error: " + str(e))
    return res


def get_PageNo(res):
        soup = BeautifulSoup(res, 'lxml')
        products = ''
        try:
            if soup.find("div", {'class': 'totalResults'}) is not None:
                PageDiv = soup.find("div", {'class': 'totalResults'}).text.replace("\n", '').replace('\t', '')
                regx = re.compile(r'\d+')
                no = regx.search(PageDiv)
                if no:
                    products = int(no.group())
            elif soup.find('ol', {'class': 'seriesListings'}) is not None:
                oltag = soup.find('ol', {'class': 'seriesListings'})
                licount = oltag.find_all('li', {'class': 'seriesListings-itemContainer'})
                products = len(licount)
            elif soup.find('div', {'class': 'accessories-pagination'}) is not None:
                tag = soup.find('div', {'class': 'accessories-pagination'}).find('li', {'class': 'last'}).find('a')['href'][-1]
                Pages = int(tag) + 1
                return Pages
            else:
                products = soup.find('span', {'id': 'js-results-count-ui'}).text
            if products is not "":
                Pages = int(products / 8)
                if products % 8 > 0:
                    Pages += 1
            else:
                Pages = 0
        except Exception as e:
            Pages = 0
        return Pages


def Extract_data(res, url):
    Itemnumber = ''
    mpn = ''
    Manufacturer = ''
    Name = ''
    ProdURL = ''
    price = ''
    promo = ''
    today = str(datetime.datetime.now()).split(".")[0]
    soup = BeautifulSoup(res, 'lxml')
    try:
        if soup.find('div', {'id': 'resultsList'}) is not None:
            container = soup.find('div', {'id': 'resultsList'})
            block = container.find_all('div', {'class': 'facetedResults-item only-allow-small-pricingSummary'})
            for li in block:
                Name = li.find('h3', {'class': 'facetedResults-title'}).find('a').text
                namepart = Name.split(" ")
                Manufacturer = namepart[0]
                try:
                    Desc = li.find('div', {'class': 'facetedResults-feature-list'}).text.replace('\r', '').replace('\n','').replace('\t', '').strip()
                    Name = Name + '^^' + Desc
                except:
                    pass

                ProdURL = "https://www3.lenovo.com" + li.find('h3', {'class': 'facetedResults-title'}).find('a')['href']
                try:
                    promo = price = float(li.find('dd', {'itemprop': 'price'}).text.replace('\n', '').replace('\t', '').replace('€', '').replace('.','').replace(",", "").replace(" ",""))/100
                    # pr_sp = [word for word in price if word not in string.ascii_letters]
                    # price_main = ''
                    # for sp in pr_sp:
                    #     if sp=='.':
                    #         price_main=price_main + sp
                    #     else:
                    #         try:
                    #             i=int(sp)
                    #             price_main = price_main + sp
                    #         except:
                    #             pass
                    # price =promo= price_main
                except Exception as es:
                    promo = price = float(li.find('dt', {'class': 'webprice'}).find('strike').text.replace('\n', '').replace('\t', '').replace('€', '').replace('.','').replace(",", "").replace(" ","").replace("A",""))/100
                    # pr_sp = [word for word in price1 if word not in string.ascii_letters]
                    # price_main = ''
                    # for sp in pr_sp:
                    #     if sp=='.':
                    #         price_main=price_main + sp
                    #     else:
                    #         try:
                    #             i=int(sp)
                    #             price_main = price_main + sp
                    #         except:
                    #             pass
                    # price = price_main
                    #
                    # promo1 = li.find('dd', {'class': 'saleprice'}).text.replace('€', '').replace(",", ".").replace(" ","")
                    # pr_sp = [word for word in promo1 if word not in string.ascii_letters]
                    # price_main = ''
                    # for sp in pr_sp:
                    #     if sp=='.':
                    #         price_main=price_main + sp
                    #     else:
                    #         try:
                    #             i=int(sp)
                    #             price_main = price_main + sp
                    #         except:
                    #             pass
                    # promo = price_main
                if li.find('input', {'name': 'productCodePost'})is not None:
                    Itemnumber = li.find('input', {'name': 'productCodePost'})['value']
                else:
                    Itemnumber = ProdURL.split('/')[-1]
                mpn = Itemnumber
                temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                        'Manufacturer': Manufacturer,
                        'Name': Name, 'Product URL': ProdURL, 'List Price': price, 'Promo Price': promo,
                        'Currency': CurrencyType, 'Retailer ID': RetailerId, 'Category URL': CategoryURL,
                        'Crawling Date': today}
                DataOut.append(temp)
                sqldata.append(temp)
        elif soup.find('ol',{'class': 'facetsSearchListing'}): #---Processor, Graphics card
            container = soup.find("ol", {"class": "facetsSearchListing"})
            block = container.find_all('li', {"class": "qa_item_container"})
            for li in block:
                Name = li.find("h3", {"class": "qa_product_title"}).find("a").text
                Manufacturer = Name.split(" ")[0]
                try:
                    Desc = li.find('div', {'class': 'facetedResults-feature-list'}).text.replace('\r', '').replace('\n','').replace('\t', '').strip()
                    Name = Name + '^^' + Desc
                except:
                    pass
                ProdURL = "https://www3.lenovo.com" + li.find('h3', {'class': 'qa_product_title'}).find('a')['href']
                if li.find('dd',{'potentialcoupontype': 'COUPONPRICE'}) is None:
                    promo = price = float(li.find('dd', {'class': 'qa_final_price'}).text.replace('.', '').replace(',', '').replace('€', '').strip())/100
                else:
                    promo = price = li.find('dd',{'potentialcoupontype': 'COUPONPRICE'})['potentialcouponprice']
                mpn = Itemnumber = ProdURL.split('/')[-1]
                temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                        'Manufacturer': Manufacturer,
                        'Name': Name, 'Product URL': ProdURL, 'List Price': price, 'Promo Price': promo,
                        'Currency': CurrencyType, 'Retailer ID': RetailerId, 'Category URL': CategoryURL,
                        'Crawling Date': today}
                DataOut.append(temp)
                sqldata.append(temp)
        else:
            container = soup.find("ol", {"class": "seriesListings"})
            block = container.find_all('li', {"class": "seriesListings-itemContainer"})
            for li in block:
                Name = li.find("h3", {"class": "seriesListings-title"}).find("a").text
                namepart = Name.split(" ")
                Manufacturer = namepart[0]
                try:
                    Desc=li.find('div',{'class':'facetedResults-feature-list'}).text.replace('\r','').replace('\n','').replace('\t','').strip()
                    Name=Name+'^^'+Desc
                except:
                    pass

                ProdURL = "https://www3.lenovo.com" + li.find('h3', {'class': 'seriesListings-title'}).find('a')['href']
                promo = price = "Check for price"
                IMSplit = ProdURL.split('/')
                ind = IMSplit.__len__() - 1
                Itemnumber = IMSplit[ind]
                mpn = Itemnumber
                temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                        'Manufacturer': Manufacturer,
                        'Name': Name, 'Product URL': ProdURL, 'List Price': price, 'Promo Price': promo,
                        'Currency': CurrencyType, 'Retailer ID': RetailerId, 'Category URL': CategoryURL,
                        'Crawling Date': today}
                DataOut.append(temp)
                sqldata.append(temp)
    except Exception as e:
        temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                'Manufacturer': Manufacturer,
                'Name': Name, 'Product URL': ProdURL, 'List Price': price, 'Promo Price': promo,
                'Currency': CurrencyType, 'Retailer ID': RetailerId, 'Category URL': CategoryURL,
                'Crawling Date': today}
        DataOut.append(temp)
        sqldata.append(temp)


def Push_TO_Sql(df):
    ''''add here'''
    connStr = pyodbc.connect('DRIVER={SQL Server};SERVER=ecxus249;DATABASE=SHOPAMD;UID=SHOPAMD;PWD=SHOP@md2010')
    if connStr:
        # print('Connected To SQL Server')
        cursor = connStr.cursor()
        for index, row in df.iterrows():
            try:
                cursor.execute("INSERT INTO dbo.Master_Collation(LOB,Country,Site,Itemnumber,MPN,Manufacturer,ProductName,ProductURL,Listprice,Promoprice,CurrencyType,RetailerID,CategoryURL,Date) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", row['LOB'],row['Country'],row['Site'],row['ItemNumber'],row['MPN'],row['Manufacturer'],row['Name'],row['Product URL'],row['List Price'],row['Promo Price'],row['Currency'],row['Retailer ID'], row['Category URL'],row['Crawling Date'])
            except Exception as e:
                print(e)
        connStr.commit()
        print('Sucessfully Stored Records To DB')
        cursor.close()
        connStr.close()


def result_out_excel(DataOut):
    col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price', 'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']
    dt = str(datetime.date.today())
    filename = site + "_" + dt
    path = "E:\Python\AMD Script\Output\\" +filename+".xlsx"
    df = pd.DataFrame(DataOut, columns=col)
    writer = ExcelWriter(path)
    df.to_excel(writer, 'Sheet1', index=False)
    writer.save()

print("start")
LOB = ''
site = ''
country = ''
CurrencyType = ''
RetailerId = ''
CategoryURL = ''
excel_To_List()
today = str(datetime.date.today())
col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price',
           'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']
for url in input:
    # if "lenovo.com/de" in url and 'Processor^' in url:
    if "lenovo.com/de" in url:
        print(url)
        indx = url.index('^')
        if indx != 0:
            LOB = url[:indx]
            url = url[indx + 1:]
        CategoryURL = url
        splitURL = url.split('/')
        country = splitURL[3].lower()
        if splitURL[2] == "www3.lenovo.com":
            site = splitURL[2].replace('www3.', '').replace('.com', '') + "-" + country
        else:
            site = splitURL[2].replace('www.', '').replace('.com', '') + "-" + country
        RetailerId = "95986"
        country = "Germany"
        CurrencyType = "EURO"
        response = fetch_data(url)
        Pages = int(get_PageNo(response))
        for i in range(0, Pages):
            if "page=" in url:
                len = url.index('page=')
                if 'page=' in url:
                    len = url.index('page=')
                    if len != 0:
                        caturl = url[:len + 5] + str(i)
                else:
                    caturl = url
                # caturl = url[:len + 5] + str(i)
                CatRes = fetch_data(caturl)
                Extract_data(CatRes, url)
        Result_SQL = pd.DataFrame(sqldata, columns=col)
        Push_TO_Sql(Result_SQL)
        sqldata.clear()
result_out_excel(DataOut)
print("Crawling Completed Successfully")
