from pandas import ExcelWriter
import pandas as pd
from openpyxl import load_workbook
import pyodbc
import datetime
import requests
from pandas.io.json import json_normalize
import os
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import json
import string

chromedriver = "E:\Python\AMD Daily Python Crwalers\chromedriver.exe"
os.environ["webdriver.chrome.driver"] = chromedriver

options = Options()
# options.add_argument('--headless')
options.add_argument('--disable-gpu')  # Last I checked this was necessary.

driver = webdriver.Chrome(chromedriver, chrome_options=options)
driver.set_page_load_timeout(120)

input=[]
DataOut=[]
sqldata=[]

sess = requests.session()
sess.headers = ({
    'Connection': 'keep-alive',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36',
    'Upgrade-Insecure-Requests': '1',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-GB,en;q=0.9,en-US;q=0.8,hi;q=0.7'})


def excel_To_List():
    wb = load_workbook(filename='E:\Python\AMD Script\Input.xlsx')
    # wb = load_workbook(filename='E:\Python\AMD Script\Input.xlsx')
    ws = wb['Sheet1']
    row = ws.max_row
    col = ws.max_column
    for row in ws.iter_rows(min_row=2, min_col=0, max_row=row, max_col=1):
        for cell in row:
            if cell.value is not None and "mindfactory.de" in cell.value:
                input.append(cell.value)
    wb.close()


def fetch_data(url):
    res = ''
    proxy = {'https': 'https://eclerxamd:Rid8B67I2Q@shp-prx109-de-v00002.tp-ns.com:80'}
    try:
        driver.get(url)
        # driver.get(url)
    except Exception as e:
        print("type error: " + str(e))
    res = driver.page_source
    return res


def get_PageNo(res):
    soup = BeautifulSoup(res, 'lxml')
    try:
        # if soup.find('ul', {'class': 'pagination pull-right'}) is not None:
        if driver.find_element_by_class_name('pagination') is not None:
            Pages = int(driver.find_element_by_class_name('pagination').text.replace('Seite 1 von ',''))
        else:
            Pages = 1
    except Exception as e:
        Pages = 1
    return Pages

def Extract_data(res, url):
    Itemnumber = ''
    mpn = ''
    Manufacturer = ''
    Name = ''
    ProdURL = ''
    price = ''
    promo = ''
    today = str(datetime.datetime.now()).split(".")[0]
    res1 = driver.get(url)
    soup = driver.page_source
    # soup = BeautifulSoup(res, 'lxml')
    # soup = json.loads(res.text)
    try:
        # container = soup.find('div', {'id':'bProducts'})
        # items = soup.find_all('div', {'class': 'pcontent'})
        test = driver.find_elements_by_class_name('pcontent')
        for li in test:
            try:
                if li.find_element_by_class_name('pname') is not None:
                    Name = li.find_element_by_class_name('pname').text
                # print(Name)
                if li.find_element_by_class_name('phover-complete-link') is not None:
                    ProdURL = li.find_element_by_class_name('phover-complete-link').get_attribute('href')
                # print(ProdURL)
                if Name is not None:
                    Manufacturer = Name.split(' ')[0]
                else:
                    Manufacturer = 'Manufacturer not available'
                # mpn = ProdURL.split('_')[2].replace('.html','')
                # print(mpn)
                if ProdURL is not None:
                    mpn = Itemnumber = ProdURL.split('_')[2].replace('.html','')
                    # print(Itemnumber)
                # if li.find('div', {'class': 'pprice'}) is not None:
                #     get_pr= li.find('div', {'class': 'pprice'}).text.replace('.', '').replace('€', '').replace(',', '.').replace('*','').strip()
                #     pr_sp=[word for word in get_pr if word not in string.ascii_letters]
                #     price_main=''
                #     for sp in pr_sp[0:len(pr_sp) - 1]:
                #         price_main = price_main + sp
                #     promo = price = price_main
                #     # print(promo)
                if li.find_element_by_class_name('pprice') is not None:
                    price = promo = li.find_element_by_class_name('pprice').text.replace('€ ','').replace('.','').replace('*','').replace(',','.')
                else:
                    price = promo = 'Check for Price'

                temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                        'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                        'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                        'Category URL': url, 'Crawling Date': today}
                DataOut.append(temp)
                sqldata.append(temp)
            except Exception as e:
                print(Name)
                print('error in Product')

    except Exception as e:
        temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                'Category URL': url, 'Crawling Date': today}
        DataOut.append(temp)
        sqldata.append(temp)
    return DataOut


def Push_TO_Sql(df):
    ''''add here'''
    connStr = pyodbc.connect('DRIVER={SQL Server};SERVER=ecxus249;DATABASE=SHOPAMD;UID=SHOPAMD;PWD=SHOP@md2010')
    if connStr:
        # print('Connected To SQL Server')
        cursor = connStr.cursor()
        for index, row in df.iterrows():
            cursor.execute("INSERT INTO dbo.Master_Collation(LOB,Country,Site,Itemnumber,MPN,Manufacturer,ProductName,ProductURL,Listprice,Promoprice,CurrencyType,RetailerID,CategoryURL,Date) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",row['LOB'], row['Country'], row['Site'], row['ItemNumber'], row['MPN'], row['Manufacturer'],row['Name'], row['Product URL'], row['List Price'], row['Promo Price'], row['Currency'],row['Retailer ID'], row['Category URL'], row['Crawling Date'])
            try:
                pass
            except Exception as e:
                print(e)
        connStr.commit()
        print('Sucessfully Stored Records To DB')
        cursor.close()
        connStr.close()


def Result_Out_Excel(DataOut):
    col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price',
           'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']

    dt = str(datetime.date.today())
    filename = "mindfactory_de" + dt
    path = "E:\Python\AMD Script\Output\\" +filename+".xlsx"
    # path = "E:\SAYAR PROJECTS\PYTHON\AMD_CNCT\Output\\" + filename + ".xlsx"
    df = pd.DataFrame(DataOut, columns=col)
    writer = ExcelWriter(path)
    df.to_excel(writer, 'Sheet1', index=False)
    writer.save()
    return df


print("start")
LOB = ''
site = ''
country = ''
CurrencyType = ''
RetailerId = ''
CategoryURL = ''
excel_To_List()
col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price',
           'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']

for url in input:
    print(url)
    indx = url.index('^')
    if indx != 0:
        LOB = url[:indx]
        url = url[indx+1:]
        CategoryURL = url
        splitURL = url.split('/')
        country = 'de'
        site = splitURL[2].replace('www.', '').replace('.de', '-') + country
        if country == 'de':
            RetailerId = '31025'
            country = "Germany"
            CurrencyType = 'EURO'
        endpart = splitURL[-1].split('?')
    response = fetch_data(url)
    Pages = int(get_PageNo(response))
    for i in range(1, Pages+1):
        caturl = url+ str('/') +str(i)
        print(caturl)
        CatRes = fetch_data(caturl)
        Extract_data(CatRes, caturl)
        Result_SQL = pd.DataFrame(sqldata, columns=col)
        Push_TO_Sql(Result_SQL)
        sqldata.clear()
    Result_Out_Excel(DataOut)
print('Completed')