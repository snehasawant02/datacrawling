'''
Last Modified By : sayar
Last Modified Date : 29/8/2018
'''
import datetime
import requests
import re
import json
from bs4 import BeautifulSoup
from openpyxl import load_workbook
import xlsxwriter
import pyodbc
import pandas as pd
from pandas import ExcelWriter
import random
import os
from selenium  import webdriver
from selenium.webdriver.chrome.options import Options

chromedriver = "E:\Python\AMD Daily Python Crwalers\chromedriver.exe"
os.environ["webdriver.chrome.driver"] = chromedriver

options = Options()
# options.add_argument('--headless')
options.add_argument('--disable-gpu')



input = []
DataOut = []
sqldata=[]
headerslist= ['Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.65 Safari/537.36',
              'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.104 Safari/537.36',
              'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36',
              'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.93 Safari/537.36'
              ]

#proxy= {'https': 'https://216.227.130.13:80'}
proxy = {'https': 'https://eclerxamd:Rid8B67I2Q@shp-prx109-de-v00003.tp-ns.com:80'}

def excel_to_list():
    wb = load_workbook(filename='E:\Python\AMD Script\Input.xlsx')
    # wb = load_workbook(filename='E:\Python\AMD Script\Input.xlsx')
    ws = wb['Sheet1']
    row = ws.max_row
    col=ws.max_column
    for row in ws.iter_rows(min_row=2, min_col=0, max_row=row, max_col=1):
        for cell in row:
            if "wortmann.de" in cell.value:
                input.append(cell.value)
    wb.close()

def extract_data(res, url, CategoryURL):
    Itemnumber = ''
    mpn = ''
    Manufacturer = ''
    Name = ''
    ProdURL = ''
    price = ''
    promo = ''
    today = str(datetime.datetime.now()).split(".")[0]
    soup = BeautifulSoup(res, 'lxml')

    try:
        if soup.find('div', {'class': 'list-group-item product'}) is not None:
            block= soup.find_all('div', {'class': 'list-group-item product'})
            for li in block:
                try:
                    json_text=li.find('input',{'type':'hidden'})['value']
                    data = json.loads(json_text)
                    if li.find('div', {'class': 'product-description'}) is not None:
                        prod_desc = li.find('div', {'class': 'product-description'}).text.replace('\t\n', ' ').replace('\t', '').replace('\n', '').strip()
                    Name = data['Title'] + "^^" + prod_desc
                    Manufacturer = data['Title'].split(' ')[0]
                    ProdURL ='https://www.wortmann.de/de-DE/'+ li.find('div',{'class':'product-description'}).find('a')['href']

                    promo = price = data['ListPrice']
                    if price == 0:
                        promo = price = 'Check For Price'
                    Itemnumber = data['ProductId']
                    mpn = Itemnumber
                    temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                            'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                            'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                            'Category URL': url, 'Crawling Date': today}
                    DataOut.append(temp)
                    sqldata.append(temp)
                except Exception as e:
                    # print("error in product")
                    print(Name)
    except Exception as e:
        temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                'Category URL': url, 'Crawling Date': today}
        DataOut.append(temp)
        sqldata.append(temp)
    return DataOut


def push_to_sql(df):
    ''''add here'''
    conn_str = pyodbc.connect('DRIVER={SQL Server};SERVER=ecxus249;DATABASE=SHOPAMD;UID=SHOPAMD;PWD=SHOP@md2010')
    if conn_str:
        # print('Connected To SQL Server')
        cursor = conn_str.cursor()
        for index,row in df.iterrows():
            try:
                cursor.execute("INSERT INTO dbo.Master_Collation(LOB,Country,Site,Itemnumber,MPN,Manufacturer,ProductName,ProductURL,Listprice,Promoprice,CurrencyType,RetailerID, CategoryURL, Date) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", row['LOB'],row['Country'],row['Site'],row['ItemNumber'],row['MPN'],row['Manufacturer'],row['Name'],row['Product URL'],row['List Price'],row['Promo Price'],row['Currency'],row['Retailer ID'], row['Category URL'],row['Crawling Date'])
            except Exception as e:
                print("String SQL", e)
        conn_str.commit()
        print('Sucessfully Stored Records To DB')
        cursor.close()
        conn_str.close()


def result_out_excel(DataOut):
    col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price', 'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']
    dt = str(datetime.date.today())
    filename = site + "_" + dt
    path = "E:\Python\AMD Script\Output\\" + filename + ".xlsx"
    df = pd.DataFrame(DataOut, columns=col)
    writer = pd.ExcelWriter(path, engine='xlsxwriter', options={'strings_to_urls': False})
    df.to_excel(writer, 'Sheet1', index=False)
    writer.save()


print("start")
LOB = ''
site = ''
country = ''
CurrencyType = ''
RetailerId = ''
CategoryURL = ''
col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price',
           'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']
excel_to_list()
driver = webdriver.Chrome(chromedriver, chrome_options=options)
for url in input:
    if "wortmann.de" in url:
        # print(url)
        indx = url.index('^')
        if indx != 0:
            LOB = url[:indx]
            url = url[indx+1:]
            CategoryURL = url
            splitURL = url.split('/')
            country = splitURL[2].split('.')[2]
            if country == "de":
                RetailerId = "95995"
                country = 'Germany'
                CurrencyType = "EURO"
            site = splitURL[2].replace('www.', '').replace('.', '-')
        driver.get(url)
        while(True):
            extract_data(driver.page_source, url, CategoryURL)
            Result_SQL = pd.DataFrame(sqldata, columns=col)
            push_to_sql(Result_SQL)
            sqldata.clear()

            try:
                soup=BeautifulSoup(driver.page_source,'lxml')
                page=soup.find_all('div',{'class':'col-sm-4'})
                page_sp=''
                for p in page:
                    if 'Ergebnisse' in p.text:
                        page_sp=p.text.replace('Ergebnisse','').split('von')[1].strip()
                        break
                if(int(page_sp))<=10:
                    break
                next=driver.find_element_by_id('ctl00_ctl00_ctl00_SiteContent_SiteContent_SiteContent_SolrProductDisplay_BulkPagerTop_ButtonNext')
                dis=next.get_attribute('disabled')
                if dis is None:
                    next.find_element_by_tag_name('i').click()
                else:
                    break
            except:
                pass
result_out_excel(DataOut)
driver.quit()
#driver.close()

print("Crawling completed Successfully.")
