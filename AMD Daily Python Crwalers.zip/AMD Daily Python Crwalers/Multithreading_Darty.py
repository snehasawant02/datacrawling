'''
!/usr/bin/env python
title           : Best_Buy.py
description     : To crawl Product information uisng python(Selenium,BS4)
author          : Sayar Mendis
date            : 6-8-2018
version         : 0.1
python_version  : 3.6.4
==============================================================================
'''

import time
from multiprocessing.dummy import Pool
import os
from openpyxl import load_workbook
import datetime
import pandas as pd
from selenium.webdriver.chrome.options import Options
from selenium import webdriver
from bs4 import BeautifulSoup as bs
import zipfile
import pyodbc
import openpyxl

class Pixmania_MT():

    def __init__(self): 
        self.inputs=[]

        self.RetailerId=''
        self.CurrencyType=''
        self.Count=1
        self.Output=[]
        self.Product_URL=[]
        self.Excel_out=[]

    def excel_To_List(self):
        wb = load_workbook(filename ='E:\Python\AMD Script\Input.xlsx')
        ws = wb['Sheet7']
        row = ws.max_row
        col = ws.max_column
        for row in ws.iter_rows(min_row=0, min_col=0, max_row=row, max_col=1):
            for cell in row:
                url=cell.value
                if 'darty.com' in url:
                    indx = url.index('^')
                    if indx != 0:
                        LOB = url[:indx]
                        url = url[indx + 1:]
                        CategoryURL = url+":>>"+LOB
                        url = url.replace("http:", "https:")
                        splitURL = url.split('/')
                        hostpart = splitURL[2].split('.')
                        country = hostpart[2].upper()
                        self.RetailerId = "95972"
                        self.CurrencyType = "EURO"
                    self.inputs.append(CategoryURL)
        wb.close()
        return self.inputs

    def Result_Out_Excel(self,DataOut):
        now = datetime.datetime.now()
        datstr = str(now.day) + '_' + str(now.month) + '_' + str(now.year)
        dirname = os.path.dirname(__file__)
        pathexcl = 'E:\Python\AMD Script\Output\\' + "Mul_Darty" + str(datstr) + '.xlsx'
        df = pd.DataFrame(DataOut)
        df.to_excel(pathexcl,index=False)

        # if os.path.isfile(pathexcl):
        #     book = openpyxl.load_workbook(pathexcl)
        #     sheet = book.get_sheet_by_name('Sheet1')
        #     r = sheet.max_row
        #     c = sheet.max_column
        # else:
        #

    def Get_Product_URL(self,urlg):
        try:
            # chromedriver = "chromedriver.exe"
            # os.environ["webdriver.chrome.driver"] = chromedriver
            # if(self.Count%4==0):
            #     # PROXY_HOST = '104.144.109.87'  # rotating proxy
            #     PROXY_HOST = 'shp-prx109-fr-v00001.tp-ns.com'
            # if (self.Count % 4 == 1):
            #     # PROXY_HOST = '104.144.43.40'
            #     PROXY_HOST = 'shp-prx109-fr-v00001.tp-ns.com'
            # if (self.Count % 4 == 2):
            #     # PROXY_HOST ='168.91.82.85'
            #     PROXY_HOST = 'shp-prx109-fr-v00001.tp-ns.com'
            # if (self.Count % 4 == 3):
            #     # PROXY_HOST ='168.91.84.114'
            #     PROXY_HOST = 'shp-prx109-fr-v00001.tp-ns.com'
            #
            # PROXY_PORT = 80
            # PROXY_USER = 'eclerxamd'
            # PROXY_PASS = 'Rid8B67I2Q'
            #
            # manifest_json = """
            #            {
            #                "version": "1.0.0",
            #                "manifest_version": 2,
            #                "name": "Chrome Proxy",
            #                "permissions": [
            #                    "proxy",
            #                    "tabs",
            #                    "unlimitedStorage",
            #                    "storage",
            #                    "<all_urls>",
            #                    "webRequest",
            #                    "webRequestBlocking"
            #                ],
            #                "background": {
            #                    "scripts": ["background.js"]
            #                },
            #                "minimum_chrome_version":"22.0.0"
            #            }"""
            # background_js = """
            # var config = {
            #         mode: "fixed_servers",
            #         rules: {
            #           singleProxy: {
            #             scheme: "http",
            #             host: "%s",
            #             port: parseInt(%s)
            #           },
            #           bypassList: ["localhost"]
            #         }
            #       };
            #
            # chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
            #
            # function callbackFn(details) {
            #     return {
            #         authCredentials: {
            #             username: "%s",
            #             password: "%s"
            #         }
            #     };
            # }
            #
            # chrome.webRequest.onAuthRequired.addListener(
            #             callbackFn,
            #             {urls: ["<all_urls>"]},
            #             ['blocking']
            # );
            # """ % (PROXY_HOST, PROXY_PORT, PROXY_USER, PROXY_PASS)
            # options = Options()
            # pluginfile = 'proxy_auth_plugin.zip'
            # with zipfile.ZipFile(pluginfile, 'w') as zp:
            #         zp.writestr("manifest.json", manifest_json)
            #         zp.writestr("background.js", background_js)
            # options.add_extension(pluginfile)
            # # options.add_argument('--headless')
            # options.add_argument('--disable-gpu')
            chromedriver = "chromedriver.exe"
            os.environ["webdriver.chrome.driver"] = chromedriver

            options = Options()
            # options.add_argument('--headless')

            options.add_argument('--disable-gpu')  # Last I checked this was necessary.

            driver = webdriver.Chrome(chromedriver, chrome_options=options)
            url=urlg.split(":>>")[0]
            LOB=urlg.split(":>>")[1]
            # driver = webdriver.Chrome(chromedriver, chrome_options=options)
            # driver.set_window_size(0,0)
            print('Running URL  : '+ url)
            driver.get(url)
            time.sleep(4)
            pages=0
            Check_Page=True
            while Check_Page:
                try:
                    html = driver.page_source
                    soup = bs(html, features='lxml')
                    block = soup.find_all('div', {'class': 'product_detail'})

                    for li in block:
                        productdata={}
                        productname=li.find('div', {'class': 'prd-family'}).text
                        purl= 'https://www.darty.com' + li.find('div', {'class': 'prd-family'}).find('a')['href']
                        itemsku=li.find('div',{'class':'comparator-item-trigger comparator_button'})['data-codic']
                        if li.find('div', {'class': 'sale_price'}) is not None:
                            price = li.find('span', {'class': 'darty_prix darty_normal'}).text.replace(' ','').replace('€', '').replace(',', '.').replace('*', '')
                        elif li.find('span', {'class': 'darty_prix darty_normal'}) == ' ':
                            price = 'Check for Price'
                        else:
                            price = 'Price Not Available'
                        list_price =price
                        # promo=getu.find('span', {'class': 'pix-price-int'}).text
                        productdata['LOB']=LOB
                        productdata['Country'] = 'FR'
                        productdata['Site'] = 'darty-fr'
                        productdata['ItemNumber'] = itemsku
                        productdata['MPN']=itemsku
                        productdata['Manufacturer'] = productname
                        productdata['Name'] = productname
                        productdata['Product URL'] = purl
                        productdata['List Price'] = list_price
                        # if promo =='':
                        productdata['Promo Price'] =list_price
                        # else:
                        #     productdata['Promo price'] = promo
                        productdata['Currency'] = self.CurrencyType
                        productdata['Retailer ID'] = self.RetailerId
                        productdata['Category URL'] = driver.current_url
                        today = str(datetime.datetime.now()).split(".")[0]
                        productdata['Crawling Date'] = today
                        self.Output.append(productdata)
                        self.Excel_out.append(productdata)

                except Exception as e:
                    print("Product details missing.")

                # try:
                #     next=driver.find_element_by_partial_link_text('suivante')
                #     webdriver.ActionChains(driver).move_to_element(next).click().perform()
                #
                # except Exception as e:
                #     Check_Page=False
                #     print("Button Not found.")# print('Last Page Hit')
            driver.close()
            print('Completed URL :',str(self.Count)+' Out of '+str(len(self.inputs)))
            self.Count += 1
            # if(self.Count%4==0):
            #     self.Save_Info()
            df = pd.DataFrame(self.Output)
            self.Push_TO_Sql(self.Output)
            self.Output.clear()
        except Exception as e:
            print('Page not hit: (Pagging Error)')
            # driver.close()

    def Multi_process_List(self, Inputs):
        i = 1
        pool = Pool(processes=5)
        pool_outputs = pool.map(self.Get_Product_URL, Inputs)
        pool.close()
        pool.join()


    def Push_TO_Sql(self,df):
        connStr = pyodbc.connect('DRIVER={SQL Server};SERVER=ecxus249;DATABASE=SHOPAMD;UID=SHOPAMD;PWD=SHOP@md2010')
        if connStr:
            print('Connected To SQL Server')
            cursor = connStr.cursor()
            for row in df:
                try:
                    cursor.execute(
                        "INSERT INTO dbo.Master_Collation(LOB,Country,Site,CategoryURL,Itemnumber,MPN,Manufacturer,ProductName,ProductURL,Listprice,Promoprice,CurrencyType,RetailerID,Date) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        row['LOB'], row['Country'], row['Site'], row['Category URL'], row['ItemNumber'], row['MPN'], row['Manufacturer'],
                        row['Name'], row['Product URL'], row['List Price'], row['Promo Price'], row['Currency'],
                        row['Retailer ID'], row['Crawling Date'])
                except Exception as e:
                    print(str(e))
            connStr.commit()
            print('Sucessfully Stored Records To DB')
            cursor.close()
            connStr.close()

if __name__=='__main__':

    Px=Pixmania_MT()
    Inputs=Px.excel_To_List()
    Px.Multi_process_List(Inputs)
    Px.Result_Out_Excel(Px.Excel_out)
    # Px.Save_Info()