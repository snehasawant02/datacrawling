from pandas import ExcelWriter
import pandas as pd
import pyodbc
from tkinter.tix import ResizeHandle
import datetime
import requests
import os
import re
from bs4 import BeautifulSoup
from openpyxl import load_workbook
import xlsxwriter

#sess = requests.session()
headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36',
           'content-type': 'text/html;charset=UTF-8',
           'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
           'Host': 'www.amazon.de'}
input = []
DataOut = []
sqldata=[]

def excel_To_List():
    # wb = load_workbook(filename='E:\Python\AMD Script\Hemant Test\InputHK.xlsx')
    wb= load_workbook(filename='E:\Python\AMD Script\Input.xlsx')
    ws = wb['Sheet1']
    row = ws.max_row
    col=ws.max_column
    for row in ws.iter_rows(min_row=2, min_col=0, max_row=row, max_col=1):
        for cell in row:
            if cell.value is not None and "amazon.de" in cell.value:
                input.append(cell.value)
    wb.close()

def Result_Out_Excel(DataOut):
    col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price',
           'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']

    dt = str(datetime.date.today())
    filename = "amazon.de_" + dt
    path = "E:\Python\AMD Script\Output\\" + filename + ".xlsx"
    # path = "E:\SAYAR PROJECTS\PYTHON\AMD_CNCT\Output\\" + filename + ".xlsx"
    df = pd.DataFrame(DataOut, columns=col)
    writer = ExcelWriter(path)
    df.to_excel(writer, 'Sheet1', index=False)
    writer.save()
    return df


def fetch_data(url):
    res = ''
    proxy = {'https': 'https://eclerxamd:Rid8B67I2Q@shp-prx109-de-v00003.tp-ns.com:80'}
    try:
        res = requests.get(url, proxies=proxy).text
    except Exception as e:
        print("type error: " + str(e))
    return res

def get_PageNo(res):
    soup = BeautifulSoup(res, 'lxml')
    try:
        Pagination = soup.find('li', {'class': 'a-last'})
        Pages= Pagination.find('span',{'class': "paging--display"}).text.replace("von", "").replace("\n", "").strip()
        #PageDiv= Pagination.find_all("a", title='Nächste Seite')
        #pagi= PageDiv.find("span", style='letter-spacing:1px;')
       # pg= pagi.find_all("a", target='_top')
        #for i in pg:
        #Pages= i.text

        #Pages= Pages.replace("[", "").replace("]", "").strip()
        print(Pages)
    except Exception as e:
        Pages = 1
    return Pages

def Extract_data(res, url):
    soup = BeautifulSoup(res, 'lxml')
    today = datetime.datetime.today()
    try:
        container = soup.find('div', {'class': 's-main-slot s-result-list s-search-results sg-row'})
        liBlock = container.find_all('div', {'class': 'sg-col-20-of-24 s-result-item'})
        for li in liBlock:
            Name = li.find('span', {'class': 'a-size-medium a-color-base a-text-normal'}).text.replace("\n", "").strip()

            try:
                Desc = li.find('div', {'class': 'product--description'}).text.replace("\n", " ").strip()
                Name = Name + "^^" + Desc
            except:
                pass
            namepart = Name.split(" ")
            Manufacturer = namepart[0]
            ProdURL = li.find('a', {'class': 'a-link-normal'})['href']
            Itemnumber = li.find('div', {'class': 'product--ordernumber'}).text.replace("Artnr.:", "").strip()
            mpn = Itemnumber

            try:
                sup = li.find('span', {'class': 'pricelayer fill'}).find('sup').text
                price = li.find('span', {'class': 'pricelayer fill'}).text.replace(sup, "", 1).replace(" €", "").replace("\n", "").strip()
                promo = price= price + "." + sup
            except Exception as es:
                promo = price = "check for price"

            temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                    'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                    'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                    'Category URL': CategoryURL, 'Crawling Date': today}
            DataOut.append(temp)
            sqldata.append(temp)
    except Exception as e:
            temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': '', 'MPN': '',
                        'Manufacturer': '', 'Name': '', 'Product URL': '', 'List Price': '',
                        'Promo Price': '', 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                        'Category URL': CategoryURL, 'Crawling Date': today}
            sqldata.append(temp)
            DataOut.append(temp)

    return DataOut

def Push_TO_Sql(df):
    ''''add here'''
    connStr = pyodbc.connect('DRIVER={SQL Server};SERVER=ecxus249;DATABASE=SHOPAMD;UID=SHOPAMD;PWD=SHOP@md2010')
    if connStr:
        print('Connected To SQL Server')
        cursor = connStr.cursor()
        for index, row in df.iterrows():
            try:
                cursor.execute("INSERT INTO dbo.Master_Collation(LOB,Country,Site,Itemnumber,MPN,Manufacturer,ProductName,ProductURL,Listprice,Promoprice,CurrencyType,RetailerID,Date) values(?,?,?,?,?,?,?,?,?,?,?,?,?)", row['LOB'],row['Country'],row['Site'],row['ItemNumber'],row['MPN'],row['Manufacturer'],row['Name'],row['Product URL'],row['List Price'],row['Promo Price'],row['Currency'],row['Retailer ID'],row['Crawling Date'])
            except Exception as e:
                print(e)
        connStr.commit()
        print('Sucessfully Stored Records To DB')
        cursor.close()
        connStr.close()


print("start")
LOB = ''
site = ''
country = ''
CurrencyType = ''
RetailerId = ''
CategoryURL = ''
excel_To_List()
col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price',
           'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']

for url in input:
    if "bora-computer.de" in url:
        print(url)
        indx = url.index('^')
        if indx != 0:
            LOB = url[:indx]
            url = url[indx+1:]
            CategoryURL = url
            url = url.replace("http:", "https:")
            splitURL = url.split('/')
            hostpart = splitURL[2].split('.')
            #country = hostpart[2].upper()
            site = splitURL[2].replace('www.', '').replace('.', '-').replace('-computer', '')
            RetailerId = '96031'
            country = "Germany"
            CurrencyType = 'EURO'
        response = fetch_data(url)
        Pages = int(get_PageNo(response))
        for i in range(1, Pages+1):
            sp_cat=url.lower().split('?p=')
            caturl=sp_cat[0]+'?p='+str(i)
            CatRes = fetch_data(caturl)
            Extract_data(CatRes, url)
            Result_SQL = pd.DataFrame(sqldata, columns=col)
            Push_TO_Sql(Result_SQL)
            sqldata.clear()
        Result_Out_Excel(DataOut)
        Result_SQL = Result_Out_Excel(DataOut)
        print('Çompleted')
