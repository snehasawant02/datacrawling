import datetime
import requests
import pandas as pd
from bs4 import BeautifulSoup
from openpyxl import load_workbook
from pandas import ExcelWriter
import pyodbc
import os

url='https://www.cyberport.de/'
sess=requests.Session()
res=sess.get(url)
rest=res.text
bait=res.cookies.get_dict()
soup=BeautifulSoup(rest,'lxml')
print ("Page Loaded")
