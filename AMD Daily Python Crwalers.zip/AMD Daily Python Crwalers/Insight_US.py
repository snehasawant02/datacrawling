'''
Last Modified by :Hemant
Last Modified date : 29/8/2018
'''
import datetime
import time
import requests
import re
from bs4 import BeautifulSoup
from openpyxl import load_workbook
import xlsxwriter
import os
from urllib.parse import unquote
from selenium.webdriver.chrome.options import Options
from selenium import webdriver
import zipfile
import pyodbc
import pandas as pd
from pandas import ExcelWriter

chromedriver = "E:\Python\AMD Daily Python Crwalers\chromedriver.exe"
os.environ["webdriver.chrome.driver"] = chromedriver
options = Options()
# options.add_argument('--headless')
options.add_argument('--disable-gpu')

driver = webdriver.Chrome(chromedriver, chrome_options=options)
#driver.set_window_size(0, 0)

sess = requests.session()
sess.headers = ({
    'Connection': 'keep-alive',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36',
    'Upgrade-Insecure-Requests': '1',
    'Accept': 'application/json; charset=utf-8',
    'Accept-Encoding': 'gzip, deflate, br'})

input = []
DataOut = []
sqldata=[]

def excel_To_List():
    # wb = load_workbook(filename='E:\Python\AMD Script\Hemant Test\InputHK.xlsx')
    wb = load_workbook(filename='E:\Python\AMD Script\Input.xlsx')
    ws = wb['Sheet1']
    row = ws.max_row
    col=ws.max_column
    for row in ws.iter_rows(min_row=1, min_col=0, max_row=row, max_col=1):
        for cell in row:
            if cell.value is not None and "uk.insight" not in cell.value and "insight.com" in cell.value:
                input.append(cell.value)
    wb.close()

def result_out_excel(DataOut):
    col = ['LOB', 'Country', 'Site', 'Itemnumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price',
           'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']
    dt = str(datetime.date.today())
    filename = site + "_" + dt
    path = "E:\Python\AMD Script\Output\\" + filename + ".xlsx"
    df = pd.DataFrame(DataOut, columns=col)
    writer = pd.ExcelWriter(path, engine='xlsxwriter', options={'strings_to_urls': False})
    df.to_excel(writer, 'Sheet1', index=False)
    writer.save()


def fetch_data(url):
    try:
        driver.get(url)
        time.sleep(25)
        html = driver.page_source
    except Exception as e:
        print('Page not hit: (Pagging Error)')
    return html


def get_PageNo(res):
    soup = BeautifulSoup(res, 'lxml')
    global check
    global content
    try:
        if content:
            check=True
        else:
            check=False
    except Exception as e:
        check=False


def Extract_data(res, url):
    global content
    Itemnumber = ''
    mpn = ''
    Manufacturer = ''
    Name = ''
    ProdURL = ''
    price = ''
    promo = ''
    today = str(datetime.datetime.now()).split(".")[0]
    soup = BeautifulSoup(res, 'lxml')
    try:
        if soup.find('div', {'id': 'js-search-product-items'}) is not None:
            container = soup.find('div', {'id': 'js-search-product-items'})
            block = container.find_all('div', {'class': 'result-item-wrapper result-item-list'})
            if len(block)<1:
                content=False

            for li in block:
                try:
                    Name = li.find('div', {'itemprop': 'name'}).text
                    namepart = Name.split(" ")
                    Manufacturer = namepart[0]
                    ProdURL = li.find('div', {'itemprop': 'url'}).text
                    try:
                        promo = price = li.find('p', {'class': 'prod-price'}).text.replace('\n', '').replace('\t','').replace('USD', '').replace('$', '').replace(',', '').strip()
                        promo = price = li.find('p', {'class': 'prod-price'}).text.replace('\n', '').replace('\t','').replace('USD', '').replace('$', '').replace(',', '').strip()
                    except Exception as es:
                        price = promo = "Check for price"
                    mpn = Itemnumber = li.find("div", {'class': 'compare-list-container show-for-medium-up'}).find("div",{'class':'columns medium-5'}).find('a')['data-material-id']

                    temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                            'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                            'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                            'Category URL': url, 'Crawling Date': today}
                    DataOut.append(temp)
                    sqldata.append(temp)
                except:
                    print("error in product")
    except Exception as e:
        temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                'Category URL': url, 'Crawling Date': today}
        DataOut.append(temp)
        sqldata.append(temp)

    return DataOut


def Push_TO_Sql(df):
    ''''add here'''
    connStr = pyodbc.connect('DRIVER={SQL Server};SERVER=ecxus249;DATABASE=SHOPAMD;UID=SHOPAMD;PWD=SHOP@md2010')
    if connStr:
        # print('Connected To SQL Server')
        cursor = connStr.cursor()
        for index, row in df.iterrows():
            try:
                cursor.execute("INSERT INTO dbo.Master_Collation(LOB,Country,Site,Itemnumber,MPN,Manufacturer,ProductName,ProductURL,Listprice,Promoprice,CurrencyType,RetailerID, CategoryURL, Date) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", row['LOB'],row['Country'],row['Site'],row['ItemNumber'],row['MPN'],row['Manufacturer'],row['Name'],row['Product URL'],row['List Price'],row['Promo Price'],row['Currency'],row['Retailer ID'], row['Category URL'],row['Crawling Date'])
            except Exception as e:
                print("String SQL", e)
        connStr.commit()
        print('Sucessfully Stored Records To DB')
        cursor.close()
        connStr.close()


def result_out_excel(DataOut):
    col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price', 'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']
    dt = str(datetime.date.today())
    filename = site + "_" + dt
    path = "E:\Python\AMD Script\Output\\" +filename+".xlsx"
    df = pd.DataFrame(DataOut, columns=col)
    writer = pd.ExcelWriter(path, engine='xlsxwriter', options={'strings_to_urls': False})
    df.to_excel(writer, 'Sheet1', index=False)
    writer.save()


print("start")
LOB = ''
site = ''
country = ''
CurrencyType = ''
RetailerId = ''
CategoryURL = ''
col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price',
           'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']
excel_To_List()
for url in input:
    if "uk.insight" not in url and "insight.com" in url:
        # print(url)
        url = url.replace("http:", "https:")
        CategoryURL = url
        indx = url.index('^')
        if indx != 0:
            LOB = url[:indx]
            url = url[indx+1:]
            splitURL = url.split('/')
            print('Running URL  : ' + url)
            country = 'us'
            if country == "us":
                country = 'US'
                RetailerId = "95996"
                CurrencyType = "USD"
            site = splitURL[2].replace('www.', '').replace('com', '').replace('.', '-us')
        response = fetch_data(url)
        check=True
        content=True
        i=0
        while check:
            i=i+1
            urlText = "currentPage%22%3A1"
            PageText = "currentPage%22%3A"+str(i)
            caturl = url.replace(urlText, PageText)
            print(caturl)
            CatRes = fetch_data(caturl)
            Extract_data(CatRes, url)
            Result_SQL = pd.DataFrame(sqldata, columns=col)
            Push_TO_Sql(Result_SQL)
            sqldata.clear()
            result_out_excel(DataOut)
            get_PageNo(CatRes)
driver.quit()