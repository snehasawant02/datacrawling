import time
import requests
import datetime
from openpyxl import load_workbook
import pyodbc
import pandas as pd
import os
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from pandas import ExcelWriter
import json

chromedriver = "E:\Python\AMD Daily Python Crwalers\chromedriver.exe"
os.environ["webdriver.chrome.driver"] = chromedriver

options = Options()
# options.add_argument('--headless')
options.add_argument('--disable-gpu')  # Last I checked this was necessary.

driver = webdriver.Chrome(chromedriver, chrome_options=options)
driver.set_page_load_timeout(120)


#proxy = {'https': 'https://eclerxusa:WonderS1979@london.wonderproxy.com:80'}
headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36',
           'content-type': 'text/html;charset=utf-8',
           'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
           'Host': 'www.misco.fr'}

input = []
DataOut = []
sqldata=[]


def excel_To_List():
    wb = load_workbook(filename='E:\Python\AMD Script\Input.xlsx')
    ws = wb['Sheet1']
    row = ws.max_row
    col=ws.max_column
    for row in ws.iter_rows(min_row=1, min_col=0, max_row=row, max_col=1):
        for cell in row:
            input.append(cell.value)
    wb.close()

def result_out_excel(DataOut):
    col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price', 'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']
    dt = str(datetime.date.today())
    filename = "staplesCA_" + dt
    path = "E:\Python\AMD Script\Output\\" + filename + ".xlsx"
    df = pd.DataFrame(DataOut, columns=col)
    writer = pd.ExcelWriter(path, engine='xlsxwriter', options={'strings_to_urls': False})
    df.to_excel(writer,index=False)
    writer.close()




def fetch_data(url):
    res = ''
    # proxy = {'https': 'https://eclerxamd:Rid8B67I2Q@shp-prx109-br-v00001.tp-ns.com:80'}
    proxy= {'https': 'https://eclerxamd:Rid8B67I2Q@shp-prx109-us-v00003.tp-ns.com:80'}
    try:
        driver.get(url)
        # ispage=True
        # while ispage:
        #     try:
        #         pgt=driver.find_element_by_id('load-more-results')
        #         pgt.click()
        #         get_class=pgt.get_attribute('class')
        #         if 'disabled' in get_class:
        #             ispage=False
        #         time.sleep(2)
        #     except:
        #         ispage=False
        # res = requests.get(url, proxies=proxy).text
    except Exception as e:
        print("type error: " + str(e))
    # return res
    return driver.page_source


def get_PageNo(res):
    try:
        soup = BeautifulSoup(res, "lxml")
        if soup.find("div", {'class': 'ais-body ais-stats--body'}) is not None:
            PageDiv = soup.find("span", {'class': 'ais-stats--nb-results'}).text.replace("Results", "").replace("\n", "").replace(',','').strip()
            page1 = int(PageDiv) / 32
            if int(page1) >= 1:
                Pages = int(page1)
            else:
                Pages = 1
        else:
            Pages = 1

    except Exception as e:
        Pages = 1
    return Pages


def Extract_data(res, url):
    Itemnumber = ''
    mpn = ''
    Manufacturer = ''
    Name = ''
    ProdURL = ''
    price = ''
    promo = ''
    today = str(datetime.datetime.now()).split(".")[0]
    soup = BeautifulSoup(res, 'lxml')
    try:
        if soup.find("div", {"class": 'ais-hits'}) is not None:
            #container = soup.find("div", {"class": 'productView__productTileRows'})
            block = soup.find_all("div", {"class": "ais-hits--item"})
            for li in block:
                try:
                    Name = li.find('a', {'class': 'product-thumbnail__title d-block product-link'}).text.strip()
                    # print(Name)
                    namepart = Name.split(" ")
                    Manufacturer = namepart[0]
                    #Manufacturer = Name.split()[0]
                    # print(Manufacturer)
                    ProdURL = 'https://www.staples.ca' + li.find('a', {'class': 'product-thumbnail__title d-block product-link'})['href']
                    # print(ProdURL)
                    Itemnumber = li.find('a', {'class': 'product-thumbnail__title d-block product-link'})['data-handle'].split('-')
                    Itemnumber = Itemnumber[0]
                    mpn = Itemnumber
                    # print(mpn)
                    if li.find("div", {"class": "product-thumbnail__footer"}) is not None:
                        price = li.find("span", {"class": "money"}).text.replace('\n','').replace('$','').replace(',','')
                    else:
                        price = 'Check For Price'
                    # print(price)
                    promo = price
                    temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                            'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                            'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                            'Category URL': url, 'Crawling Date': today}
                    DataOut.append(temp)
                    sqldata.append(temp)
                except Exception as e:
                    print("Error in product")
                    print(Name)

    except Exception as e:
        temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                'Category URL': url, 'Crawling Date': today}
        print("Error in page")
        DataOut.append(temp)
        sqldata.append(temp)
    #return DataOut



def Push_TO_Sql(df):
    ''''add here'''
    connStr = pyodbc.connect('DRIVER={SQL Server};SERVER=ecxus249;DATABASE=SHOPAMD;UID=SHOPAMD;PWD=SHOP@md2010')
    if connStr:
        # print('Connected To SQL Server')
        cursor = connStr.cursor()
        for index, row in df.iterrows():
            try:
                cursor.execute(
                    "INSERT INTO dbo.Master_Collation(LOB,Country,Site, CategoryURL,Itemnumber,MPN,Manufacturer,ProductName,ProductURL,Listprice,Promoprice,CurrencyType,RetailerID,Date) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    row['LOB'], row['Country'], row['Site'], row['Category URL'], row['ItemNumber'], row['MPN'],
                    row['Manufacturer'], row['Name'], row['Product URL'], row['List Price'], row['Promo Price'],
                    row['Currency'], row['Retailer ID'], row['Crawling Date'])
            except Exception as e:
                print(e)
        connStr.commit()
        print('Sucessfully Stored Records To DB')
        cursor.close()
        connStr.close()


print("start")
LOB = ''
site = ''
country = ''
CurrencyType = ''
RetailerId = ''
CategoryURL = ''
excel_To_List()

col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price', 'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']
for url in input:
    if 'staples.ca' in url:
        print(url)
        indx = url.index('^')
        if indx != 0:
            CategoryURL = url
            LOB = url[:indx]
            url = url[indx+1:]
            splitURL = url.split('/')
            hostpart = splitURL[2].split('.')
            country = 'Canada'
            site = splitURL[2].replace('www.', '').replace('.', '-')
            RetailerId = '95958'
            country = "Canada"
            CurrencyType = 'CND'
        response = fetch_data(url)
        # Extract_data(response, url)
        # Result_SQL = pd.DataFrame(sqldata, columns=col)
        # Push_TO_Sql(Result_SQL)
        # sqldata.clear()
        # result_out_excel(DataOut)
        Pages = int(get_PageNo(response))
        print(Pages)
        for i in range(0, Pages+1):
            if '&p=0' in url:
                temp_url = url.replace('&p=0', '&p=%s'%i)
                caturl = temp_url
            else:
                caturl = url
            print(caturl)
            response = fetch_data(caturl)
            Extract_data(response, url)
            #Extract_data(driver.page_source, url)

        Result_SQL = pd.DataFrame(sqldata, columns=col)
        Push_TO_Sql(Result_SQL)
        sqldata.clear()
        result_out_excel(DataOut)

driver.close()
