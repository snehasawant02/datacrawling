import requests
import datetime
from openpyxl import load_workbook
import pyodbc
import pandas as pd
import os
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from pandas import ExcelWriter
from lxml import html


chromedriver = "E:\Python\AMD Daily Python Crwalers\chromedriver.exe"
os.environ["webdriver.chrome.driver"] = chromedriver

options = Options()
# options.add_argument('--headless')
options.add_argument('--disable-gpu')  # Last I checked this was necessary.

driver = webdriver.Chrome(chromedriver, chrome_options=options)
driver.set_page_load_timeout(120)

sess = requests.session()
#proxy = {'https': 'https://eclerxusa:WonderS1979@london.wonderproxy.com:80'}
sess.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36',
           'content-type': 'text/html;charset=utf-8',
           'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
           'Host': 'www.misco.fr'}

input = []
DataOut = []
sqldata=[]


def excel_To_List():
    wb= load_workbook(filename='E:\Python\AMD Script\Input.xlsx')
    ws = wb['Sheet1']
    row = ws.max_row
    col=ws.max_column
    for row in ws.iter_rows(min_row=2, min_col=0, max_row=row, max_col=1):
        for cell in row:
            input.append(cell.value)
    wb.close()

def result_out_excel(DataOut):
    col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price', 'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']
    dt = str(datetime.date.today())
    filename = "misco-fr" + dt
    path = "E:\Python\AMD Script\Output\\" + filename + ".xlsx"
    df = pd.DataFrame(DataOut, columns=col)
    writer = ExcelWriter(path)
    df.to_excel(writer, 'Sheet1', index=False)
    writer.save()


def fetch_data(url):
    res = ''
    proxy = {'https': 'https://eclerxamd:Rid8B67I2Q@shp-prx109-fr-v00004.tp-ns.com:80'}
# proxy= {'https': 'https://162.248.6.107:80'}
    try:
        # driver.get(url)
        res = sess.get(url, proxies=proxy).text
    except Exception as e:
        print("type error: " + str(e))
    return res


def get_PageNo(res):
    try:
        # res1=html.fromstring(res.content)
        # Pages=res1.xpath('//*[@id="TotalPage"]/text()')
        soup = BeautifulSoup(res, "lxml")
        Pages = soup.find("x", {'id': 'TotalPage'}).text
    except Exception as e:
        Pages = 1
    return Pages

def Extract_data(res, url):
    Itemnumber = ''
    mpn = ''
    Manufacturer = ''
    Name = ''
    ProdURL = ''
    price = ''
    promo = ''
    today = str(datetime.datetime.now()).split(".")[0]
    soup = BeautifulSoup(res, 'lxml')
    try:
        if soup.find("div", {"id": 'catProductListContent'}) is not None:
            container = soup.find("div", {"id": 'catProductListContent'})
            block = container.find_all("div", {"class": "productCell"})
            for li in block:
                try:
                    Name = li.find('h2', {'class': 'ttShortTitle'}).text
                    Manufacturer = Name.split()[0]
                    ProdURL = li.find('h2', {'class': 'ttShortTitle'}).find('a')['href']
                    Itemnumber_div = li.find('p', {'class': 'reference'}).find_all('span')
                    mpn = Manufacturer + "/" + Itemnumber_div[1].text
                    Itemnumber = Itemnumber_div[0].text
                    price_desp = li.find("span", {"class": "low-price"}).find('sup').text
                    promo = price = li.find("span", {"class": "low-price"}).text.replace("€", "").replace(price_desp, "").replace("HT", "").strip() + "." + price_desp
                    temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                            'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                            'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                            'Category URL': url, 'Crawling Date': today}
                    DataOut.append(temp)
                    sqldata.append(temp)
                except:
                    print("Error in product")
        elif soup.find("div", {"id": 'cmcwebusercataloguepromotion'}) is not None:
            container = soup.find("div", {"id": 'cmcwebusercataloguepromotion'})
            block = container.find_all("div", {"class": "productPushMag hovereffect"})
            for li in block:
                try:
                    Name = li.find('h3').text
                    Manufacturer = Name.replace("CARTE GRAPH. ", "").split()[0]
                    ProdURL = "https://www.misco.fr" + li.find('a', {'class': 'moreDetail'})['href']
                    mpn = Itemnumber =ProdURL.split('/')[-1].replace(".htm", "")
                    price_desp = li.find("div", {"class": "priceHT"}).find('sup').text
                    promo = price = li.find("div", {"class": "priceHT"}).text.replace("€", "").replace(price_desp,"").replace("HT", "").strip() + "." + price_desp
                    temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                            'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                            'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                            'Category URL': url, 'Crawling Date': today}
                    DataOut.append(temp)
                    sqldata.append(temp)
                except:
                    print("Error in product")
    except Exception as e:
        temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                'Category URL': url, 'Crawling Date': today}
        print("Error in page")
        DataOut.append(temp)
        sqldata.append(temp)



def Push_TO_Sql(df):
    if not df.empty:
        ''''add here'''
        connStr = pyodbc.connect('DRIVER={SQL Server};SERVER=ecxus249;DATABASE=SHOPAMD;UID=SHOPAMD;PWD=SHOP@md2010')
        if connStr:
            # print('Connected To SQL Server')
            cursor = connStr.cursor()
            for index, row in df.iterrows():
                try:
                    cursor.execute("INSERT INTO dbo.Master_Collation(LOB,Country,Site, CategoryURL,Itemnumber,MPN,Manufacturer,ProductName,ProductURL,Listprice,Promoprice,CurrencyType,RetailerID,Date) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", row['LOB'],row['Country'],row['Site'], row['Category URL'],row['ItemNumber'],row['MPN'],row['Manufacturer'],row['Name'],row['Product URL'],row['List Price'],row['Promo Price'],row['Currency'],row['Retailer ID'],row['Crawling Date'])
                except Exception as e:
                    print(e)
            connStr.commit()
            print('Sucessfully Stored Records To DB')
            cursor.close()
            connStr.close()
    else:
        print('DataFrame is Empty')


print("start")
LOB = ''
site = ''
country = ''
CurrencyType = ''
RetailerId = ''
CategoryURL = ''
excel_To_List()
col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price', 'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date']
for url in input:
    if 'misco.fr' in url:
        print(url)
        indx = url.index('^')
        if indx != 0:
            CategoryURL = url
            LOB = url[:indx]
            url = url[indx+1:]
            splitURL = url.split('/')
            hostpart = splitURL[2].split('.')
            country = hostpart[2].upper()
            site = splitURL[2].replace('www.', '').replace('.', '_')
            if country == 'FR':
                RetailerId = '-'
                country = "France"
                CurrencyType = 'EURO'
        response = fetch_data(url)
        Pages = int(get_PageNo(response))
        print(Pages)
        for i in range(1, Pages+1):
            pagetext = '&p=' + str(i)
            caturl = url.replace('&p=1', pagetext)
            CatRes = fetch_data(caturl)
            Extract_data(CatRes, url)
            Result_SQL = pd.DataFrame(sqldata, columns=col)
            Push_TO_Sql(Result_SQL)
            sqldata.clear()
        result_out_excel(DataOut)



