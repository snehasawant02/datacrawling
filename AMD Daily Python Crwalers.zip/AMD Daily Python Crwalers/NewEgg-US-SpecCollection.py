import requests
import datetime
from openpyxl import load_workbook
import pyodbc
import pandas as pd
import os
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import time
from pandas import ExcelWriter
import json

chromedriver = "chromedriver.exe"
os.environ["webdriver.chrome.driver"] = chromedriver

options = Options()
# options.add_argument('--headless')
options.add_argument('--disable-gpu')  # Last I checked this was necessary.

driver = webdriver.Chrome(chromedriver, chrome_options=options)
driver.set_page_load_timeout(120)


#proxy = {'https': 'https://eclerxusa:WonderS1979@london.wonderproxy.com:80'}
headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36',
           'content-type': 'text/html;charset=utf-8',
           'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
           'Host': 'uae.souq.com'}

input = []
DataOut = []
sqldata=[]


def excel_To_List():
    wb= load_workbook(filename='E:\Python\AMD Script\EGGUS.xlsx')
    ws = wb['Sheet1']
    row = ws.max_row
    col=ws.max_column
    for row in ws.iter_rows(min_row=1, min_col=0, max_row=row, max_col=1):
        for cell in row:
            input.append(cell.value)
    wb.close()

def result_out_excel(DataOut):
    col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price', 'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date','Itemnumber']
    dt = str(datetime.date.today())
    filename = "NEUS" + dt
    path = "E:\Python\AMD Script\\" + filename + ".xlsx"
    df = pd.DataFrame(DataOut)
    writer = pd.ExcelWriter(path, engine='xlsxwriter', options={'strings_to_urls': False})
    df.to_excel(writer,index=False)
    writer.close()




def fetch_data(url):
    res = ''
    # proxy = {'https': 'https://eclerxamd:Rid8B67I2Q@shp-prx109-br-v00001.tp-ns.com:80'}
    proxy= {'https': 'https://107.155.108.158:80'}
    try:
        driver.get(url)
        # res = requests.get(url, proxies=proxy).text
    except Exception as e:
        print("type error: " + str(e))
    # return res
    # time.sleep(2)
    return driver.page_source


def get_PageNo(res):
    try:
        soup = BeautifulSoup(res, "lxml")
        Pages = 1
    except Exception as e:
        Pages = 1
    return Pages

def Extract_data(res, url):
    Itemnumber = ''
    mpn = ''
    Manufacturer = ''
    Name = ''
    ProdURL = ''
    price = ''
    promo = ''
    processor = ''
    model_number = ''
    memory = ''
    drive = ''
    today = str(datetime.datetime.now()).split(".")[0]
    soup = BeautifulSoup(res, 'lxml')
    try:
        container = soup.find('div', {'id': 'container'})
        # time.sleep(2)

        try:
            if container.find('span', {'itemprop': 'name'}) is not None:
                Name = container.find('span', {'itemprop': 'name'}).text.replace('\n','').strip()
            else:
                Name = 'Product name not available'
            # print(Name)
            Itemnumber = driver.find_element_by_xpath("//span[@class='mainSlide']").find_element_by_tag_name('img').get_attribute('src')
            if container.find('li', {'class': 'price-current'}) is not None:
                promo = price = container.find('li', {'class': 'price-current'}).text
            # if container.find('span', {'id': 'priceblock_ourprice'}) is not None:
            #     promo = container.find('span', {'id': 'priceblock_ourprice'}).text
            # else:
            #     promo = 'Price not available'
            if price == '':
                price = promo =  'Check for Price'

            # print(price,promo)

            specs = container.find('div', {'id': 'detailSpecContent'})

            temp = {'LOB': LOB, 'Country': country, 'Site': site, 'Name': Name, 'Product URL': url, 'List Price': price,
                    'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                    'Category URL': url, 'Crawling Date': today,'Itemnumber': Itemnumber}

            # p_specs = container.find('table', {'id': 'productDetails_techSpec_section_1'})
            # p_table = p_specs.find_all('tr')
            table_tr = specs.find_all('dl')
            i=0
            for tr in table_tr:
                head=tr.find('dt').text
                value=tr.find('dd').text
                temp[head]=value
                #
                # if 'Brand' in tr.text :
                #     Brand = tr.find('dd').text
                # if 'Model' in tr.text and processor == '':
                #     model = tr.find('dd').text
                # if 'Part Number' in tr.text:
                #     partnumber = tr.find('dd').text
                # if 'Color' in tr.text:
                #     color = tr.find('dd').text
                # if 'Operating System' in tr.text:
                #     operatingsystem = tr.find('dd').text
                # if 'CPU' in tr.text:
                #     cpu = tr.find('dd').text
                # if 'Screen' in tr.text:
                #     Screen = tr.find('dd').text
                # if 'Memory' in tr.text:
                #     memory = tr.find('dd').text
                # if 'Storage' in tr.text:
                #     storage = tr.find('dd').text
                # if 'Optical Drive' in tr.text:
                #     opticaldrive = tr.find('dd').text
                # if 'Graphics Card' in tr.text:
                #     graphicscard = tr.find('dd').text
                # if 'Video Memory' in tr.text:
                #     videomemory = tr.find('dd').text
                # if 'Dimensions (W x D x H)' in tr.text:
                #     dimensions = tr.find('dd').text
                # if 'Weight' in tr.text:
                #     weight = tr.find('dd').text
                # if 'CPU Type' in tr.text:
                #     cputype = tr.find('dd').text
                # if 'CPU Speed' in tr.text:
                #     cpuspeed = tr.find('dd').text
                # if 'Number of Cores' in tr.text:
                #     numberofcores = tr.find('dd').text
                # if 'Screen Size' in tr.text:
                #     screensize = tr.find('dd').text
                # if 'Touchscreen' in tr.text:
                #     touchscreen = tr.find('dd').text
                # if 'Wide Screen Support' in tr.text:
                #     widescreensupport = tr.find('dd').text
                # if 'Resolution' in tr.text:
                #     resolution = tr.find('dd').text
                # if 'LCD Features' in tr.text:
                #     lcdfeatures = tr.find('dd').text
                # if 'GPU/VPU' in tr.text:
                #     gpuvpu = tr.find('dd').text
                # if 'Video Memory' in tr.text:
                #     videomemory = tr.find('dd').text
                # if 'Graphic Type' in tr.text:
                #     graphictype = tr.find('dd').text
                # if 'SSD' in tr.text:
                #     SSD = tr.find('dd').text
                # if 'HDD' in tr.text:
                #     hdd = tr.find('dd').text
                # if 'Memory' in tr.text:
                #     memory = tr.find('dd').text
                # if 'Memory Speed' in tr.text:
                #     memoryspeed = tr.find('dd').text
                # if 'Video Memory' in tr.text:
                #     videomemory = tr.find('dd').text
                # if 'Video Memory' in tr.text:
                #     videomemory = tr.find('dd').text
                # if 'Video Memory' in tr.text:
                #     videomemory = tr.find('dd').text
                # if 'Video Memory' in tr.text:
                #     videomemory = tr.find('dd').text
                # if 'Video Memory' in tr.text:
                #     videomemory = tr.find('dd').text
                # if 'Video Memory' in tr.text:
                #     videomemory = tr.find('dd').text
                # if 'Video Memory' in tr.text:
                #     videomemory = tr.find('dd').text
                # if i == 0 :
                #     if 'RAM' in tr.text.strip():
                #         ram = tr.find('td').text.strip()
                #         i = i+1

            # mpn = Brand
            # Itemnumber = "NA"
            # ProdURL = "NA"
            # Manufacturer = "NA"
            # ProdURL = "NA"

            # print(Name, price, promo, mpn, Itemnumber, ProdURL, Manufacturer)

            # print(Manufacturer)
            # mpn = Itemnumber = 'default'
            # print(mpn)


            DataOut.append(temp)
            # Sqldataout.append(temp)

        except Exception as e:
            print(Name, price, promo, mpn, Itemnumber, ProdURL, Manufacturer)
            print('error in Product')

    except Exception as e:
        temp = {'LOB': LOB, 'Country': country, 'Site': site, 'ItemNumber': Itemnumber, 'MPN': mpn,
                'Manufacturer': Manufacturer, 'Name': Name, 'Product URL': ProdURL, 'List Price': price,
                'Promo Price': promo, 'Currency': CurrencyType, 'Retailer ID': RetailerId,
                'Category URL': url, 'Crawling Date': today}
        DataOut.append(temp)
        # Sqldataout.append(temp)
    return DataOut


def Push_TO_Sql(df):
    ''''add here'''
    connStr = pyodbc.connect('DRIVER={SQL Server};SERVER=ecxus249;DATABASE=SHOPAMD;UID=SHOPAMD;PWD=SHOP@md2010')
    if connStr:
        # print('Connected To SQL Server')
        cursor = connStr.cursor()
        for index, row in df.iterrows():
            try:
                cursor.execute("INSERT INTO dbo.Master_Collation(LOB,Country,Site, CategoryURL,Itemnumber,MPN,Manufacturer,ProductName,ProductURL,Listprice,Promoprice,CurrencyType,RetailerID,Date) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", row['LOB'],row['Country'],row['Site'], row['Category URL'],row['ItemNumber'],row['MPN'],row['Manufacturer'],row['Name'],row['Product URL'],row['List Price'],row['Promo Price'],row['Currency'],row['Retailer ID'],row['Crawling Date'])
            except Exception as e:
                print(e)
        connStr.commit()
        print('Sucessfully Stored Records To DB')
        cursor.close()
        connStr.close()


print("start")
LOB = ''
site = ''
country = ''
CurrencyType = ''
RetailerId = ''
CategoryURL = ''
excel_To_List()
col = ['LOB', 'Country', 'Site', 'ItemNumber', 'MPN', 'Manufacturer', 'Name', 'Product URL', 'List Price', 'Promo Price', 'Currency', 'Retailer ID', 'Category URL', 'Crawling Date','Itemnumber']
for url in input:
    #if 'newegg.com' in url:
    if 'newegg.com' in url:
        # print(url)
        indx = url.index('^')
        if indx != 0:
            CategoryURL = url
            LOB = url[:indx]
            url = url[indx+1:]
            splitURL = url.split('/')
            hostpart = splitURL[2].split('.')
            country = 'US'
            site = 'NewEgg-US'
            RetailerId = '5994'
            country = "US"
            CurrencyType = 'USD'
        response = fetch_data(url)
        Pages = int(get_PageNo(response))
        print(Pages)
        for i in range(1, Pages+1):
            # temp_url = url.replace('page=1', 'page=')
            caturl = url
            print(caturl)
            response = fetch_data(caturl)
            Extract_data(response, url)
            # if driver.find_element_by_id('pagnNextLink') is not None:
            #     # CatRes = driver.find_element_by_id('pagnNextLink')
            #     # CatRes.click()
            #     driver.find_element_by_link_text("Página siguiente").click()
            # else:
            #    print('No Button to Click')
            #    break
            # Result_SQL = pd.DataFrame(sqldata, columns=col)
            # Push_TO_Sql(Result_SQL)
            # sqldata.clear()
            result_out_excel(DataOut)
driver.close()
