import pandas as pd
import os


df = pd.read_excel("C:\\Users\\AMD\\Desktop\\sanjana\\python\\python data.xlsx")
df["Item number"] = df["Item number"].str.replace("\\t","")
print(df.head())
df.to_excel("exact_data.xlsx",index = False)
print(os.getcwd())