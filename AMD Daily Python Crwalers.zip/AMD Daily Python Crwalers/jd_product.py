'''
!/usr/bin/env python
description     : To crawl Product information uisng python(Selenium,BS4)
author          : Sayar Mendis
date            : 6-8-2018
version         : 0.1
python_version  : 3.6.4
==============================================================================
'''
import pyodbc
import time
from selenium.webdriver.common.action_chains import ActionChains
from multiprocessing.dummy import Pool
import os
from openpyxl import load_workbook
import datetime
import pandas as pd
from selenium.webdriver.chrome.options import Options
from selenium import webdriver
from bs4 import BeautifulSoup as bs
import zipfile

class JD_product():

    def __init__(self):
        self.inputs=[]

        self.RetailerId=''
        self.CurrencyType=''
        self.Count=1
        self.Output=[]
        self.Product_URL=[]
        self.sqldata=[]


    def excel_To_List(self):
        dirname = os.path.dirname(__file__)
        filename = 'E:\Python\AMD Script\Input123.xlsx'
        wb = load_workbook(filename=filename)
        ws = wb['Sheet1']
        row = ws.max_row
        col = ws.max_column
        for row in ws.iter_rows(min_row=0, min_col=0, max_row=row, max_col=1):
            for cell in row:
                url=cell.value
                indx = url.index('^')
                if indx != 0:
                    LOB = url[:indx]
                    url = url[indx + 1:]
                    CategoryURL = url+":>>"+LOB
                    url = url.replace("http:", "https:")
                    splitURL = url.split('/')
                    hostpart = splitURL[2].split('.')
                    country = hostpart[2].upper()
                    if country == "CN":
                        self.RetailerId = "29533"
                        self.CurrencyType = "EURO"
                self.inputs.append(CategoryURL)
        wb.close()
        return self.inputs

    def Result_Out_Excel(self,DataOut):
        now = datetime.datetime.now()
        datstr = str(now.day) + '_' + str(now.month) + '_' + str(now.year)
        dirname = os.path.dirname(__file__)
        path = 'E:\Python\AMD Daily Python Crwalers\output_' + str(datstr) + '.xlsx'
        df = pd.DataFrame(DataOut)
        df.to_excel(path)


    def Get_Product_URL(self,urlg):
        try:
            # chromedriver = "chromedriver.exe"
            # os.environ["webdriver.chrome.driver"] = chromedriver
            # if(self.Count%2==0):
            #     PROXY_HOST = '216.227.130.3'  # rotating proxy
            # else:
            #     PROXY_HOST = '216.227.130.3'
            # PROXY_PORT = 80
            # PROXY_USER = ''
            # PROXY_PASS = ''
            #
            # manifest_json = """
            #            {
            #                "version": "1.0.0",
            #                "manifest_version": 2,
            #                "name": "Chrome Proxy",
            #                "permissions": [
            #                    "proxy",
            #                    "tabs",
            #                    "unlimitedStorage",
            #                    "storage",
            #                    "<all_urls>",
            #                    "webRequest",
            #                    "webRequestBlocking"
            #                ],
            #                "background": {
            #                    "scripts": ["background.js"]
            #                },
            #                "minimum_chrome_version":"22.0.0"
            #            }"""
            # background_js = """
            # var config = {
            #         mode: "fixed_servers",
            #         rules: {
            #           singleProxy: {
            #             scheme: "http",
            #             host: "%s",
            #             port: parseInt(%s)
            #           },
            #           bypassList: ["localhost"]
            #         }
            #       };
            #
            # chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
            #
            # function callbackFn(details) {
            #     return {
            #         authCredentials: {
            #             username: "%s",
            #             password: "%s"
            #         }
            #     };
            # }
            #
            # chrome.webRequest.onAuthRequired.addListener(
            #             callbackFn,
            #             {urls: ["<all_urls>"]},
            #             ['blocking']
            # );
            # """ % (PROXY_HOST, PROXY_PORT, PROXY_USER, PROXY_PASS)
            # options = Options()
            # pluginfile = 'proxy_auth_plugin.zip'
            # with zipfile.ZipFile(pluginfile, 'w') as zp:
            #         zp.writestr("manifest.json", manifest_json)
            #         zp.writestr("background.js", background_js)
            # options.add_extension(pluginfile)
            # # options.add_argument('--headless')
            # options.add_argument('--disable-gpu')
            chromedriver = "chromedriver.exe"
            os.environ["webdriver.chrome.driver"] = chromedriver

            options = Options()
            # options.add_argument('--headless')

            options.add_argument('--disable-gpu')  # Last I checked this was necessary.

            driver = webdriver.Chrome(chromedriver, chrome_options=options)
            url=urlg.split(":>>")[0]
            LOB=urlg.split(":>>")[1]
            # driver = webdriver.Chrome(chromedriver, chrome_options=options)
            # driver.set_window_size(0,0)
            print('Running URL  : '+ url)
            driver.get(url)
            time.sleep(3)
            # html = driver.page_source
            # soup = bs(html, features='lxml')
            pages=0
            Check_Page=True
            while Check_Page:
                SCROLL_PAUSE_TIME = 1

                # Get scroll height
                last_height = driver.execute_script("return document.body.scrollHeight")

                while True:
                    # Scroll down to bottom
                    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")

                    # Wait to load page
                    time.sleep(SCROLL_PAUSE_TIME)

                    # Calculate new scroll height and compare with last scroll height
                    new_height = driver.execute_script("return document.body.scrollHeight")
                    if new_height == last_height:
                        break
                    last_height = new_height

                time.sleep(3)
                html = driver.page_source
                soup = bs(html, features='lxml')
                all_div=soup.find_all('li', {'class': 'gl-item'})

                for getu in all_div:
                    productdata={}
                    divimg=getu.find('div',{'class':'jDesc'})
                    purl='https:'+divimg.find('a')['href']
                    productname=divimg.text.replace('\n','').replace('\t','').replace('\r','').strip()
                    itemsku_sp=purl.split('/')
                    itemsku=itemsku_sp[len(itemsku_sp)-1].replace('.html','').strip()
                    list_price = getu.find('div', {'class': 'jdPrice'}).text.replace('￥',"").strip()

                    productdata['LOB']=LOB
                    productdata['Country'] = 'China'
                    productdata['Site'] = 'jd-cn'
                    productdata['ItemNumber'] = itemsku
                    productdata['MPN']=itemsku
                    productdata['Manufacturer'] = str(productname.split(" ")[0])
                    productdata['Name'] = productname
                    productdata['Product URL'] = purl
                    productdata['List price'] = list_price
                    productdata['Promo price'] =list_price
                    productdata['Currency'] = 'CNY'
                    productdata['Retailer ID'] = '95955'
                    productdata['Category URL'] = driver.current_url
                    productdata['Crawling Date'] = str(datetime.datetime.now())
                    self.Output.append(productdata)
                    self.sqldata.append(productdata)
                try:
                    next=soup.find('span', {'class': 'jPageDisable'}).text
                    if '>' in next:
                        Check_Page=False
                    else:
                        pages+=1
                        pages=driver.find_element_by_class_name('jPage').find_elements_by_tag_name('a')
                        ActionChains(driver).move_to_element(pages[len(pages)-1]).perform()
                        time.sleep(3)
                        pages[len(pages)-1].click()
                        time.sleep(5)

                    # driver.get(url+'/?page='+str(pages))
                    # print('Pages Hit ::'+str(pages))
                except Exception as e:
                    Check_Page=False
                    # print('Last Page Hit')
            driver.close()
            print('Completed URL :',str(self.Count)+' Out of '+str(len(self.inputs)))
            self.Count += 1
            self.Save_Info()
        except Exception as e:
            print('Page not hit: (Pagging Error)')
            driver.close()

    def Save_Info(self):
        columns_order=['LOB','Country','Site','ItemNumber','MPN','Manufacturer','Product Name','Product URL','List price','Promo price','Currency','Retailer ID','Category URL','Date']
        print('Excel is generating for : '+str(len(self.Output))+' Products')
        df=pd.DataFrame(self.Output,columns=columns_order)
        now=datetime.datetime.now()
        datstr = str(now.day) + '_' + str(now.month) + '_' + str(now.year)
        df.to_excel('./Output/jd_Cn_product'+datstr+'.xlsx')
        print('Excel is Completed for : ' + str(len(self.Output)) + ' Products')
        df = pd.DataFrame(self.sqldata)
        JD_object.Push_TO_Sql(df)
        self.sqldata.clear()

    def Multi_process_List(self, Inputs):
        i = 1
        pool = Pool(processes=1)
        pool_outputs = pool.map(self.Get_Product_URL, Inputs)
        pool.close()
        pool.join()

    def Push_TO_Sql(self,df):
        ''''add here'''
        connStr = pyodbc.connect('DRIVER={SQL Server};SERVER=ecxus249;DATABASE=SHOPAMD;UID=SHOPAMD;PWD=SHOP@md2010')
        if connStr:
            # print('Connected To SQL Server')
            cursor = connStr.cursor()
            for index, row in df.iterrows():
                try:
                    cursor.execute(
                        "INSERT INTO dbo.Master_Collation(LOB,Country,Site, CategoryURL,Itemnumber,MPN,Manufacturer,ProductName,ProductURL,Listprice,Promoprice,CurrencyType,RetailerID,Date) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        row['LOB'], row['Country'], row['Site'], row['Category URL'], row['ItemNumber'], row['MPN'],
                        row['Manufacturer'], row['Name'], row['Product URL'], row['List Price'], row['Promo Price'],
                        row['Currency'], row['Retailer ID'], row['Date'])
                except Exception as e:
                    print(e)
            connStr.commit()
            print('Sucessfully Stored Records To DB')
            cursor.close()
            connStr.close()

if __name__=='__main__':

    JD_object=JD_product()
    Inputs=JD_object.excel_To_List()
    JD_object.Multi_process_List(Inputs)
    JD_object.Save_Info()
